<?php
// database_connection.php

$host = 'sql102.infinityfree.com';
$username = 'if0_40435316';
$password = 'NJHOmLBWzet';
$dbname = 'if0_40435316_ghimire';
try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}
?>