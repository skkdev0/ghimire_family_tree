<?php
// delete_member.php
require_once 'database_connection.php';

if(isset($_POST['member_id'])) {
    try {
        // Check if member has children
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM Ghimire_members WHERE parent = ?");
        $stmt->execute([$_POST['member_id']]);
        $childCount = $stmt->fetchColumn();
        
        if($childCount > 0) {
            echo json_encode(['success' => false, 'error' => 'Cannot delete member with children']);
        } else {
            $stmt = $pdo->prepare("DELETE FROM Ghimire_members WHERE id = ?");
            $stmt->execute([$_POST['member_id']]);
            echo json_encode(['success' => true, 'message' => 'Member deleted successfully']);
        }
    } catch(PDOException $e) {
        echo json_encode(['success' => false, 'error' => $e->getMessage()]);
    }
}
?>