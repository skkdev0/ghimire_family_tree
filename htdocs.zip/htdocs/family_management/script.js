// script.js
let currentFamilyId = null;
let currentFamilyName = null;
let isEditing = false;
let currentEditMemberId = null;

function loadFamily(familyId, element) {
    // Update UI
    document.querySelectorAll('.family-item').forEach(item => {
        item.classList.remove('active');
    });
    element.classList.add('active');
    
    // Show members section
    const membersSection = document.getElementById('members-section');
    membersSection.classList.add('active');
    
    // Show loading
    document.getElementById('members-list').innerHTML = `
        <div class="loading">
            <div class="loading-spinner"></div>
            <p>Loading members...</p>
        </div>
    `;
    
    // Load members
    fetch('get_members.php?family_id=' + familyId)
        .then(response => response.text())
        .then(data => {
            document.getElementById('members-list').innerHTML = data;
            currentFamilyId = familyId;
            currentFamilyName = element.querySelector('.family-name').textContent;
            document.getElementById('current-family-name').textContent = '👨‍👩‍👧‍👦 ' + currentFamilyName + ' Members';
        })
        .catch(error => {
            showMessage('Error loading members: ' + error, 'error');
        });
}

function showAddMemberForm() {
    if (!currentFamilyId) {
        showMessage('Please select a family first', 'error');
        return;
    }

    isEditing = false;
    currentEditMemberId = null;
    
    document.getElementById('members-list').innerHTML = `
        <div class="form-container">
            <h3>👤 Add New Family Member</h3>
            <form onsubmit="saveMember(event)" id="member-form">
                <input type="hidden" name="family_id" value="${currentFamilyId}">
                <input type="hidden" name="member_id" id="member_id" value="">
                <input type="hidden" name="author" value="1">
                
                <div class="form-section">
                    <div class="form-section-title">Personal Information</div>
                    <div class="form-row">
                        <div class="form-group">
                            <label class="form-label">First Name *</label>
                            <input type="text" name="firstname" id="firstname" class="form-control" required 
                                   placeholder="Enter first name">
                        </div>
                        <div class="form-group">
                            <label class="form-label">Last Name *</label>
                            <input type="text" name="lastname" id="lastname" class="form-control" required 
                                   placeholder="Enter last name">
                        </div>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label class="form-label">Gender *</label>
                            <select name="gender" id="gender" class="form-control" required>
                                <option value="0">⚧ Other</option>
                                <option value="1">👩 Female</option>
                                <option value="2">👨 Male</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Birth Date</label>
                            <input type="date" name="birthdate" id="birthdate" class="form-control">
                        </div>
                    </div>
                </div>
                
                <div class="form-section">
                    <div class="form-section-title">Family Relations</div>
                    <div class="form-row">
                        <div class="form-group">
                            <label class="form-label">Parent</label>
                            <select name="parent" class="form-control" id="parent-select">
                                <option value="0">👤 No Parent (Root Member)</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Relation/Spouse</label>
                            <input type="text" name="relation" id="relation" class="form-control" 
                                   placeholder="Spouse/Partner name">
                        </div>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label class="form-label">Level</label>
                            <input type="number" name="level" id="level" class="form-control" value="0" min="0">
                        </div>
                        <div class="form-group">
                            <label class="form-label">Type</label>
                            <select name="type" id="type" class="form-control">
                                <option value="1">Family Member</option>
                                <option value="2">Relative</option>
                                <option value="3">Friend</option>
                            </select>
                        </div>
                    </div>
                </div>
                
                <div class="form-section">
                    <div class="form-section-title">Contact Information</div>
                    <div class="form-row">
                        <div class="form-group">
                            <label class="form-label">Phone</label>
                            <input type="tel" name="phone" id="phone" class="form-control" 
                                   placeholder="Phone number">
                        </div>
                        <div class="form-group">
                            <label class="form-label">Email</label>
                            <input type="email" name="email" id="email" class="form-control" 
                                   placeholder="Email address">
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">Address</label>
                        <textarea name="address" id="address" class="form-control" rows="3" 
                                  placeholder="Full address"></textarea>
                    </div>
                </div>
                
                <div class="form-section">
                    <div class="form-section-title">Professional Information</div>
                    <div class="form-row">
                        <div class="form-group">
                            <label class="form-label">Education</label>
                            <input type="text" name="education" id="education" class="form-control" 
                                   placeholder="Education level">
                        </div>
                        <div class="form-group">
                            <label class="form-label">Occupation</label>
                            <input type="text" name="occupation" id="occupation" class="form-control" 
                                   placeholder="Occupation">
                        </div>
                    </div>
                </div>
                
                <div class="form-section">
                    <div class="form-section-title">Additional Information</div>
                    <div class="form-group">
                        <label class="form-label">Notes</label>
                        <textarea name="notes" id="notes" class="form-control" rows="3" 
                                  placeholder="Additional notes"></textarea>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">
                            <input type="checkbox" name="death" id="death" value="1"> Deceased
                        </label>
                    </div>
                </div>
                
                <div class="form-actions">
                    <button type="submit" class="btn btn-success">💾 Save Member</button>
                    <button type="button" class="btn btn-danger" onclick="cancelForm()">❌ Cancel</button>
                </div>
            </form>
        </div>
    `;
    
    loadParents(currentFamilyId);
}

function editMember(memberId) {
    if (!currentFamilyId) {
        showMessage('Please select a family first', 'error');
        return;
    }

    isEditing = true;
    currentEditMemberId = memberId;
    
    // Show loading
    document.getElementById('members-list').innerHTML = `
        <div class="loading">
            <div class="loading-spinner"></div>
            <p>Loading member data...</p>
        </div>
    `;
    
    // Load member data
    fetch('get_members.php?family_id=' + currentFamilyId + '&member_data=' + memberId)
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(member => {
            if (!member) {
                throw new Error('Member not found');
            }
            
            console.log('Loaded member data:', member); // Debug log
            
            // Set form values
            document.getElementById('members-list').innerHTML = `
                <div class="form-container">
                    <h3>✏️ Edit Family Member</h3>
                    <form onsubmit="saveMember(event)" id="member-form">
                        <input type="hidden" name="family_id" value="${currentFamilyId}">
                        <input type="hidden" name="member_id" id="member_id" value="${member.id}">
                        <input type="hidden" name="author" value="${member.author || 1}">
                        
                        <div class="form-section">
                            <div class="form-section-title">Personal Information</div>
                            <div class="form-row">
                                <div class="form-group">
                                    <label class="form-label">First Name *</label>
                                    <input type="text" name="firstname" id="firstname" class="form-control" required 
                                           value="${escapeHtml(member.firstname || '')}" placeholder="Enter first name">
                                </div>
                                <div class="form-group">
                                    <label class="form-label">Last Name *</label>
                                    <input type="text" name="lastname" id="lastname" class="form-control" required 
                                           value="${escapeHtml(member.lastname || '')}" placeholder="Enter last name">
                                </div>
                            </div>
                            
                            <div class="form-row">
                                <div class="form-group">
                                    <label class="form-label">Gender *</label>
                                    <select name="gender" id="gender" class="form-control" required>
                                        <option value="0" ${member.gender == 0 ? 'selected' : ''}>⚧ Other</option>
                                        <option value="1" ${member.gender == 1 ? 'selected' : ''}>👩 Female</option>
                                        <option value="2" ${member.gender == 2 ? 'selected' : ''}>👨 Male</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label class="form-label">Birth Date</label>
                                    <input type="date" name="birthdate" id="birthdate" class="form-control" 
                                           value="${member.birthdate || ''}">
                                </div>
                            </div>
                        </div>
                        
                        <div class="form-section">
                            <div class="form-section-title">Family Relations</div>
                            <div class="form-row">
                                <div class="form-group">
                                    <label class="form-label">Parent</label>
                                    <select name="parent" class="form-control" id="parent-select">
                                        <option value="0">👤 No Parent (Root Member)</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label class="form-label">Relation/Spouse</label>
                                    <input type="text" name="relation" id="relation" class="form-control" 
                                           value="${escapeHtml(member.relation || '')}" placeholder="Spouse/Partner name">
                                </div>
                            </div>
                            
                            <div class="form-row">
                                <div class="form-group">
                                    <label class="form-label">Level</label>
                                    <input type="number" name="level" id="level" class="form-control" 
                                           value="${member.level || 0}" min="0">
                                </div>
                                <div class="form-group">
                                    <label class="form-label">Type</label>
                                    <select name="type" id="type" class="form-control">
                                        <option value="1" ${member.type == 1 ? 'selected' : ''}>Family Member</option>
                                        <option value="2" ${member.type == 2 ? 'selected' : ''}>Relative</option>
                                        <option value="3" ${member.type == 3 ? 'selected' : ''}>Friend</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        
                        <div class="form-section">
                            <div class="form-section-title">Contact Information</div>
                            <div class="form-row">
                                <div class="form-group">
                                    <label class="form-label">Phone</label>
                                    <input type="tel" name="phone" id="phone" class="form-control" 
                                           value="${escapeHtml(member.phone || '')}" placeholder="Phone number">
                                </div>
                                <div class="form-group">
                                    <label class="form-label">Email</label>
                                    <input type="email" name="email" id="email" class="form-control" 
                                           value="${escapeHtml(member.email || '')}" placeholder="Email address">
                                </div>
                            </div>
                            
                            <div class="form-group">
                                <label class="form-label">Address</label>
                                <textarea name="address" id="address" class="form-control" rows="3" 
                                          placeholder="Full address">${escapeHtml(member.address || '')}</textarea>
                            </div>
                        </div>
                        
                        <div class="form-section">
                            <div class="form-section-title">Professional Information</div>
                            <div class="form-row">
                                <div class="form-group">
                                    <label class="form-label">Education</label>
                                    <input type="text" name="education" id="education" class="form-control" 
                                           value="${escapeHtml(member.education || '')}" placeholder="Education level">
                                </div>
                                <div class="form-group">
                                    <label class="form-label">Occupation</label>
                                    <input type="text" name="occupation" id="occupation" class="form-control" 
                                           value="${escapeHtml(member.occupation || '')}" placeholder="Occupation">
                                </div>
                            </div>
                        </div>
                        
                        <div class="form-section">
                            <div class="form-section-title">Additional Information</div>
                            <div class="form-group">
                                <label class="form-label">Notes</label>
                                <textarea name="notes" id="notes" class="form-control" rows="3" 
                                          placeholder="Additional notes">${escapeHtml(member.notes || '')}</textarea>
                            </div>
                            
                            <div class="form-group">
                                <label class="form-label">
                                    <input type="checkbox" name="death" id="death" value="1" ${member.death == 1 ? 'checked' : ''}> Deceased
                                </label>
                            </div>
                        </div>
                        
                        <div class="form-actions">
                            <button type="submit" class="btn btn-success">💾 Update Member</button>
                            <button type="button" class="btn btn-danger" onclick="cancelForm()">❌ Cancel</button>
                        </div>
                    </form>
                </div>
            `;
            
            loadParents(currentFamilyId, member.parent || 0);
        })
        .catch(error => {
            console.error('Error loading member data:', error);
            showMessage('Error loading member data: ' + error.message, 'error');
        });
}

function escapeHtml(text) {
    const map = {
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#039;'
    };
    return text.replace(/[&<>"']/g, function(m) { return map[m]; });
}

function loadParents(familyId, selectedParentId = 0) {
    fetch('get_members.php?family_id=' + familyId + '&parents_only=1')
        .then(response => response.json())
        .then(members => {
            const select = document.getElementById('parent-select');
            if (!select) return;
            
            // Clear existing options except the first one
            while(select.children.length > 1) {
                select.removeChild(select.lastChild);
            }
            
            members.forEach(member => {
                // Don't allow selecting self as parent when editing
                if (isEditing && member.id == currentEditMemberId) {
                    return;
                }
                
                const option = document.createElement('option');
                option.value = member.id;
                const genderIcon = member.gender == 1 ? '👩' : member.gender == 2 ? '👨' : '⚧';
                option.textContent = `${genderIcon} ${member.firstname} ${member.lastname}`;
                option.selected = (parseInt(member.id) === parseInt(selectedParentId));
                select.appendChild(option);
            });
        })
        .catch(error => {
            console.error('Error loading parents:', error);
        });
}

function saveMember(event) {
    event.preventDefault();
    const formData = new FormData(event.target);
    
    const url = isEditing ? 'edit_member.php' : 'add_member.php';
    const successMessage = isEditing ? 'Member updated successfully!' : 'Member added successfully!';
    
    fetch(url, {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(result => {
        if(result.success) {
            showMessage(successMessage, 'success');
            loadFamily(currentFamilyId, document.querySelector('.family-item.active'));
        } else {
            showMessage('Error: ' + result.error, 'error');
        }
    })
    .catch(error => {
        showMessage('Network error: ' + error, 'error');
    });
}

function cancelForm() {
    loadFamily(currentFamilyId, document.querySelector('.family-item.active'));
}

function showMessage(message, type) {
    const container = document.getElementById('messages-container');
    const messageDiv = document.createElement('div');
    messageDiv.className = `message ${type}`;
    messageDiv.textContent = message;
    container.appendChild(messageDiv);
    
    setTimeout(() => {
        messageDiv.remove();
    }, 5000);
}

function deleteMember(memberId) {
    if(confirm('Are you sure you want to delete this member?')) {
        fetch('delete_member.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: 'member_id=' + memberId
        })
        .then(response => response.json())
        .then(result => {
            if(result.success) {
                showMessage('Member deleted successfully!', 'success');
                loadFamily(currentFamilyId, document.querySelector('.family-item.active'));
            } else {
                showMessage('Error: ' + result.error, 'error');
            }
        });
    }
}