<?php
// families_list.php
require_once 'database_connection.php';

// Get all families
$stmt = $pdo->query("SELECT * FROM Ghimire_families WHERE status = 0 ORDER BY name");
$families = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="ne">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Family Management System</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🏠 Family Management System</h1>
            <p>Manage your family tree with ease</p>
        </div>
        
        <div class="content">
            <!-- Family List Section -->
            <div class="family-section">
                <h2 class="section-title">📁 Family Groups</h2>
                <ul class="family-list">
                    <?php foreach($families as $family): ?>
                        <li class="family-item" onclick="loadFamily(<?php echo $family['id']; ?>, this)">
                            <div class="family-name"><?php echo htmlspecialchars($family['name']); ?></div>
                            <span class="family-id">ID: <?php echo $family['id']; ?></span>
                        </li>
                    <?php endforeach; ?>
                </ul>
            </div>
            
            <!-- Members Section -->
            <div class="members-section" id="members-section">
                <div class="members-header">
                    <h2 class="section-title" id="current-family-name">👨‍👩‍👧‍👦 Family Members</h2>
                    <button class="btn btn-primary" onclick="showAddMemberForm()">
                        <span>➕</span> Add New Member
                    </button>
                </div>
                
                <div id="messages-container"></div>
                <div id="members-list" class="members-container">
                    <div class="loading">
                        <div class="loading-spinner"></div>
                        <p>Select a family to view members</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="script.js"></script>
</body>
</html>