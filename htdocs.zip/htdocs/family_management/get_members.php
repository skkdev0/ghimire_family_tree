<?php
// get_members.php
require_once 'database_connection.php';

if(isset($_GET['family_id'])) {
    $family_id = $_GET['family_id'];
    
    if(isset($_GET['parents_only'])) {
        // Get only parents for dropdown
        $stmt = $pdo->prepare("SELECT id, firstname, lastname, gender FROM Ghimire_members WHERE family = ?");
        $stmt->execute([$family_id]);
        $members = $stmt->fetchAll(PDO::FETCH_ASSOC);
        echo json_encode($members);
        exit;
    }
    
    if(isset($_GET['member_data'])) {
        // Get single member data for editing
        $stmt = $pdo->prepare("SELECT * FROM Ghimire_members WHERE id = ? AND family = ?");
        $stmt->execute([$_GET['member_data'], $family_id]);
        $member = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if($member) {
            // Format dates for form input
            if($member['birthdate'] && $member['birthdate'] != '0000-00-00') {
                $member['birthdate'] = date('Y-m-d', strtotime($member['birthdate']));
            } else {
                $member['birthdate'] = '';
            }
        }
        
        echo json_encode($member);
        exit;
    }
    
    // Get all members with proper hierarchy
    $stmt = $pdo->prepare("
        SELECT m.*, 
               p.firstname as parent_firstname, 
               p.lastname as parent_lastname,
               (SELECT COUNT(*) FROM Ghimire_members WHERE parent = m.id) as child_count
        FROM Ghimire_members m 
        LEFT JOIN Ghimire_members p ON m.parent = p.id 
        WHERE m.family = ? 
        ORDER BY COALESCE(m.parent, 0), m.id
    ");
    $stmt->execute([$family_id]);
    $members = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Build hierarchy
    $memberTree = [];
    $memberMap = [];
    
    foreach($members as $member) {
        $memberMap[$member['id']] = $member;
        $memberMap[$member['id']]['children'] = [];
    }
    
    foreach($members as $member) {
        if($member['parent'] && isset($memberMap[$member['parent']])) {
            $memberMap[$member['parent']]['children'][] = &$memberMap[$member['id']];
        } else {
            $memberTree[] = &$memberMap[$member['id']];
        }
    }
    
    // Generate HTML with proper hierarchy
    function renderMemberTree($members, $level = 0) {
        $html = '';
        foreach($members as $member) {
            $genderClass = '';
            $genderText = 'Other';
            if($member['gender'] == 1) {
                $genderClass = 'female';
                $genderText = 'Female';
            } elseif($member['gender'] == 2) {
                $genderClass = 'male';
                $genderText = 'Male';
            } else {
                $genderClass = 'other';
                $genderText = 'Other';
            }
            
            // Format birthdate
            $birthdate = '';
            if($member['birthdate'] && $member['birthdate'] != '0000-00-00') {
                $birthdate = date('M d, Y', strtotime($member['birthdate']));
            }
            
            // Death status
            $deathStatus = $member['death'] ? ' († Deceased)' : '';
            
            $html .= '<div class="member-item ' . $genderClass . ' member-level-' . $level . '">';
            $html .= '<div class="member-info">';
            $html .= '<div class="member-name">' . htmlspecialchars($member['firstname'] . ' ' . $member['lastname']) . $deathStatus . '</div>';
            $html .= '<div class="member-details">';
            $html .= '<span class="detail-badge gender-' . $genderClass . '">' . $genderText . '</span>';
            
            if($birthdate) {
                $html .= '<span class="detail-badge">🎂 ' . $birthdate . '</span>';
            }
            
            if($member['parent_firstname']) {
                $html .= '<span class="detail-badge">👥 Child of: ' . htmlspecialchars($member['parent_firstname'] . ' ' . $member['parent_lastname']) . '</span>';
            } else {
                $html .= '<span class="detail-badge">👤 Root Member</span>';
            }
            
            if($member['relation']) {
                $html .= '<span class="detail-badge">💑 ' . htmlspecialchars($member['relation']) . '</span>';
            }
            
            if($member['occupation']) {
                $html .= '<span class="detail-badge">💼 ' . htmlspecialchars($member['occupation']) . '</span>';
            }
            
            if($member['child_count'] > 0) {
                $html .= '<span class="detail-badge">👶 ' . $member['child_count'] . ' children</span>';
            }
            
            // Show additional fields if they exist
            if($member['type'] && $member['type'] != 1) {
                $typeText = '';
                switch($member['type']) {
                    case 2: $typeText = 'Relative'; break;
                    case 3: $typeText = 'Friend'; break;
                    default: $typeText = 'Family Member';
                }
                $html .= '<span class="detail-badge">🏷️ ' . $typeText . '</span>';
            }
            
            $html .= '</div>';
            
            // Additional information
            if($member['address'] || $member['phone'] || $member['email'] || $member['education'] || $member['notes']) {
                $html .= '<div class="member-additional-info">';
                if($member['address']) {
                    $html .= '<div class="additional-detail">🏠 ' . htmlspecialchars($member['address']) . '</div>';
                }
                if($member['phone']) {
                    $html .= '<div class="additional-detail">📞 ' . htmlspecialchars($member['phone']) . '</div>';
                }
                if($member['email']) {
                    $html .= '<div class="additional-detail">📧 ' . htmlspecialchars($member['email']) . '</div>';
                }
                if($member['education']) {
                    $html .= '<div class="additional-detail">🎓 ' . htmlspecialchars($member['education']) . '</div>';
                }
                if($member['notes']) {
                    $html .= '<div class="additional-detail">📝 ' . htmlspecialchars($member['notes']) . '</div>';
                }
                $html .= '</div>';
            }
            
            $html .= '</div>';
            $html .= '<div class="member-actions">';
            $html .= '<button class="btn btn-warning btn-sm" onclick="editMember(' . $member['id'] . ')">✏️ Edit</button>';
            $html .= '<button class="btn btn-danger btn-sm" onclick="deleteMember(' . $member['id'] . ')">🗑️ Delete</button>';
            $html .= '</div>';
            
            // Render children recursively
            if(!empty($member['children'])) {
                $html .= renderMemberTree($member['children'], $level + 1);
            }
            
            $html .= '</div>';
        }
        return $html;
    }
    
    echo '<div class="members-container">';
    echo renderMemberTree($memberTree);
    echo '</div>';
}
?>