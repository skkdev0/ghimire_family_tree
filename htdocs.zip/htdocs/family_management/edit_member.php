<?php
// edit_member.php
require_once 'database_connection.php';

if($_POST) {
    try {
        $stmt = $pdo->prepare("
            UPDATE Ghimire_members 
            SET firstname = ?, lastname = ?, gender = ?, parent = ?, level = ?, 
                death = ?, type = ?, relation = ?, birthdate = ?, address = ?, 
                phone = ?, email = ?, education = ?, occupation = ?, notes = ?
            WHERE id = ? AND family = ?
        ");
        
        $stmt->execute([
            $_POST['firstname'],
            $_POST['lastname'],
            $_POST['gender'],
            $_POST['parent'],
            $_POST['level'] ?? 0,
            $_POST['death'] ?? 0,
            $_POST['type'] ?? 1,
            $_POST['relation'] ?? '',
            $_POST['birthdate'] ?? '',
            $_POST['address'] ?? '',
            $_POST['phone'] ?? '',
            $_POST['email'] ?? '',
            $_POST['education'] ?? '',
            $_POST['occupation'] ?? '',
            $_POST['notes'] ?? '',
            $_POST['member_id'],
            $_POST['family_id']
        ]);
        
        echo json_encode(['success' => true, 'message' => 'Member updated successfully']);
    } catch(PDOException $e) {
        echo json_encode(['success' => false, 'error' => $e->getMessage()]);
    }
}
?>