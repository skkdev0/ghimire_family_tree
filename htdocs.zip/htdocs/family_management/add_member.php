<?php
// add_member.php
require_once 'database_connection.php';

if($_POST) {
    try {
        $stmt = $pdo->prepare("
            INSERT INTO Ghimire_members 
            (author, family, date, firstname, lastname, gender, parent, level, death, type, relation, birthdate, address, phone, email, education, occupation, notes) 
            VALUES (?, ?, UNIX_TIMESTAMP(), ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");
        
        $stmt->execute([
            $_POST['author'] ?? 1,
            $_POST['family_id'],
            $_POST['firstname'],
            $_POST['lastname'],
            $_POST['gender'],
            $_POST['parent'] ?? 0,
            $_POST['level'] ?? 0,
            $_POST['death'] ?? 0,
            $_POST['type'] ?? 1,
            $_POST['relation'] ?? '',
            $_POST['birthdate'] ?? '',
            $_POST['address'] ?? '',
            $_POST['phone'] ?? '',
            $_POST['email'] ?? '',
            $_POST['education'] ?? '',
            $_POST['occupation'] ?? '',
            $_POST['notes'] ?? ''
        ]);
        
        echo json_encode(['success' => true, 'message' => 'Member added successfully']);
    } catch(PDOException $e) {
        echo json_encode(['success' => false, 'error' => $e->getMessage()]);
    }
}
?>