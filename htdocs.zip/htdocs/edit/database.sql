-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: sql105.ezyro.com
-- Generation Time: Oct 27, 2025 at 12:59 PM
-- Server version: 11.4.7-MariaDB
-- PHP Version: 7.2.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ezyro_39771760_data`
--

-- --------------------------------------------------------

--
-- Table structure for table `Ghimire_configs`
--

CREATE TABLE `Ghimire_configs` (
  `id` tinyint(3) UNSIGNED NOT NULL,
  `variable` varchar(255) DEFAULT NULL,
  `value` text DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Dumping data for table `Ghimire_configs`
--

INSERT INTO `Ghimire_configs` (`id`, `variable`, `value`) VALUES
(1, 'site_title', 'Ghimire Family'),
(2, 'site_url', 'https://www.facebook.com/shyamchhetri0'),
(3, 'site_description', 'Make your family tree live with Ghimire Family Tree and do not leave it just a memory hanging. build it with the participation of everyone and make it stretch to infinity.'),
(4, 'site_keywords', 'family tree, Ghimire family tree, family builder, family tree maker'),
(5, 'site_author', 'ShyamKumarKshetri'),
(6, 'site_register', '1'),
(7, 'site_plans', '1'),
(8, 'site_register_status', '0'),
(9, 'site_families_status', '0'),
(10, 'site_reset_password_msg', NULL),
(11, 'color1', '#ff3535'),
(12, 'color2', '#ff0000'),
(13, 'color3', '#0026ff'),
(14, 'color4', '#f0f9f7'),
(15, 'color5', '#35a299'),
(16, 'color6', '#a29bfe'),
(17, 'color7', '#fdb105'),
(18, 'color8', '#3c46fe'),
(19, 'color9', '#000'),
(20, 'color10', '#DDD'),
(51, 'site_smtp_auth', '1'),
(50, 'site_smtp_port', '587'),
(26, 'site_noreply', 'donotreply@ShyamKumarKshetri.com'),
(31, 'login_facebook', '1'),
(32, 'login_twitter', '1'),
(33, 'login_google', '1'),
(34, 'login_fbAppId', ''),
(35, 'login_fbAppSecret', ''),
(36, 'login_fbAppVersion', ''),
(37, 'login_twConKey', ''),
(38, 'login_twConSecret', ''),
(39, 'login_ggClientId', ''),
(40, 'login_ggClientSecret', ''),
(41, 'site_paypal_id', ''),
(42, 'site_paypal_live', '0'),
(43, 'site_currency_name', 'USD'),
(44, 'site_currency_symbol', '$'),
(45, 'site_smtp', '0'),
(46, 'site_smtp_host', 'localhost'),
(47, 'site_smtp_username', ''),
(48, 'site_smtp_password', ''),
(49, 'site_smtp_encryption', 'none'),
(52, 'site_favicon', 'assets/img/fav.png'),
(53, 'site_paypal_client_id', ''),
(54, 'site_paypal_client_secret', ''),
(62, 'site_stripe_key', ''),
(63, 'site_stripe_secret', ''),
(65, 'site_ads1', '<a href=\"https://codecanyon.net/item/ifood-multi-restaurant-merchant-hosting-site/27556124\" target=\"_blank\"><img src=\"https://lh5.googleusercontent.com/gJJaadz-vB5IFDWmtZ9KAAUUBg7GtrtCwGyLW7h8ByBofQbn5VX9J0XdI67-gnBQKqo=w2400\"></a>'),
(66, 'site_ads2', '<img src=\"http://ShyamKumarKshetri.com/quizy/assets/img/ads/ads2.png\">'),
(67, 'site_ads3', '<img src=\"http://ShyamKumarKshetri.com/quizy/assets/img/ads/ads3.png\">'),
(68, 'site_ads4', '<img src=\"http://ShyamKumarKshetri.com/quizy/assets/img/ads/ads3.png\">'),
(69, 'site_ads5', '<img src=\"http://ShyamKumarKshetri.com/quizy/assets/img/ads/ads2.png\">'),
(70, 'site_ads6', '<img src=\"http://ShyamKumarKshetri.com/quizy/assets/img/ads/ads2.png\">'),
(71, 'site_language', '{\"rtl\":\"false\",\"lang\":\"en\",\"success\":\"Success!\",\"error\":\"Error!\",\"rip\":\"R.I.P\",\"site\":{\"title\":\"Ghimire Family Tree\",\"no-result\":\"No Result Found!\",\"submit\":\"Submit\",\"close\":\"Close\",\"emailver\":\"Email verification:\"},\"header\":{\"welcome\":\"Welcome!\",\"search\":\"Search for family...\",\"home\":\"Home\",\"family\":\"Family Trees\",\"plans\":\"Plans\",\"about\":\"About Us\",\"contact\":\"Contact Us\",\"details\":\"Your Details\",\"logout\":\"Logout!\",\"no-not\":\"No notifications\",\"newtree\":\"Create a tree\",\"dashboard\":\"Dashboard\",\"users\":\"Users\",\"fam\":\"Family Tree\",\"fammanag\":\"Managers (Only Usernames):\"},\"plans\":{\"title\":\"Simple Pricing for Everyone!\",\"desc\":\"Pricing is built for businesses of all sizes. Always know what you will pay. All plans come with a 100% money-back guarantee.\",\"month\":\"/per month\",\"btn\":\"Get Started\",\"alert\":{\"success\":\"Your payments have been calculated!\"}},\"indexpage\":{\"h4\":\"Building Family Tree.\",\"h2\":\"Who are they?\",\"p\":\"Make your family tree live with Ghimire Family Tree and do not leave it just a memory hanging. build it with the participation of everyone and make it stretch to infinity.\",\"form\":{\"b\":\"More than just a family tree.\",\"s\":\"A new home for family memories\",\"login\":\"Login\",\"register\":\"Register\",\"fid\":{\"l\":\"Family ID:\",\"i\":\"Write your family ID\"},\"pass\":{\"l\":\"Password:\",\"i\":\"Write your password\"},\"npass\":{\"l\":\"New Password:\",\"i\":\"Write your new password\"},\"vpass\":{\"l\":\"View Password:\",\"i\":\"Write your view password\"},\"email\":{\"l\":\"Email:\",\"i\":\"Write your email\"},\"in\":\"Sign In\",\"up\":\"Sign Up\",\"view\":\"Can everyone see this family (public view)\"},\"my\":\"My Family Tree\",\"list\":\"List Of the trees you manage!\",\"more\":\"More Results!\",\"forget\":\"Forget your password?\",\"reset\":\"Reset it now\",\"pravicy\":\"Pravicy policy\",\"byclick\":\"By clicking in Sign up button you are automaticly accepting in our {a}, dont hasitate to read it first!\"},\"treepage\":{\"vp\":{\"t\":\"View Password :\",\"p\":\"We are sorry to inform you that, this family isnt public view. you need to have password view to show it.\",\"i\":\"Write the view password\",\"b\":\"Submit\"},\"edit\":\"Edit\",\"new\":\"New Member\",\"link\":\"Tree Link\",\"fam\":\"s Family Tree:\",\"share\":\"Share\",\"share_f\":\"Share on Facebook\",\"share_t\":\"Share on Twitter\",\"share_w\":\"Share on Whatsapp\",\"share_e\":\"Send in Email\",\"pdf\":\"Export PDF\"},\"heritage\":{\"title\":\"Heritage a family                     :\",\"link\":\"Link this momber as a parent of family:\"},\"detailspage\":{\"title\":\"Manege your details\",\"send\":\"Send Details\",\"username\":\"Your Username\",\"username_l\":\"Write your username\"},\"contactpage\":{\"title\":\"Contact Us\"},\"aboutpage\":{\"title\":\"About Us\"},\"userspage\":{\"title\":\"Users:\",\"families\":\"families\"},\"resetpage\":{\"title1\":\"Reset your password:\",\"email\":\"Your Registred Email Address\",\"title\":\"Reset new password :\",\"npass\":\"New Password       :\",\"npass_l\":\"type your password\",\"rpass\":\"Re-Password        :\",\"rpass_l\":\"type your re-password\"},\"listpage\":{\"title\":\"Famelie Tree List\",\"no-result\":\"No Result Found!\",\"members\":\"Members\",\"my\":\"My Trees\",\"edit\":\"Edit\"},\"timedate\":{\"time_second\":\"second\",\"time_minute\":\"minute\",\"time_hour\":\"hour\",\"time_day\":\"day\",\"time_week\":\"week\",\"time_month\":\"month\",\"time_year\":\"year\",\"time_decade\":\"decade\",\"time_ago\":\"ago\"},\"newmember\":{\"title\":\"Add New member\",\"personal\":\"Personal\",\"contact\":\"Contact\",\"biographical\":\"Biographical\",\"pictures\":\"Pictures\",\"link\":\"Link this member to a user:\",\"first\":\"First Name:\",\"last\":\"Last Name\",\"gender\":\"Gender\",\"female\":\"Female\",\"male\":\"Male\",\"rtype\":\"Relation Type\",\"child\":\"Child\",\"ex\":\"Ex-Partner\",\"parent\":\"Parent\",\"partner\":\"Partner\",\"bdate\":\"Birth Date\",\"mdate\":\"Mariage Date\",\"ddate\":\"Death Date\",\"alive\":\"This person is alive\",\"photo_url\":\"Enter Photo URL\",\"photo\":\"Photo\",\"choose\":\"Choose an image from your device\",\"instead\":\"Or choose an avatar instead\",\"website\":\"Website\",\"tel\":\"Home Tel\",\"mobile\":\"Mobile\",\"bplace\":\"Birth Place\",\"dplace\":\"Death Place\",\"profession\":\"Profession\",\"company\":\"Company\",\"interests\":\"Interests\",\"bio\":\"Bio Notes\",\"photos\":\"Photos\",\"lab1\":\"Enter first name\",\"lab2\":\"Enter last name\",\"lab3\":\"Enter Facebook\",\"lab4\":\"Enter Twitter\",\"lab5\":\"Enter Instagram\",\"lab6\":\"Enter Email\",\"lab7\":\"Enter Website\",\"lab8\":\"Enter Home Tel\",\"lab9\":\"Enter Mobile\",\"lab10\":\"Enter Birth Place\",\"lab11\":\"Enter Death Place\",\"lab12\":\"Enter Profession\",\"lab13\":\"Enter Company\",\"lab14\":\"Enter Interests\",\"lab15\":\"Enter Bio Notes\",\"bornat\":\"Born at\",\"bornin\":\"in\",\"deadat\":\"Dead at\",\"marriageat\":\"Marriage at\"},\"details\":{\"title\":\"Manage infos:\",\"firstname\":\"Your first name\",\"lastname\":\"Your last name\",\"username\":\"Edit Username\",\"password\":\"Edit Password\",\"email\":\"Edit Email\",\"male\":\"Male\",\"female\":\"Female\",\"country\":\"Country\",\"state\":\"State/Region\",\"city\":\"City\",\"address\":\"Full Address\",\"image_n\":\"No image chosen...\",\"image_c\":\"Choose Image\",\"button\":\"Send info\",\"alert\":{\"success\":\"Edit infos process has ended successfully.\"}},\"alerts\":{\"families\":\"Your number of families that you can add for the plan you have is expired, please upgrade your plan for more!\",\"members\":\"Your number of members per family that you can add for the plan you have is expired, please upgrade your plan for more!\",\"albums\":\"You dont have permission to add photos in albums using the plan you have, please upgrade your plan for more!\",\"heritage\":\"You dont have permission to heritage using the plan you have, please upgrade your plan for more!\",\"no-data\":\"No data found!\",\"nodata\":\"No data found!\",\"logout\":\"Are you sure you want to logout?\",\"nofile\":\"No file chosen...\",\"required\":\"All fields are required!\",\"login\":\"You have login succesfully!\",\"viewp\":\"View password is incorrect!\",\"wrong\":\"something wrong!\",\"done\":\"All done!\",\"payment\":\"Payment success!\",\"payment_f\":\"Failed to retrieve payment from PayPal!\",\"alldone\":\"Success, all done!\",\"famexist\":\"This family is already exist!\",\"name\":\"Name is required!\",\"correctemail\":\"You need a correct email address!\",\"existemail\":\"This Email is already exist!\",\"existusername\":\"This Username is already exist!\",\"regsuccess\":\"Your have being registred succesfuly.\",\"regsuccess1\":\"Your have being registred succesfuly, but we sent you an email for verification!\",\"regsuccess2\":\"Your have being registred succesfuly, but need to be accepted by administration!\",\"famsuccess\":\"Your family ID has created succesfully!\",\"logsuccess\":\"You have login succesfully!\",\"logapprov\":\"this user needs approval by administration before sign in!\",\"logverif\":\"this user needs to verify by email address!\",\"logerror\":\"Family ID or password is incorrect!\",\"reseterror\":\"There is no user with this info!\",\"resetsuccess\":\"The resset password sent succcesfuly.\",\"permission\":\"You have no permission for accessing to this page!\",\"emailver\":\"All right, you can login now.\",\"her_1\":\"you cant herirate this family beacause it isnt yours!\",\"her_2\":\"you cant herirate a family twise in the same tree!\",\"her_3\":\"you cant herirate this family beacause it isnt public!\",\"her_4\":\"you cant herirate this family!\",\"pass1\":\"password more than 6 letters\",\"pass2\":\"password dont match repassword\",\"pass3\":\"you can login now with this new password\",\"de_mem\":\"Are you sure you want to delete this memebr?\"},\"dash\":{\"p_disacticate\":\"Disable plans option\",\"planalert\":\"The plans have been saved successfully.\",\"p_title\":\"Payments\",\"p_user\":\"User\",\"p_status\":\"Status\",\"p_amount\":\"Amount\",\"p_paymentid\":\"Payment ID\",\"p_payerid\":\"Payer ID\",\"created_at\":\"Created At\",\"u_create\":\"Create a User\"},\"dashboard\":{\"hello\":\"Hello,\",\"welcome\":\"Welcome back again to your dashboard.\",\"stats_line_d\":\"Statistics for the last 7 days\",\"stats_line_m\":\"Statistics for this year\",\"stats_bar_d\":\"Statistics for the last 7 days\",\"stats_bar_m\":\"Statistics for this year\",\"surveys\":\"Families\",\"families\":\"Families\",\"users\":\"Users\",\"responses\":\"Members\",\"questions\":\"Images\",\"new_u\":\"New Users (24h)\",\"new_p\":\"Latest Payements (24h)\",\"new_s\":\"Latest Surveys (24h)\",\"u_users\":\"Members\",\"u_status\":\"Status\",\"u_username\":\"Username\",\"u_plan\":\"Plan\",\"u_pages\":\"Pages\",\"u_credits\":\"Credits\",\"u_last_p\":\"Last Payment\",\"u_registred\":\"Registred at\",\"u_updated\":\"Updated at\",\"u_delete\":\"Delete User\",\"u_edit\":\"Edit User\",\"p_title\":\"Payments\",\"p_user\":\"User\",\"p_status\":\"Status\",\"p_plan\":\"Plan\",\"p_amount\":\"Amount\",\"p_date\":\"Payment Date\",\"p_txn\":\"TXN\",\"set_title\":\"General Settings\",\"set_stitle\":\"Site title:\",\"set_keys\":\"Site keywords:\",\"set_desc\":\"Site Description:\",\"set_url\":\"Site URL:\",\"set_btn\":\"Send Settings\",\"days\":\"Days\",\"months\":\"Months\",\"latest_f\":\"Latest Families\",\"latest_m\":\"Latest Members\",\"status\":\"Status\",\"name\":\"name\",\"public\":\"public\",\"members\":\"members\",\"moderators\":\"moderators\",\"date\":\"Date\",\"edit\":\"Edit\",\"delete\":\"Delete\",\"verification\":\"Verification\",\"npage\":\"New Page\",\"title\":\"Title\",\"inmenu\":\"in Menu\",\"created\":\"Created\",\"regstatus\":\"Registration Status:\",\"mneedsapproval\":\"Need Approval Without Email\",\"open\":\"Open\",\"hidereg\":\"Hide registration form\",\"fneedsapproval\":\"Families needs approval before being live\",\"colors\":\"Colors\",\"byemail\":\"By Email\",\"ptitle\":\"Page Title\",\"picon\":\"Page Icon\",\"pcontent\":\"Page Content\",\"dmenu\":\"Display it in menu\",\"save\":\"Save\",\"alert\":{\"success\":\"Setting has sent successfully.\"}}}');

-- --------------------------------------------------------

--
-- Table structure for table `Ghimire_families`
--

CREATE TABLE `Ghimire_families` (
  `id` smallint(5) UNSIGNED NOT NULL,
  `author` int(10) UNSIGNED DEFAULT 0,
  `moderators` varchar(255) DEFAULT NULL,
  `name` varchar(200) DEFAULT NULL,
  `password` varchar(200) DEFAULT NULL,
  `date` int(11) UNSIGNED DEFAULT 0,
  `levels` tinyint(1) UNSIGNED DEFAULT 0,
  `email` varchar(200) DEFAULT NULL,
  `vpassword` varchar(255) DEFAULT NULL,
  `public` tinyint(1) UNSIGNED DEFAULT 0,
  `photo` varchar(255) DEFAULT NULL,
  `status` tinyint(1) UNSIGNED DEFAULT 0,
  `slug` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Ghimire_heritage`
--

CREATE TABLE `Ghimire_heritage` (
  `id` int(11) NOT NULL,
  `family` int(10) UNSIGNED DEFAULT NULL,
  `member` int(10) UNSIGNED DEFAULT NULL,
  `heritage` int(10) UNSIGNED DEFAULT NULL,
  `author` int(10) UNSIGNED DEFAULT NULL,
  `date` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Ghimire_images`
--

CREATE TABLE `Ghimire_images` (
  `id` int(11) NOT NULL,
  `member` int(11) UNSIGNED DEFAULT 0,
  `date` int(11) UNSIGNED DEFAULT 0,
  `family` int(11) UNSIGNED DEFAULT 0,
  `url` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Ghimire_languages`
--

CREATE TABLE `Ghimire_languages` (
  `id` int(11) NOT NULL,
  `language` varchar(100) DEFAULT NULL,
  `short` varchar(4) DEFAULT NULL,
  `isdefault` tinyint(1) NOT NULL,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `content` longtext DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Dumping data for table `Ghimire_languages`
--

INSERT INTO `Ghimire_languages` (`id`, `language`, `short`, `isdefault`, `created_at`, `updated_at`, `content`) VALUES
(1, 'English', 'us', 0, 1761579644, 1761579644, '{\"rtl\":\"rtl_false\",\"lang\":\"en\",\"success\":\"Success!\",\"error\":\"Error!\",\"rip\":\"R.I.P\",\"no-result\":\"No Result Found!\",\"submit\":\"Submit\",\"close\":\"Close\",\"header\":{\"welcome\":\"Welcome!\",\"search\":\"Search for family...\",\"home\":\"Home\",\"family\":\"Family Trees\",\"plans\":\"Plans\",\"about\":\"About Us\",\"contact\":\"Contact Us\",\"details\":\"Your Details\",\"logout\":\"Logout!\",\"no-not\":\"No notifications\",\"newtree\":\"Create a tree\",\"dashboard\":\"Dashboard\",\"users\":\"Users\",\"fam\":\"Family Tree\",\"fammanag\":\"Managers (Only Usernames):\",\"emailver\":\"Email verification:\"},\"plans\":{\"title\":\"Simple Pricing for Everyone!\",\"desc\":\"Pricing is built for businesses of all sizes. Always know what you\'ll pay. [br]All plans come with a 100% money-back guarantee.\",\"month\":\"\\/per month\",\"btn\":\"Get Started\"},\"indexpage\":{\"h4\":\"Building Family Tree.\",\"h2\":\"Who are they?\",\"p\":\"Make your family tree live with Ghimire Family Tree and do not leave it just a memory hanging. build it with the participation of everyone and make it stretch to infinity.\",\"form_b\":\"More than just a family tree.\",\"form_s\":\"A new home for family memories\",\"form_login\":\"Login\",\"form_register\":\"Register\",\"form_fid_l\":\"Family ID:\",\"form_fid_i\":\"Write your family ID\",\"form_pass_l\":\"Password:\",\"form_pass_i\":\"Write your password\",\"form_npass_l\":\"New Password:\",\"form_npass_i\":\"Write your new password\",\"form_vpass_l\":\"View Password:\",\"form_vpass_i\":\"Write your view password\",\"form_email_l\":\"Email:\",\"form_email_i\":\"Write your email\",\"form_in\":\"Sign In\",\"form_up\":\"Sign Up\",\"form_view\":\"Can everyone see this family (public view)\",\"my\":\"My Family Tree\",\"list\":\"List Of the trees you manage!\",\"more\":\"More Results!\",\"forget\":\"Forget your password?\",\"reset\":\"Reset it now\",\"pravicy\":\"Pravicy policy\",\"byclick\":\"By clicking in \'Sign up\' button you are automaticly accepting in our {a}, don\'t hasitate to read it first!\"},\"treepage\":{\"vp_t\":\"View Password :\",\"vp_p\":\"We are sorry to inform you that, this family isn\'t public view. you need to have password view to show it.\",\"vp_i\":\"Write the view password\",\"vp_b\":\"Submit\",\"edit\":\"Edit\",\"new\":\"New Member\",\"link\":\"Tree Link\",\"fam\":\"\'s Family Tree:\",\"share\":\"Share\",\"share_f\":\"Share on Facebook\",\"share_t\":\"Share on Twitter\",\"share_w\":\"Share on Whatsapp\",\"share_e\":\"Send in Email\",\"pdf\":\"Export PDF\"},\"heritage\":{\"title\":\"Heritage a family :\",\"link\":\"Link this momber as a parent of family:\"},\"detailspage\":{\"title\":\"Manege your details\",\"send\":\"Send Details\",\"username\":\"Your Username\",\"username_l\":\"Write your username\",\"image_n\":\"No image chosen...\",\"image_c\":\"Choose Image\"},\"resetpage\":{\"title1\":\"Reset your password:\",\"email\":\"Your Registred Email Address\",\"title\":\"Reset new password :\",\"npass\":\"New Password       :\",\"npass_l\":\"type your password\",\"rpass\":\"Re-Password :\",\"rpass_l\":\"type your re-password\"},\"listpage\":{\"title\":\"Famelie Tree List\",\"no-result\":\"No Result Found!\",\"members\":\"Members\",\"my\":\"My Trees\",\"edit\":\"Edit\"},\"timedate\":{\"time_second\":\"second\",\"time_minute\":\"minute\",\"time_hour\":\"hour\",\"time_day\":\"day\",\"time_week\":\"week\",\"time_month\":\"month\",\"time_year\":\"year\",\"time_decade\":\"decade\",\"time_ago\":\"ago\"},\"newmember\":{\"title\":\"Add New member\",\"personal\":\"Personal\",\"contact\":\"Contact\",\"biographical\":\"Biographical\",\"pictures\":\"Pictures\",\"link\":\"Link this member to a user:\",\"first\":\"First Name:\",\"last\":\"Last Name\",\"gender\":\"Gender\",\"female\":\"Female\",\"male\":\"Male\",\"rtype\":\"Relation Type\",\"child\":\"Child\",\"ex\":\"Ex-Partner\",\"parent\":\"Parent\",\"partner\":\"Partner\",\"bdate\":\"Birth Date\",\"mdate\":\"Mariage Date\",\"ddate\":\"Death Date\",\"alive\":\"This person is alive\",\"photo_url\":\"Enter Photo URL\",\"photo\":\"Photo\",\"choose\":\"Choose an image from your device\",\"instead\":\"Or choose an avatar instead\",\"website\":\"Website\",\"tel\":\"Home Tel\",\"mobile\":\"Mobile\",\"bplace\":\"Birth Place\",\"dplace\":\"Death Place\",\"profession\":\"Profession\",\"company\":\"Company\",\"interests\":\"Interests\",\"bio\":\"Bio Notes\",\"photos\":\"Photos\",\"lab1\":\"Enter first name\",\"lab2\":\"Enter last name\",\"lab3\":\"Enter Facebook\",\"lab4\":\"Enter Twitter\",\"lab5\":\"Enter Instagram\",\"lab6\":\"Enter Email\",\"lab7\":\"Enter Website\",\"lab8\":\"Enter Home Tel\",\"lab9\":\"Enter Mobile\",\"lab10\":\"Enter Birth Place\",\"lab11\":\"Enter Death Place\",\"lab12\":\"Enter Profession\",\"lab13\":\"Enter Company\",\"lab14\":\"Enter Interests\",\"lab15\":\"Enter Bio Notes\",\"bornat\":\"Born at\",\"bornin\":\"in\",\"deadat\":\"Dead at\",\"marriageat\":\"Marriage at\"},\"alerts\":{\"required\":\"All fields are required!\",\"login\":\"You have login succesfully!\",\"viewp\":\"View password is incorrect!\",\"her_1\":\"you can\'t herirate this family beacause it isn\'t yours!\",\"her_2\":\"you can\'t herirate a family twise in the same tree!\",\"her_3\":\"you can\'t herirate this family beacause it isn\'t public!\",\"her_4\":\"you can\'t herirate this family!\",\"alldone\":\"Success, all done!\",\"famexist\":\"This family is already exist!\",\"name\":\"Name is required!\",\"wrong\":\"something wrong!\",\"correctemail\":\"You need a correct email address!\",\"existemail\":\"This Email is already exist!\",\"existusername\":\"This Username is already exist!\",\"regsuccess\":\"Your have being registred succesfuly.\",\"regsuccess1\":\"Your have being registred succesfuly, but we sent you an email for verification!\",\"regsuccess2\":\"Your have being registred succesfuly, but need to be accepted by administration!\",\"famsuccess\":\"Your family ID has created succesfully!\",\"logsuccess\":\"You have login succesfully!\",\"logapprov\":\"this user needs approval by administration before sign in!\",\"logverif\":\"this user needs to verify by email address!\",\"logerror\":\"Family ID or password is incorrect!\",\"reseterror\":\"There is no user with this info!\",\"resetsuccess\":\"The resset password sent succcesfuly.\",\"pass1\":\"password more than 6 letters\",\"pass2\":\"password don\'t match repassword\",\"pass3\":\"you can login now with this new password\",\"nodata\":\"No data found!\",\"emailver\":\"All right, you can login now.\",\"families\":\"Your number of families that you can add for the plan you have is expired, please upgrade your plan for more!\",\"heritage\":\"You don\'t have permission to heritage using the plan you have, please upgrade your plan for more!\",\"members\":\"Your number of members per family that you can add for the plan you have is expired, please upgrade your plan for more!\",\"albums\":\"You don\'t have permission to add photos in albums using the plan you have, please upgrade your plan for more!\",\"permission\":\"You have no permission for accessing to this page!\",\"payment\":\"Payment success!\",\"payment_f\":\"Failed to retrieve payment from PayPal!\",\"logout\":\"Are you sure you want to logout?\",\"nofile\":\"No file chosen...\",\"de_mem\":\"Are you sure you want to delete this memebr?\"},\"dashboard\":{\"hello\":\"Hello,\",\"welcome\":\"Welcome back again to your dashboard.\",\"families\":\"Families\",\"users\":\"Users\",\"responses\":\"Members\",\"questions\":\"Images\",\"days\":\"Days\",\"months\":\"Months\",\"new_u\":\"New Users (24h)\",\"latest_f\":\"Latest Families\",\"latest_m\":\"Latest Members\",\"save\":\"Save\",\"p_disacticate\":\"Disable plans option\",\"status\":\"Status\",\"name\":\"name\",\"public\":\"public\",\"members\":\"members\",\"moderators\":\"moderators\",\"date\":\"Date\",\"edit\":\"Edit\",\"delete\":\"Delete\",\"u_users\":\"Members\",\"u_status\":\"Status\",\"u_username\":\"Username\",\"verification\":\"Verification\",\"u_registred\":\"Registred at\",\"u_updated\":\"Updated at\",\"u_delete\":\"Delete User\",\"u_edit\":\"Edit User\",\"u_create\":\"Create a User\",\"u_pages\":\"Pages\",\"npage\":\"New Page\",\"title\":\"Title\",\"inmenu\":\"in Menu\",\"created\":\"Created\",\"p_title\":\"Payments\",\"p_user\":\"User\",\"u_plan\":\"Plan\",\"p_amount\":\"Amount\",\"p_paymentid\":\"Payment ID\",\"p_payerid\":\"Payer ID\",\"created_at\":\"Created At\",\"set_title\":\"General Settings\",\"set_stitle\":\"Site title:\",\"set_keys\":\"Site keywords:\",\"set_desc\":\"Site Description:\",\"set_url\":\"Site URL:\",\"regstatus\":\"Registration Status:\",\"byemail\":\"By Email\",\"mneedsapproval\":\"Need Approval Without Email\",\"open\":\"Open\",\"hidereg\":\"Hide registration form\",\"fneedsapproval\":\"Families needs approval before being live\",\"colors\":\"Colors\",\"ptitle\":\"Page Title\",\"picon\":\"Page Icon\",\"pcontent\":\"Page Content\",\"dmenu\":\"Display it in menu\",\"stats_line_d\":\"Statistics for the last 7 days\",\"stats_line_m\":\"Statistics for this year\",\"planalert\":\"The plans have been saved successfully.\"}}'),
(2, 'Nepali', 'np', 1, 1761579644, 1761579644, '{\"rtl\":\"rtl_false\",\"lang\":\"np\",\"success\":\"à¤¸à¤«à¤² à¤­à¤¯à¥‹!\",\"error\":\"à¤¤à¥à¤°à¥à¤Ÿà¤¿!\",\"rip\":\"à¤¸à¥à¤µà¤°à¥à¤—à¤¿à¤¯ à¤†à¤¤à¥à¤®à¤¾à¤²à¤¾à¤ˆ à¤ˆà¤¶à¥à¤µà¤°à¤•à¥‹ à¤¶à¤¾à¤¨à¥à¤¤à¤¿ à¤®à¤¿à¤²à¥‹à¤¸à¥\",\"no-result\":\"à¤•à¥à¤¨à¥ˆ à¤ªà¤°à¤¿à¤£à¤¾à¤® à¤«à¥‡à¤²à¤¾ à¤ªà¤°à¥‡à¤¨!\",\"submit\":\"à¤ªà¥‡à¤¶ à¤—à¤°à¥à¤¨à¥à¤¹à¥‹à¤¸à¥\",\"close\":\"à¤¬à¤¨à¥à¤¦ à¤—à¤°à¥à¤¨à¥à¤¹à¥‹à¤¸à¥\",\"header\":{\"welcome\":\"à¤¸à¥à¤µà¤¾à¤—à¤¤à¤®à¥!\",\"search\":\"à¤ªà¤°à¤¿à¤µà¤¾à¤° à¤–à¥‹à¤œà¥à¤¨à¥à¤¹à¥‹à¤¸à¥...\",\"home\":\"à¤—à¥ƒà¤¹\",\"family\":\"à¤µà¤‚à¤¶à¤µà¥ƒà¤•à¥à¤·à¤¹à¤°à¥‚\",\"plans\":\"à¤¯à¥‹à¤œà¤¨à¤¾à¤¹à¤°à¥‚\",\"about\":\"à¤¹à¤¾à¤®à¥à¤°à¥‹ à¤¬à¤¾à¤°à¥‡\",\"contact\":\"à¤¹à¤¾à¤®à¥à¤°à¥‹ à¤¸à¤®à¥à¤ªà¤°à¥à¤•\",\"details\":\"à¤¤à¤ªà¤¾à¤ˆà¤‚à¤•à¥‹ à¤µà¤¿à¤µà¤°à¤£à¤¹à¤°à¥‚\",\"logout\":\"à¤²à¤—à¤†à¤‰à¤Ÿ à¤—à¤°à¥à¤¨à¥à¤¹à¥‹à¤¸à¥!\",\"no-not\":\"à¤•à¥à¤¨à¥ˆ à¤¸à¥‚à¤šà¤¨à¤¾à¤¹à¤°à¥‚ à¤›à¥ˆà¤¨à¤¨à¥\",\"newtree\":\"à¤µà¤‚à¤¶à¤µà¥ƒà¤•à¥à¤· à¤¸à¤¿à¤°à¥à¤œà¤¨à¤¾ à¤—à¤°à¥à¤¨à¥à¤¹à¥‹à¤¸à¥\",\"dashboard\":\"à¤¡à¥à¤¯à¤¾à¤¸à¤¬à¥‹à¤°à¥à¤¡\",\"users\":\"à¤ªà¥à¤°à¤¯à¥‹à¤—à¤•à¤°à¥à¤¤à¤¾à¤¹à¤°à¥‚\",\"fam\":\"à¤µà¤‚à¤¶à¤µà¥ƒà¤•à¥à¤·\",\"fammanag\":\"à¤ªà¥à¤°à¤¬à¤¨à¥à¤§à¤•à¤¹à¤°à¥‚ (à¤•à¥‡à¤µà¤² à¤ªà¥à¤°à¤¯à¥‹à¤—à¤•à¤°à¥à¤¤à¤¾ à¤¨à¤¾à¤®à¤¹à¤°à¥‚):\",\"emailver\":\"à¤‡à¤®à¥‡à¤² à¤ªà¥à¤°à¤®à¤¾à¤£à¥€à¤•à¤°à¤£:\"},\"plans\":{\"title\":\"à¤¸à¤¬à¥ˆà¤•à¥‹ à¤²à¤¾à¤—à¤¿ à¤¸à¤°à¤² à¤®à¥‚à¤²à¥à¤¯ à¤¨à¤¿à¤°à¥à¤§à¤¾à¤°à¤£!\",\"desc\":\"à¤®à¥‚à¤²à¥à¤¯ à¤¨à¤¿à¤°à¥à¤§à¤¾à¤°à¤£ à¤¸à¤¬à¥ˆ à¤†à¤•à¤¾à¤°à¤•à¤¾ à¤µà¥à¤¯à¤µà¤¸à¤¾à¤¯à¤¹à¤°à¥‚à¤•à¥‹ à¤²à¤¾à¤—à¤¿ à¤¨à¤¿à¤°à¥à¤®à¤¿à¤¤ à¤›à¥¤ à¤¤à¤ªà¤¾à¤ˆà¤‚à¤²à¥‡ à¤•à¥‡ à¤¤à¤¿à¤°à¥à¤¨à¥à¤¹à¥à¤¨à¥‡à¤› à¤­à¤¨à¥à¤¨à¥‡ à¤•à¥à¤°à¤¾ à¤¸à¤§à¥ˆà¤‚ à¤œà¤¾à¤¨à¥à¤¨à¥à¤¹à¥‹à¤¸à¥à¥¤ [br]à¤¸à¤¬à¥ˆ à¤¯à¥‹à¤œà¤¨à¤¾à¤¹à¤°à¥‚ à¥§à¥¦à¥¦% à¤ªà¥ˆà¤¸à¤¾ à¤«à¤¿à¤°à¥à¤¤à¤¾ à¤—à¥à¤¯à¤¾à¤°à¥‡à¤¨à¥à¤Ÿà¥€à¤•à¥‹ à¤¸à¤¾à¤¥ à¤†à¤‰à¤à¤›à¤¨à¥à¥¤\",\"month\":\"\\/à¤ªà¥à¤°à¤¤à¤¿ à¤®à¤¹à¤¿à¤¨à¤¾\",\"btn\":\"à¤¸à¥à¤°à¥ à¤—à¤°à¥à¤¨à¥à¤¹à¥‹à¤¸à¥\"},\"indexpage\":{\"h4\":\"à¤µà¤‚à¤¶à¤µà¥ƒà¤•à¥à¤· à¤¨à¤¿à¤°à¥à¤®à¤¾à¤£ à¤—à¤°à¥à¤¦à¥ˆà¥¤\",\"h2\":\"à¤¤à¤¿à¤¨à¥€à¤¹à¤°à¥‚ à¤•à¥‹ à¤¹à¥à¤¨à¥?\",\"p\":\"à¤†à¤«à¥à¤¨à¥‹ à¤µà¤‚à¤¶à¤µà¥ƒà¤•à¥à¤·à¤²à¤¾à¤ˆ à¤˜à¤¿à¤®à¤¿à¤°à¥‡ à¤µà¤‚à¤¶à¤µà¥ƒà¤•à¥à¤·à¤¸à¤à¤— à¤œà¥€à¤µà¤¿à¤¤ à¤¬à¤¨à¤¾à¤‰à¤¨à¥à¤¹à¥‹à¤¸à¥ à¤° à¤¯à¤¸à¤²à¤¾à¤ˆ à¤à¥à¤¨à¥à¤¡à¤¿à¤à¤•à¥‹ à¤¸à¥à¤®à¥ƒà¤¤à¤¿ à¤®à¤¾à¤¤à¥à¤° à¤¨à¤›à¥‹à¤¡à¥à¤¨à¥à¤¹à¥‹à¤¸à¥à¥¤ à¤¸à¤¬à¥ˆà¤•à¥‹ à¤¸à¤¹à¤­à¤¾à¤—à¤¿à¤¤à¤¾à¤®à¤¾ à¤¯à¤¸à¤²à¤¾à¤ˆ à¤¨à¤¿à¤°à¥à¤®à¤¾à¤£ à¤—à¤°à¥à¤¨à¥à¤¹à¥‹à¤¸à¥ à¤° à¤¯à¤¸à¤²à¤¾à¤ˆ à¤…à¤¨à¤¨à¥à¤¤à¤¤à¤¾à¤¸à¤®à¥à¤® à¤«à¥ˆà¤²à¤¾à¤‰à¤¨à¥à¤¹à¥‹à¤¸à¥à¥¤\",\"form_b\":\"à¤•à¥‡à¤µà¤² à¤µà¤‚à¤¶à¤µà¥ƒà¤•à¥à¤· à¤­à¤¨à¥à¤¦à¤¾ à¤¬à¤¢à¥€à¥¤\",\"form_s\":\"à¤ªà¤°à¤¿à¤µà¤¾à¤°à¤•à¤¾ à¤¸à¥à¤®à¥ƒà¤¤à¤¿à¤¹à¤°à¥‚à¤•à¥‹ à¤²à¤¾à¤—à¤¿ à¤¨à¤¯à¤¾à¤ à¤˜à¤°\",\"form_login\":\"à¤²à¤—à¤‡à¤¨\",\"form_register\":\"à¤¦à¤°à¥à¤¤à¤¾ à¤—à¤°à¥à¤¨à¥à¤¹à¥‹à¤¸à¥\",\"form_fid_l\":\"à¤ªà¤°à¤¿à¤µà¤¾à¤° à¤†à¤ˆà¤¡à¥€:\",\"form_fid_i\":\"à¤†à¤«à¥à¤¨à¥‹ à¤ªà¤°à¤¿à¤µà¤¾à¤° à¤†à¤ˆà¤¡à¥€ à¤²à¥‡à¤–à¥à¤¨à¥à¤¹à¥‹à¤¸à¥\",\"form_pass_l\":\"à¤ªà¤¾à¤¸à¤µà¤°à¥à¤¡:\",\"form_pass_i\":\"à¤†à¤«à¥à¤¨à¥‹ à¤ªà¤¾à¤¸à¤µà¤°à¥à¤¡ à¤²à¥‡à¤–à¥à¤¨à¥à¤¹à¥‹à¤¸à¥\",\"form_npass_l\":\"à¤¨à¤¯à¤¾à¤ à¤ªà¤¾à¤¸à¤µà¤°à¥à¤¡:\",\"form_npass_i\":\"à¤†à¤«à¥à¤¨à¥‹ à¤¨à¤¯à¤¾à¤ à¤ªà¤¾à¤¸à¤µà¤°à¥à¤¡ à¤²à¥‡à¤–à¥à¤¨à¥à¤¹à¥‹à¤¸à¥\",\"form_vpass_l\":\"à¤¹à¥‡à¤°à¥à¤¨à¥‡ à¤ªà¤¾à¤¸à¤µà¤°à¥à¤¡:\",\"form_vpass_i\":\"à¤¹à¥‡à¤°à¥à¤¨à¥‡ à¤ªà¤¾à¤¸à¤µà¤°à¥à¤¡ à¤²à¥‡à¤–à¥à¤¨à¥à¤¹à¥‹à¤¸à¥\",\"form_email_l\":\"à¤‡à¤®à¥‡à¤²:\",\"form_email_i\":\"à¤‡à¤®à¥‡à¤² à¤²à¥‡à¤–à¥à¤¨à¥à¤¹à¥‹à¤¸à¥\",\"form_in\":\"à¤¸à¤¾à¤‡à¤¨ à¤‡à¤¨\",\"form_up\":\"à¤¸à¤¾à¤‡à¤¨ à¤…à¤ª\",\"form_view\":\"à¤•à¥‡ à¤¸à¤¬à¥ˆà¤²à¥‡ à¤¯à¥‹ à¤ªà¤°à¤¿à¤µà¤¾à¤° à¤¹à¥‡à¤°à¥à¤¨ à¤¸à¤•à¥à¤›à¤¨à¥ (à¤¸à¤¾à¤°à¥à¤µà¤œà¤¨à¤¿à¤• à¤¦à¥ƒà¤¶à¥à¤¯)\",\"my\":\"à¤®à¥‡à¤°à¥‹ à¤µà¤‚à¤¶à¤µà¥ƒà¤•à¥à¤·\",\"list\":\"à¤¤à¤ªà¤¾à¤ˆà¤‚à¤²à¥‡ à¤µà¥à¤¯à¤µà¤¸à¥à¤¥à¤¾à¤ªà¤¨ à¤—à¤°à¥à¤¨à¥à¤­à¤à¤•à¤¾ à¤µà¥ƒà¤•à¥à¤·à¤¹à¤°à¥‚à¤•à¥‹ à¤¸à¥‚à¤šà¥€!\",\"more\":\"à¤¥à¤ª à¤¨à¤¤à¤¿à¤œà¤¾à¤¹à¤°à¥‚!\",\"forget\":\"à¤ªà¤¾à¤¸à¤µà¤°à¥à¤¡ à¤¬à¤¿à¤°à¥à¤¸à¤¨à¥à¤­à¤¯à¥‹?\",\"reset\":\"à¤…à¤¬ à¤°à¤¿à¤¸à¥‡à¤Ÿ à¤—à¤°à¥à¤¨à¥à¤¹à¥‹à¤¸à¥\",\"pravicy\":\"à¤—à¥‹à¤ªà¤¨à¥€à¤¯à¤¤à¤¾ à¤¨à¥€à¤¤à¤¿\",\"byclick\":\"\'à¤¸à¤¾à¤‡à¤¨ à¤…à¤ª\' à¤¬à¤Ÿà¤¨à¤®à¤¾ à¤•à¥à¤²à¤¿à¤• à¤—à¤°à¥‡à¤° à¤¤à¤ªà¤¾à¤ˆà¤‚ à¤¸à¥à¤µà¤šà¤¾à¤²à¤¿à¤¤ à¤°à¥‚à¤ªà¤®à¤¾ à¤¹à¤¾à¤®à¥à¤°à¥‹ {a} à¤®à¤¾ à¤¸à¥à¤µà¥€à¤•à¤¾à¤° à¤—à¤°à¥à¤¦à¥ˆ à¤¹à¥à¤¨à¥à¤¹à¥à¤¨à¥à¤›, à¤ªà¤¹à¤¿à¤²à¥‡ à¤¯à¤¸à¤²à¤¾à¤ˆ à¤ªà¤¢à¥à¤¨ à¤¹à¤šà¥à¤•à¤¿à¤šà¤¾à¤‰à¤¨à¥à¤¹à¥‹à¤¸à¥!\"},\"treepage\":{\"vp_t\":\"à¤¹à¥‡à¤°à¥à¤¨à¥‡ à¤ªà¤¾à¤¸à¤µà¤°à¥à¤¡ :\",\"vp_p\":\"à¤¹à¤¾à¤®à¥€à¤²à¤¾à¤ˆ à¤¦à¥à¤ƒà¤– à¤²à¤¾à¤—à¥‡à¤° à¤­à¤¨à¥à¤¨à¥à¤ªà¤°à¥à¤¦à¤› à¤•à¤¿, à¤¯à¥‹ à¤ªà¤°à¤¿à¤µà¤¾à¤° à¤¸à¤¾à¤°à¥à¤µà¤œà¤¨à¤¿à¤• à¤¦à¥ƒà¤¶à¥à¤¯ à¤¹à¥‹à¤‡à¤¨à¥¤ à¤¯à¤¸à¤²à¤¾à¤ˆ à¤¦à¥‡à¤–à¤¾à¤‰à¤¨ à¤¤à¤ªà¤¾à¤ˆà¤‚à¤¸à¤à¤— à¤¹à¥‡à¤°à¥à¤¨à¥‡ à¤ªà¤¾à¤¸à¤µà¤°à¥à¤¡ à¤¹à¥à¤¨à¥ à¤†à¤µà¤¶à¥à¤¯à¤• à¤›à¥¤\",\"vp_i\":\"à¤¹à¥‡à¤°à¥à¤¨à¥‡ à¤ªà¤¾à¤¸à¤µà¤°à¥à¤¡ à¤²à¥‡à¤–à¥à¤¨à¥à¤¹à¥‹à¤¸à¥\",\"vp_b\":\"à¤ªà¥‡à¤¶ à¤—à¤°à¥à¤¨à¥à¤¹à¥‹à¤¸à¥\",\"edit\":\"à¤¸à¤®à¥à¤ªà¤¾à¤¦à¤¨ à¤—à¤°à¥à¤¨à¥à¤¹à¥‹à¤¸à¥\",\"new\":\"à¤¨à¤¯à¤¾à¤ à¤¸à¤¦à¤¸à¥à¤¯\",\"link\":\"à¤µà¥ƒà¤•à¥à¤· à¤²à¤¿à¤™à¥à¤•\",\"fam\":\"à¤•à¥‹ à¤µà¤‚à¤¶à¤µà¥ƒà¤•à¥à¤·:\",\"share\":\"à¤¸à¥‡à¤¯à¤° à¤—à¤°à¥à¤¨à¥à¤¹à¥‹à¤¸à¥\",\"share_f\":\"à¤«à¥‡à¤¸à¤¬à¥à¤•à¤®à¤¾ à¤¸à¥‡à¤¯à¤° à¤—à¤°à¥à¤¨à¥à¤¹à¥‹à¤¸à¥\",\"share_t\":\"à¤Ÿà¥à¤µà¤¿à¤Ÿà¤°à¤®à¤¾ à¤¸à¥‡à¤¯à¤° à¤—à¤°à¥à¤¨à¥à¤¹à¥‹à¤¸à¥\",\"share_w\":\"à¤µà¥à¤¹à¤¾à¤Ÿà¥à¤¸à¤à¤ªà¤®à¤¾ à¤¸à¥‡à¤¯à¤° à¤—à¤°à¥à¤¨à¥à¤¹à¥‹à¤¸à¥\",\"share_e\":\"à¤‡à¤®à¥‡à¤²à¤®à¤¾ à¤ªà¤ à¤¾à¤‰à¤¨à¥à¤¹à¥‹à¤¸à¥\",\"pdf\":\"PDF à¤¨à¤¿à¤°à¥à¤¯à¤¾à¤¤ à¤—à¤°à¥à¤¨à¥à¤¹à¥‹à¤¸à¥\"},\"heritage\":{\"title\":\"à¤ªà¤°à¤¿à¤µà¤¾à¤°à¤•à¥‹ à¤µà¤¿à¤°à¤¾à¤¸à¤¤ :\",\"link\":\"à¤¯à¤¸ à¤¸à¤¦à¤¸à¥à¤¯à¤²à¤¾à¤ˆ à¤ªà¤°à¤¿à¤µà¤¾à¤°à¤•à¥‹ à¤…à¤­à¤¿à¤­à¤¾à¤µà¤•à¤•à¥‹ à¤°à¥‚à¤ªà¤®à¤¾ à¤²à¤¿à¤™à¥à¤• à¤—à¤°à¥à¤¨à¥à¤¹à¥‹à¤¸à¥:\"},\"detailspage\":{\"title\":\"à¤†à¤«à¥à¤¨à¤¾ à¤µà¤¿à¤µà¤°à¤£à¤¹à¤°à¥‚ à¤µà¥à¤¯à¤µà¤¸à¥à¤¥à¤¾à¤ªà¤¨ à¤—à¤°à¥à¤¨à¥à¤¹à¥‹à¤¸à¥\",\"send\":\"à¤µà¤¿à¤µà¤°à¤£à¤¹à¤°à¥‚ à¤ªà¤ à¤¾à¤‰à¤¨à¥à¤¹à¥‹à¤¸à¥\",\"username\":\"à¤¤à¤ªà¤¾à¤ˆà¤‚à¤•à¥‹ à¤ªà¥à¤°à¤¯à¥‹à¤—à¤•à¤°à¥à¤¤à¤¾ à¤¨à¤¾à¤®\",\"username_l\":\"à¤†à¤«à¥à¤¨à¥‹ à¤ªà¥à¤°à¤¯à¥‹à¤—à¤•à¤°à¥à¤¤à¤¾ à¤¨à¤¾à¤® à¤²à¥‡à¤–à¥à¤¨à¥à¤¹à¥‹à¤¸à¥\",\"image_n\":\"à¤•à¥à¤¨à¥ˆ à¤›à¤µà¤¿ à¤šà¤¯à¤¨ à¤—à¤°à¤¿à¤à¤•à¥‹ à¤›à¥ˆà¤¨...\",\"image_c\":\"à¤›à¤µà¤¿ à¤šà¤¯à¤¨ à¤—à¤°à¥à¤¨à¥à¤¹à¥‹à¤¸à¥\"},\"resetpage\":{\"title1\":\"à¤†à¤«à¥à¤¨à¥‹ à¤ªà¤¾à¤¸à¤µà¤°à¥à¤¡ à¤°à¤¿à¤¸à¥‡à¤Ÿ à¤—à¤°à¥à¤¨à¥à¤¹à¥‹à¤¸à¥:\",\"email\":\"à¤¤à¤ªà¤¾à¤ˆà¤‚à¤•à¥‹ à¤¦à¤°à¥à¤¤à¤¾ à¤­à¤à¤•à¥‹ à¤‡à¤®à¥‡à¤² à¤ à¥‡à¤—à¤¾à¤¨à¤¾\",\"title\":\"à¤¨à¤¯à¤¾à¤ à¤ªà¤¾à¤¸à¤µà¤°à¥à¤¡ à¤°à¤¿à¤¸à¥‡à¤Ÿ à¤—à¤°à¥à¤¨à¥à¤¹à¥‹à¤¸à¥ :\",\"npass\":\"à¤¨à¤¯à¤¾à¤ à¤ªà¤¾à¤¸à¤µà¤°à¥à¤¡       :\",\"npass_l\":\"à¤†à¤«à¥à¤¨à¥‹ à¤ªà¤¾à¤¸à¤µà¤°à¥à¤¡ à¤Ÿà¤¾à¤‡à¤ª à¤—à¤°à¥à¤¨à¥à¤¹à¥‹à¤¸à¥\",\"rpass\":\"à¤ªà¥à¤¨à¤ƒ-à¤ªà¤¾à¤¸à¤µà¤°à¥à¤¡ :\",\"rpass_l\":\"à¤†à¤«à¥à¤¨à¥‹ à¤ªà¥à¤¨à¤ƒ-à¤ªà¤¾à¤¸à¤µà¤°à¥à¤¡ à¤Ÿà¤¾à¤‡à¤ª à¤—à¤°à¥à¤¨à¥à¤¹à¥‹à¤¸à¥\"},\"listpage\":{\"title\":\"à¤µà¤‚à¤¶à¤µà¥ƒà¤•à¥à¤· à¤¸à¥‚à¤šà¥€\",\"no-result\":\"à¤•à¥à¤¨à¥ˆ à¤ªà¤°à¤¿à¤£à¤¾à¤® à¤«à¥‡à¤²à¤¾ à¤ªà¤°à¥‡à¤¨!\",\"members\":\"à¤¸à¤¦à¤¸à¥à¤¯à¤¹à¤°à¥‚\",\"my\":\"à¤®à¥‡à¤°à¤¾ à¤µà¥ƒà¤•à¥à¤·à¤¹à¤°à¥‚\",\"edit\":\"à¤¸à¤®à¥à¤ªà¤¾à¤¦à¤¨ à¤—à¤°à¥à¤¨à¥à¤¹à¥‹à¤¸à¥\"},\"timedate\":{\"time_second\":\"à¤¸à¥‡à¤•à¥‡à¤¨à¥à¤¡\",\"time_minute\":\"à¤®à¤¿à¤¨à¥‡à¤Ÿ\",\"time_hour\":\"à¤˜à¤£à¥à¤Ÿà¤¾\",\"time_day\":\"à¤¦à¤¿à¤¨\",\"time_week\":\"à¤¹à¤ªà¥à¤¤à¤¾\",\"time_month\":\"à¤®à¤¹à¤¿à¤¨à¤¾\",\"time_year\":\"à¤µà¤°à¥à¤·\",\"time_decade\":\"à¤¦à¤¶à¤•\",\"time_ago\":\"à¤…à¤˜à¤¿\"},\"newmember\":{\"title\":\"à¤¨à¤¯à¤¾à¤ à¤¸à¤¦à¤¸à¥à¤¯ à¤¥à¤ªà¥à¤¨à¥à¤¹à¥‹à¤¸à¥\",\"personal\":\"à¤µà¥à¤¯à¤•à¥à¤¤à¤¿à¤—à¤¤\",\"contact\":\"à¤¸à¤®à¥à¤ªà¤°à¥à¤•\",\"biographical\":\"à¤œà¥€à¤µà¤¨à¥€à¤¸à¤®à¥à¤¬à¤¨à¥à¤§à¥€\",\"pictures\":\"à¤¤à¤¸à¥à¤¬à¥€à¤°à¤¹à¤°à¥‚\",\"link\":\"à¤¯à¤¸ à¤¸à¤¦à¤¸à¥à¤¯à¤²à¤¾à¤ˆ à¤ªà¥à¤°à¤¯à¥‹à¤—à¤•à¤°à¥à¤¤à¤¾à¤¸à¤à¤— à¤²à¤¿à¤™à¥à¤• à¤—à¤°à¥à¤¨à¥à¤¹à¥‹à¤¸à¥:\",\"first\":\"à¤ªà¤¹à¤¿à¤²à¥‹ à¤¨à¤¾à¤®:\",\"last\":\"à¤¥à¤°\",\"gender\":\"à¤²à¤¿à¤™à¥à¤—\",\"female\":\"à¤®à¤¹à¤¿à¤²à¤¾\",\"male\":\"à¤ªà¥à¤°à¥à¤·\",\"rtype\":\"à¤¸à¤®à¥à¤¬à¤¨à¥à¤§ à¤ªà¥à¤°à¤•à¤¾à¤°\",\"child\":\"à¤¸à¤¨à¥à¤¤à¤¾à¤¨\",\"ex\":\"à¤ªà¥‚à¤°à¥à¤µ-à¤¸à¤¾à¤¥à¥€\",\"parent\":\"à¤…à¤­à¤¿à¤­à¤¾à¤µà¤•\",\"partner\":\"à¤¸à¤¾à¤¥à¥€\",\"bdate\":\"à¤œà¤¨à¥à¤® à¤®à¤¿à¤¤à¤¿\",\"mdate\":\"à¤µà¤¿à¤µà¤¾à¤¹ à¤®à¤¿à¤¤à¤¿\",\"ddate\":\"à¤®à¥ƒà¤¤à¥à¤¯à¥ à¤®à¤¿à¤¤à¤¿\",\"alive\":\"à¤¯à¥‹ à¤µà¥à¤¯à¤•à¥à¤¤à¤¿ à¤œà¥€à¤µà¤¿à¤¤ à¤›\",\"photo_url\":\"à¤«à¥‹à¤Ÿà¥‹ URL à¤ªà¥à¤°à¤µà¤¿à¤·à¥à¤Ÿ à¤—à¤°à¥à¤¨à¥à¤¹à¥‹à¤¸à¥\",\"photo\":\"à¤«à¥‹à¤Ÿà¥‹\",\"choose\":\"à¤†à¤«à¥à¤¨à¥‹ à¤‰à¤ªà¤•à¤°à¤£à¤¬à¤¾à¤Ÿ à¤à¤‰à¤Ÿà¤¾ à¤›à¤µà¤¿ à¤šà¤¯à¤¨ à¤—à¤°à¥à¤¨à¥à¤¹à¥‹à¤¸à¥\",\"instead\":\"à¤µà¤¾ à¤¸à¤Ÿà¥à¤Ÿà¤¾à¤®à¤¾ à¤à¤‰à¤Ÿà¤¾ à¤…à¤µà¤¤à¤¾à¤° à¤šà¤¯à¤¨ à¤—à¤°à¥à¤¨à¥à¤¹à¥‹à¤¸à¥\",\"website\":\"à¤µà¥‡à¤¬à¤¸à¤¾à¤‡à¤Ÿ\",\"tel\":\"à¤˜à¤° à¤Ÿà¥‡à¤²\",\"mobile\":\"à¤®à¥‹à¤¬à¤¾à¤‡à¤²\",\"bplace\":\"à¤œà¤¨à¥à¤® à¤¸à¥à¤¥à¤¾à¤¨\",\"dplace\":\"à¤®à¥ƒà¤¤à¥à¤¯à¥ à¤¸à¥à¤¥à¤¾à¤¨\",\"profession\":\"à¤ªà¥‡à¤¶à¤¾\",\"company\":\"à¤•à¤®à¥à¤ªà¤¨à¥€\",\"interests\":\"à¤°à¥à¤šà¤¿à¤¹à¤°à¥‚\",\"bio\":\"à¤œà¥€à¤µà¤¨à¥€ à¤¨à¥‹à¤Ÿà¤¹à¤°à¥‚\",\"photos\":\"à¤¤à¤¸à¥à¤¬à¥€à¤°à¤¹à¤°à¥‚\",\"lab1\":\"à¤ªà¤¹à¤¿à¤²à¥‹ à¤¨à¤¾à¤® à¤ªà¥à¤°à¤µà¤¿à¤·à¥à¤Ÿ à¤—à¤°à¥à¤¨à¥à¤¹à¥‹à¤¸à¥\",\"lab2\":\"à¤¥à¤° à¤ªà¥à¤°à¤µà¤¿à¤·à¥à¤Ÿ à¤—à¤°à¥à¤¨à¥à¤¹à¥‹à¤¸à¥\",\"lab3\":\"à¤«à¥‡à¤¸à¤¬à¥à¤• à¤ªà¥à¤°à¤µà¤¿à¤·à¥à¤Ÿ à¤—à¤°à¥à¤¨à¥à¤¹à¥‹à¤¸à¥\",\"lab4\":\"à¤Ÿà¥à¤µà¤¿à¤Ÿà¤° à¤ªà¥à¤°à¤µà¤¿à¤·à¥à¤Ÿ à¤—à¤°à¥à¤¨à¥à¤¹à¥‹à¤¸à¥\",\"lab5\":\"à¤‡à¤¨à¥à¤¸à¥à¤Ÿà¤¾à¤—à¥à¤°à¤¾à¤® à¤ªà¥à¤°à¤µà¤¿à¤·à¥à¤Ÿ à¤—à¤°à¥à¤¨à¥à¤¹à¥‹à¤¸à¥\",\"lab6\":\"à¤‡à¤®à¥‡à¤² à¤ªà¥à¤°à¤µà¤¿à¤·à¥à¤Ÿ à¤—à¤°à¥à¤¨à¥à¤¹à¥‹à¤¸à¥\",\"lab7\":\"à¤µà¥‡à¤¬à¤¸à¤¾à¤‡à¤Ÿ à¤ªà¥à¤°à¤µà¤¿à¤·à¥à¤Ÿ à¤—à¤°à¥à¤¨à¥à¤¹à¥‹à¤¸à¥\",\"lab8\":\"à¤˜à¤° à¤Ÿà¥‡à¤² à¤ªà¥à¤°à¤µà¤¿à¤·à¥à¤Ÿ à¤—à¤°à¥à¤¨à¥à¤¹à¥‹à¤¸à¥\",\"lab9\":\"à¤®à¥‹à¤¬à¤¾à¤‡à¤² à¤ªà¥à¤°à¤µà¤¿à¤·à¥à¤Ÿ à¤—à¤°à¥à¤¨à¥à¤¹à¥‹à¤¸à¥\",\"lab10\":\"à¤œà¤¨à¥à¤® à¤¸à¥à¤¥à¤¾à¤¨ à¤ªà¥à¤°à¤µà¤¿à¤·à¥à¤Ÿ à¤—à¤°à¥à¤¨à¥à¤¹à¥‹à¤¸à¥\",\"lab11\":\"à¤®à¥ƒà¤¤à¥à¤¯à¥ à¤¸à¥à¤¥à¤¾à¤¨ à¤ªà¥à¤°à¤µà¤¿à¤·à¥à¤Ÿ à¤—à¤°à¥à¤¨à¥à¤¹à¥‹à¤¸à¥\",\"lab12\":\"à¤ªà¥‡à¤¶à¤¾ à¤ªà¥à¤°à¤µà¤¿à¤·à¥à¤Ÿ à¤—à¤°à¥à¤¨à¥à¤¹à¥‹à¤¸à¥\",\"lab13\":\"à¤•à¤®à¥à¤ªà¤¨à¥€ à¤ªà¥à¤°à¤µà¤¿à¤·à¥à¤Ÿ à¤—à¤°à¥à¤¨à¥à¤¹à¥‹à¤¸à¥\",\"lab14\":\"à¤°à¥à¤šà¤¿à¤¹à¤°à¥‚ à¤ªà¥à¤°à¤µà¤¿à¤·à¥à¤Ÿ à¤—à¤°à¥à¤¨à¥à¤¹à¥‹à¤¸à¥\",\"lab15\":\"à¤œà¥€à¤µà¤¨à¥€ à¤¨à¥‹à¤Ÿà¤¹à¤°à¥‚ à¤ªà¥à¤°à¤µà¤¿à¤·à¥à¤Ÿ à¤—à¤°à¥à¤¨à¥à¤¹à¥‹à¤¸à¥\",\"bornat\":\"à¤œà¤¨à¥à¤® à¤­à¤à¤•à¥‹\",\"bornin\":\"à¤®à¤¾\",\"deadat\":\"à¤®à¥ƒà¤¤à¥à¤¯à¥ à¤­à¤à¤•à¥‹\",\"marriageat\":\"à¤µà¤¿à¤µà¤¾à¤¹ à¤­à¤à¤•à¥‹\"},\"alerts\":{\"required\":\"à¤¸à¤¬à¥ˆ à¤•à¥à¤·à¥‡à¤¤à¥à¤°à¤¹à¤°à¥‚ à¤†à¤µà¤¶à¥à¤¯à¤• à¤›à¤¨à¥!\",\"login\":\"à¤¤à¤ªà¤¾à¤ˆà¤‚ à¤¸à¤«à¤²à¤¤à¤¾à¤ªà¥‚à¤°à¥à¤µà¤• à¤²à¤—à¤‡à¤¨ à¤—à¤°à¥à¤¨à¥à¤­à¤¯à¥‹!\",\"viewp\":\"à¤¹à¥‡à¤°à¥à¤¨à¥‡ à¤ªà¤¾à¤¸à¤µà¤°à¥à¤¡ à¤—à¤²à¤¤ à¤›!\",\"her_1\":\"à¤¤à¤ªà¤¾à¤ˆà¤‚à¤²à¥‡ à¤¯à¥‹ à¤ªà¤°à¤¿à¤µà¤¾à¤°à¤•à¥‹ à¤µà¤¿à¤°à¤¾à¤¸à¤¤ à¤—à¤°à¥à¤¨ à¤¸à¤•à¥à¤¨à¥à¤¹à¥à¤¨à¥à¤¨ à¤•à¤¿à¤¨à¤­à¤¨à¥‡ à¤¯à¥‹ à¤¤à¤ªà¤¾à¤ˆà¤‚à¤•à¥‹ à¤¹à¥‹à¤‡à¤¨!\",\"her_2\":\"à¤¤à¤ªà¤¾à¤ˆà¤‚à¤²à¥‡ à¤à¤‰à¤Ÿà¥ˆ à¤µà¥ƒà¤•à¥à¤·à¤®à¤¾ à¤¦à¥à¤ˆ à¤ªà¤Ÿà¤• à¤ªà¤°à¤¿à¤µà¤¾à¤°à¤•à¥‹ à¤µà¤¿à¤°à¤¾à¤¸à¤¤ à¤—à¤°à¥à¤¨ à¤¸à¤•à¥à¤¨à¥à¤¹à¥à¤¨à¥à¤¨!\",\"her_3\":\"à¤¤à¤ªà¤¾à¤ˆà¤‚à¤²à¥‡ à¤¯à¥‹ à¤ªà¤°à¤¿à¤µà¤¾à¤°à¤•à¥‹ à¤µà¤¿à¤°à¤¾à¤¸à¤¤ à¤—à¤°à¥à¤¨ à¤¸à¤•à¥à¤¨à¥à¤¹à¥à¤¨à¥à¤¨ à¤•à¤¿à¤¨à¤­à¤¨à¥‡ à¤¯à¥‹ à¤¸à¤¾à¤°à¥à¤µà¤œà¤¨à¤¿à¤• à¤¹à¥‹à¤‡à¤¨!\",\"her_4\":\"à¤¤à¤ªà¤¾à¤ˆà¤‚à¤²à¥‡ à¤¯à¥‹ à¤ªà¤°à¤¿à¤µà¤¾à¤°à¤•à¥‹ à¤µà¤¿à¤°à¤¾à¤¸à¤¤ à¤—à¤°à¥à¤¨ à¤¸à¤•à¥à¤¨à¥à¤¹à¥à¤¨à¥à¤¨!\",\"alldone\":\"à¤¸à¤«à¤², à¤¸à¤¬à¥ˆ à¤­à¤¯à¥‹!\",\"famexist\":\"à¤¯à¥‹ à¤ªà¤°à¤¿à¤µà¤¾à¤° à¤ªà¤¹à¤¿à¤²à¥‡ à¤¨à¥ˆ à¤…à¤µà¤¸à¥à¤¥à¤¿à¤¤ à¤›!\",\"name\":\"à¤¨à¤¾à¤® à¤†à¤µà¤¶à¥à¤¯à¤• à¤›!\",\"wrong\":\"à¤•à¥‡à¤¹à¥€ à¤—à¤²à¤¤ à¤­à¤¯à¥‹!\",\"correctemail\":\"à¤¤à¤ªà¤¾à¤ˆà¤‚à¤²à¤¾à¤ˆ à¤¸à¤¹à¥€ à¤‡à¤®à¥‡à¤² à¤ à¥‡à¤—à¤¾à¤¨à¤¾ à¤šà¤¾à¤¹à¤¿à¤¨à¥à¤›!\",\"existemail\":\"à¤¯à¥‹ à¤‡à¤®à¥‡à¤² à¤ªà¤¹à¤¿à¤²à¥‡ à¤¨à¥ˆ à¤…à¤µà¤¸à¥à¤¥à¤¿à¤¤ à¤›!\",\"existusername\":\"à¤¯à¥‹ à¤ªà¥à¤°à¤¯à¥‹à¤—à¤•à¤°à¥à¤¤à¤¾ à¤¨à¤¾à¤® à¤ªà¤¹à¤¿à¤²à¥‡ à¤¨à¥ˆ à¤…à¤µà¤¸à¥à¤¥à¤¿à¤¤ à¤›!\",\"regsuccess\":\"à¤¤à¤ªà¤¾à¤ˆà¤‚ à¤¸à¤«à¤²à¤¤à¤¾à¤ªà¥‚à¤°à¥à¤µà¤• à¤¦à¤°à¥à¤¤à¤¾ à¤—à¤°à¤¿à¤¨à¥à¤­à¤¯à¥‹à¥¤\",\"regsuccess1\":\"à¤¤à¤ªà¤¾à¤ˆà¤‚ à¤¸à¤«à¤²à¤¤à¤¾à¤ªà¥‚à¤°à¥à¤µà¤• à¤¦à¤°à¥à¤¤à¤¾ à¤—à¤°à¤¿à¤¨à¥à¤­à¤¯à¥‹, à¤¤à¤° à¤¹à¤¾à¤®à¥€à¤²à¥‡ à¤¤à¤ªà¤¾à¤ˆà¤‚à¤²à¤¾à¤ˆ à¤ªà¥à¤°à¤®à¤¾à¤£à¥€à¤•à¤°à¤£à¤•à¥‹ à¤²à¤¾à¤—à¤¿ à¤‡à¤®à¥‡à¤² à¤ªà¤ à¤¾à¤¯à¥Œà¤‚!\",\"regsuccess2\":\"à¤¤à¤ªà¤¾à¤ˆà¤‚ à¤¸à¤«à¤²à¤¤à¤¾à¤ªà¥‚à¤°à¥à¤µà¤• à¤¦à¤°à¥à¤¤à¤¾ à¤—à¤°à¤¿à¤¨à¥à¤­à¤¯à¥‹, à¤¤à¤° à¤ªà¥à¤°à¤¶à¤¾à¤¸à¤¨à¤¦à¥à¤µà¤¾à¤°à¤¾ à¤¸à¥à¤µà¥€à¤•à¥ƒà¤¤ à¤¹à¥à¤¨ à¤†à¤µà¤¶à¥à¤¯à¤• à¤›!\",\"famsuccess\":\"à¤¤à¤ªà¤¾à¤ˆà¤‚à¤•à¥‹ à¤ªà¤°à¤¿à¤µà¤¾à¤° à¤†à¤ˆà¤¡à¥€ à¤¸à¤«à¤²à¤¤à¤¾à¤ªà¥‚à¤°à¥à¤µà¤• à¤¸à¤¿à¤°à¥à¤œà¤¨à¤¾ à¤—à¤°à¤¿à¤¯à¥‹!\",\"logsuccess\":\"à¤¤à¤ªà¤¾à¤ˆà¤‚ à¤¸à¤«à¤²à¤¤à¤¾à¤ªà¥‚à¤°à¥à¤µà¤• à¤²à¤—à¤‡à¤¨ à¤—à¤°à¥à¤¨à¥à¤­à¤¯à¥‹!\",\"logapprov\":\"à¤¯à¥‹ à¤ªà¥à¤°à¤¯à¥‹à¤—à¤•à¤°à¥à¤¤à¤¾ à¤²à¤—à¤‡à¤¨ à¤—à¤°à¥à¤¨à¥ à¤…à¤˜à¤¿ à¤ªà¥à¤°à¤¶à¤¾à¤¸à¤¨à¤¦à¥à¤µà¤¾à¤°à¤¾ à¤¸à¥à¤µà¥€à¤•à¥ƒà¤¤à¤¿à¤•à¥‹ à¤†à¤µà¤¶à¥à¤¯à¤•à¤¤à¤¾ à¤›!\",\"logverif\":\"à¤¯à¥‹ à¤ªà¥à¤°à¤¯à¥‹à¤—à¤•à¤°à¥à¤¤à¤¾à¤²à¤¾à¤ˆ à¤‡à¤®à¥‡à¤² à¤ à¥‡à¤—à¤¾à¤¨à¤¾à¤¦à¥à¤µà¤¾à¤°à¤¾ à¤ªà¥à¤°à¤®à¤¾à¤£à¤¿à¤¤ à¤—à¤°à¥à¤¨ à¤†à¤µà¤¶à¥à¤¯à¤•à¤¤à¤¾ à¤›!\",\"logerror\":\"à¤ªà¤°à¤¿à¤µà¤¾à¤° à¤†à¤ˆà¤¡à¥€ à¤µà¤¾ à¤ªà¤¾à¤¸à¤µà¤°à¥à¤¡ à¤—à¤²à¤¤ à¤›!\",\"reseterror\":\"à¤¯à¤¸ à¤œà¤¾à¤¨à¤•à¤¾à¤°à¥€à¤•à¥‹ à¤¸à¤¾à¤¥ à¤•à¥à¤¨à¥ˆ à¤ªà¥à¤°à¤¯à¥‹à¤—à¤•à¤°à¥à¤¤à¤¾ à¤›à¥ˆà¤¨!\",\"resetsuccess\":\"à¤°à¤¿à¤¸à¥‡à¤Ÿ à¤ªà¤¾à¤¸à¤µà¤°à¥à¤¡ à¤¸à¤«à¤²à¤¤à¤¾à¤ªà¥‚à¤°à¥à¤µà¤• à¤ªà¤ à¤¾à¤‡à¤¯à¥‹à¥¤\",\"pass1\":\"à¤ªà¤¾à¤¸à¤µà¤°à¥à¤¡ à¥¬ à¤…à¤•à¥à¤·à¤°à¤­à¤¨à¥à¤¦à¤¾ à¤¬à¤¢à¥€\",\"pass2\":\"à¤ªà¤¾à¤¸à¤µà¤°à¥à¤¡ à¤ªà¥à¤¨à¤ƒ-à¤ªà¤¾à¤¸à¤µà¤°à¥à¤¡à¤¸à¤à¤— à¤®à¥‡à¤² à¤–à¤¾à¤à¤¦à¥ˆà¤¨\",\"pass3\":\"à¤¤à¤ªà¤¾à¤ˆà¤‚ à¤…à¤¬ à¤¯à¤¸ à¤¨à¤¯à¤¾à¤ à¤ªà¤¾à¤¸à¤µà¤°à¥à¤¡à¤¸à¤à¤— à¤²à¤—à¤‡à¤¨ à¤—à¤°à¥à¤¨ à¤¸à¤•à¥à¤¨à¥à¤¹à¥à¤¨à¥à¤›\",\"nodata\":\"à¤•à¥à¤¨à¥ˆ à¤¡à¤¾à¤Ÿà¤¾ à¤«à¥‡à¤²à¤¾ à¤ªà¤°à¥‡à¤¨!\",\"emailver\":\"à¤¸à¤¬à¥ˆ à¤ à¥€à¤• à¤›, à¤¤à¤ªà¤¾à¤ˆà¤‚ à¤…à¤¬ à¤²à¤—à¤‡à¤¨ à¤—à¤°à¥à¤¨ à¤¸à¤•à¥à¤¨à¥à¤¹à¥à¤¨à¥à¤›à¥¤\",\"families\":\"à¤¤à¤ªà¤¾à¤ˆà¤‚à¤²à¥‡ à¤¥à¤ªà¥à¤¨ à¤¸à¤•à¥à¤¨à¥à¤¹à¥à¤¨à¥‡ à¤ªà¤°à¤¿à¤µà¤¾à¤°à¤¹à¤°à¥‚à¤•à¥‹ à¤¸à¤‚à¤–à¥à¤¯à¤¾ à¤¤à¤ªà¤¾à¤ˆà¤‚à¤¸à¤à¤— à¤°à¤¹à¥‡à¤•à¥‹ à¤¯à¥‹à¤œà¤¨à¤¾à¤•à¥‹ à¤²à¤¾à¤—à¤¿ à¤¸à¤®à¤¾à¤ªà¥à¤¤ à¤­à¤¯à¥‹, à¤•à¥ƒà¤ªà¤¯à¤¾ à¤¥à¤ªà¤•à¥‹ à¤²à¤¾à¤—à¤¿ à¤†à¤«à¥à¤¨à¥‹ à¤¯à¥‹à¤œà¤¨à¤¾ à¤…à¤ªà¤—à¥à¤°à¥‡à¤¡ à¤—à¤°à¥à¤¨à¥à¤¹à¥‹à¤¸à¥!\",\"heritage\":\"à¤¤à¤ªà¤¾à¤ˆà¤‚à¤¸à¤à¤— à¤¤à¤ªà¤¾à¤ˆà¤‚à¤²à¥‡ à¤ªà¥à¤°à¤¯à¥‹à¤— à¤—à¤°à¥à¤¨à¥à¤­à¤à¤•à¥‹ à¤¯à¥‹à¤œà¤¨à¤¾à¤•à¥‹ à¤ªà¥à¤°à¤¯à¥‹à¤— à¤—à¤°à¥‡à¤° à¤µà¤¿à¤°à¤¾à¤¸à¤¤ à¤—à¤°à¥à¤¨à¥‡ à¤…à¤¨à¥à¤®à¤¤à¤¿ à¤›à¥ˆà¤¨, à¤•à¥ƒà¤ªà¤¯à¤¾ à¤¥à¤ªà¤•à¥‹ à¤²à¤¾à¤—à¤¿ à¤†à¤«à¥à¤¨à¥‹ à¤¯à¥‹à¤œà¤¨à¤¾ à¤…à¤ªà¤—à¥à¤°à¥‡à¤¡ à¤—à¤°à¥à¤¨à¥à¤¹à¥‹à¤¸à¥!\",\"members\":\"à¤¤à¤ªà¤¾à¤ˆà¤‚à¤²à¥‡ à¤ªà¥à¤°à¤¤à¤¿ à¤ªà¤°à¤¿à¤µà¤¾à¤° à¤¥à¤ªà¥à¤¨ à¤¸à¤•à¥à¤¨à¥à¤¹à¥à¤¨à¥‡ à¤¸à¤¦à¤¸à¥à¤¯à¤¹à¤°à¥‚à¤•à¥‹ à¤¸à¤‚à¤–à¥à¤¯à¤¾ à¤¤à¤ªà¤¾à¤ˆà¤‚à¤¸à¤à¤— à¤°à¤¹à¥‡à¤•à¥‹ à¤¯à¥‹à¤œà¤¨à¤¾à¤•à¥‹ à¤²à¤¾à¤—à¤¿ à¤¸à¤®à¤¾à¤ªà¥à¤¤ à¤­à¤¯à¥‹, à¤•à¥ƒà¤ªà¤¯à¤¾ à¤¥à¤ªà¤•à¥‹ à¤²à¤¾à¤—à¤¿ à¤†à¤«à¥à¤¨à¥‹ à¤¯à¥‹à¤œà¤¨à¤¾ à¤…à¤ªà¤—à¥à¤°à¥‡à¤¡ à¤—à¤°à¥à¤¨à¥à¤¹à¥‹à¤¸à¥!\",\"albums\":\"à¤¤à¤ªà¤¾à¤ˆà¤‚à¤¸à¤à¤— à¤¤à¤ªà¤¾à¤ˆà¤‚à¤²à¥‡ à¤ªà¥à¤°à¤¯à¥‹à¤— à¤—à¤°à¥à¤¨à¥à¤­à¤à¤•à¥‹ à¤¯à¥‹à¤œà¤¨à¤¾à¤•à¥‹ à¤ªà¥à¤°à¤¯à¥‹à¤— à¤—à¤°à¥‡à¤° à¤à¤²à¥à¤¬à¤®à¤¹à¤°à¥‚à¤®à¤¾ à¤¤à¤¸à¥à¤¬à¥€à¤°à¤¹à¤°à¥‚ à¤¥à¤ªà¥à¤¨à¥‡ à¤…à¤¨à¥à¤®à¤¤à¤¿ à¤›à¥ˆà¤¨, à¤•à¥ƒà¤ªà¤¯à¤¾ à¤¥à¤ªà¤•à¥‹ à¤²à¤¾à¤—à¤¿ à¤†à¤«à¥à¤¨à¥‹ à¤¯à¥‹à¤œà¤¨à¤¾ à¤…à¤ªà¤—à¥à¤°à¥‡à¤¡ à¤—à¤°à¥à¤¨à¥à¤¹à¥‹à¤¸à¥!\",\"permission\":\"à¤¤à¤ªà¤¾à¤ˆà¤‚à¤¸à¤à¤— à¤¯à¤¸ à¤ªà¥ƒà¤·à¥à¤ à¤®à¤¾ à¤ªà¤¹à¥à¤à¤š à¤—à¤°à¥à¤¨à¥‡ à¤…à¤¨à¥à¤®à¤¤à¤¿ à¤›à¥ˆà¤¨!\",\"payment\":\"à¤­à¥à¤•à¥à¤¤à¤¾à¤¨à¥€ à¤¸à¤«à¤² à¤­à¤¯à¥‹!\",\"payment_f\":\"PayPal à¤¬à¤¾à¤Ÿ à¤­à¥à¤•à¥à¤¤à¤¾à¤¨à¥€ à¤ªà¥à¤°à¤¾à¤ªà¥à¤¤ à¤—à¤°à¥à¤¨ à¤…à¤¸à¤«à¤²!\",\"logout\":\"à¤•à¥‡ à¤¤à¤ªà¤¾à¤ˆà¤‚ à¤¨à¤¿à¤¶à¥à¤šà¤¿à¤¤ à¤¹à¥à¤¨à¥à¤¹à¥à¤¨à¥à¤› à¤•à¤¿ à¤¤à¤ªà¤¾à¤ˆà¤‚ à¤²à¤—à¤†à¤‰à¤Ÿ à¤—à¤°à¥à¤¨ à¤šà¤¾à¤¹à¤¨à¥à¤¹à¥à¤¨à¥à¤›?\",\"nofile\":\"à¤•à¥à¤¨à¥ˆ à¤«à¤¾à¤‡à¤² à¤šà¤¯à¤¨ à¤—à¤°à¤¿à¤à¤•à¥‹ à¤›à¥ˆà¤¨...\",\"de_mem\":\"à¤•à¥‡ à¤¤à¤ªà¤¾à¤ˆà¤‚ à¤¨à¤¿à¤¶à¥à¤šà¤¿à¤¤ à¤¹à¥à¤¨à¥à¤¹à¥à¤¨à¥à¤› à¤•à¤¿ à¤¤à¤ªà¤¾à¤ˆà¤‚ à¤¯à¥‹ à¤¸à¤¦à¤¸à¥à¤¯ à¤®à¥‡à¤Ÿà¤¾à¤‰à¤¨ à¤šà¤¾à¤¹à¤¨à¥à¤¹à¥à¤¨à¥à¤›?\"},\"dashboard\":{\"hello\":\"à¤¨à¤®à¤¸à¥à¤¤à¥‡,\",\"welcome\":\"à¤¤à¤ªà¤¾à¤ˆà¤‚à¤•à¥‹ à¤¡à¥à¤¯à¤¾à¤¸à¤¬à¥‹à¤°à¥à¤¡à¤®à¤¾ à¤«à¥‡à¤°à¤¿ à¤¸à¥à¤µà¤¾à¤—à¤¤ à¤›à¥¤\",\"families\":\"à¤ªà¤°à¤¿à¤µà¤¾à¤°à¤¹à¤°à¥‚\",\"users\":\"à¤ªà¥à¤°à¤¯à¥‹à¤—à¤•à¤°à¥à¤¤à¤¾à¤¹à¤°à¥‚\",\"responses\":\"à¤¸à¤¦à¤¸à¥à¤¯à¤¹à¤°à¥‚\",\"questions\":\"à¤¤à¤¸à¥à¤¬à¥€à¤°à¤¹à¤°à¥‚\",\"days\":\"à¤¦à¤¿à¤¨à¤¹à¤°à¥‚\",\"months\":\"à¤®à¤¹à¤¿à¤¨à¤¾à¤¹à¤°à¥‚\",\"new_u\":\"à¤¨à¤¯à¤¾à¤ à¤ªà¥à¤°à¤¯à¥‹à¤—à¤•à¤°à¥à¤¤à¤¾à¤¹à¤°à¥‚ (à¥¨à¥ª à¤˜à¤£à¥à¤Ÿà¤¾)\",\"latest_f\":\"à¤¨à¤¯à¤¾à¤à¤¤à¤® à¤ªà¤°à¤¿à¤µà¤¾à¤°à¤¹à¤°à¥‚\",\"latest_m\":\"à¤¨à¤¯à¤¾à¤à¤¤à¤® à¤¸à¤¦à¤¸à¥à¤¯à¤¹à¤°à¥‚\",\"save\":\"à¤¬à¤šà¤¤ à¤—à¤°à¥à¤¨à¥à¤¹à¥‹à¤¸à¥\",\"p_disacticate\":\"à¤¯à¥‹à¤œà¤¨à¤¾à¤¹à¤°à¥‚à¤•à¥‹ à¤µà¤¿à¤•à¤²à¥à¤ª à¤¨à¤¿à¤·à¥à¤•à¥à¤°à¤¿à¤¯ à¤—à¤°à¥à¤¨à¥à¤¹à¥‹à¤¸à¥\",\"status\":\"à¤¸à¥à¤¥à¤¿à¤¤à¤¿\",\"name\":\"à¤¨à¤¾à¤®\",\"public\":\"à¤¸à¤¾à¤°à¥à¤µà¤œà¤¨à¤¿à¤•\",\"members\":\"à¤¸à¤¦à¤¸à¥à¤¯à¤¹à¤°à¥‚\",\"moderators\":\"à¤®à¤§à¥à¤¯à¤¸à¥à¤¥à¤¹à¤°à¥‚\",\"date\":\"à¤®à¤¿à¤¤à¤¿\",\"edit\":\"à¤¸à¤®à¥à¤ªà¤¾à¤¦à¤¨ à¤—à¤°à¥à¤¨à¥à¤¹à¥‹à¤¸à¥\",\"delete\":\"à¤®à¥‡à¤Ÿà¤¾à¤‰à¤¨à¥à¤¹à¥‹à¤¸à¥\",\"u_users\":\"à¤¸à¤¦à¤¸à¥à¤¯à¤¹à¤°à¥‚\",\"u_status\":\"à¤¸à¥à¤¥à¤¿à¤¤à¤¿\",\"u_username\":\"à¤ªà¥à¤°à¤¯à¥‹à¤—à¤•à¤°à¥à¤¤à¤¾ à¤¨à¤¾à¤®\",\"verification\":\"à¤ªà¥à¤°à¤®à¤¾à¤£à¥€à¤•à¤°à¤£\",\"u_registred\":\"à¤®à¤¾ à¤¦à¤°à¥à¤¤à¤¾ à¤­à¤¯à¥‹\",\"u_updated\":\"à¤®à¤¾ à¤…à¤¦à¥à¤¯à¤¾à¤µà¤§à¤¿à¤• à¤—à¤°à¤¿à¤¯à¥‹\",\"u_delete\":\"à¤ªà¥à¤°à¤¯à¥‹à¤—à¤•à¤°à¥à¤¤à¤¾ à¤®à¥‡à¤Ÿà¤¾à¤‰à¤¨à¥à¤¹à¥‹à¤¸à¥\",\"u_edit\":\"à¤ªà¥à¤°à¤¯à¥‹à¤—à¤•à¤°à¥à¤¤à¤¾ à¤¸à¤®à¥à¤ªà¤¾à¤¦à¤¨ à¤—à¤°à¥à¤¨à¥à¤¹à¥‹à¤¸à¥\",\"u_create\":\"à¤ªà¥à¤°à¤¯à¥‹à¤—à¤•à¤°à¥à¤¤à¤¾ à¤¸à¤¿à¤°à¥à¤œà¤¨à¤¾ à¤—à¤°à¥à¤¨à¥à¤¹à¥‹à¤¸à¥\",\"u_pages\":\"à¤ªà¥ƒà¤·à¥à¤ à¤¹à¤°à¥‚\",\"npage\":\"à¤¨à¤¯à¤¾à¤ à¤ªà¥ƒà¤·à¥à¤ \",\"title\":\"à¤¶à¥€à¤°à¥à¤·à¤•\",\"inmenu\":\"à¤®à¥‡à¤¨à¥à¤®à¤¾\",\"created\":\"à¤¸à¤¿à¤°à¥à¤œà¤¨à¤¾ à¤—à¤°à¤¿à¤¯à¥‹\",\"p_title\":\"à¤­à¥à¤•à¥à¤¤à¤¾à¤¨à¥€à¤¹à¤°à¥‚\",\"p_user\":\"à¤ªà¥à¤°à¤¯à¥‹à¤—à¤•à¤°à¥à¤¤à¤¾\",\"u_plan\":\"à¤¯à¥‹à¤œà¤¨à¤¾\",\"p_amount\":\"à¤°à¤•à¤®\",\"p_paymentid\":\"à¤­à¥à¤•à¥à¤¤à¤¾à¤¨à¥€ à¤†à¤ˆà¤¡à¥€\",\"p_payerid\":\"à¤­à¥à¤•à¥à¤¤à¤¾à¤¨à¤•à¤°à¥à¤¤à¤¾ à¤†à¤ˆà¤¡à¥€\",\"created_at\":\"à¤®à¤¾ à¤¸à¤¿à¤°à¥à¤œà¤¨à¤¾ à¤—à¤°à¤¿à¤¯à¥‹\",\"set_title\":\"à¤¸à¤¾à¤®à¤¾à¤¨à¥à¤¯ à¤¸à¥‡à¤Ÿà¤¿à¤™à¤¹à¤°à¥‚\",\"set_stitle\":\"à¤¸à¤¾à¤‡à¤Ÿ à¤¶à¥€à¤°à¥à¤·à¤•:\",\"set_keys\":\"à¤¸à¤¾à¤‡à¤Ÿ à¤•à¥à¤žà¥à¤œà¥€à¤¶à¤¬à¥à¤¦à¤¹à¤°à¥‚:\",\"set_desc\":\"à¤¸à¤¾à¤‡à¤Ÿ à¤µà¤¿à¤µà¤°à¤£:\",\"set_url\":\"à¤¸à¤¾à¤‡à¤Ÿ URL:\",\"regstatus\":\"à¤¦à¤°à¥à¤¤à¤¾ à¤¸à¥à¤¥à¤¿à¤¤à¤¿:\",\"byemail\":\"à¤‡à¤®à¥‡à¤² à¤¦à¥à¤µà¤¾à¤°à¤¾\",\"mneedsapproval\":\"à¤‡à¤®à¥‡à¤² à¤¬à¤¿à¤¨à¤¾ à¤¸à¥à¤µà¥€à¤•à¥ƒà¤¤à¤¿à¤•à¥‹ à¤†à¤µà¤¶à¥à¤¯à¤•à¤¤à¤¾\",\"open\":\"à¤–à¥à¤²à¤¾\",\"hidereg\":\"à¤¦à¤°à¥à¤¤à¤¾ à¤«à¤¾à¤°à¥à¤® à¤²à¥à¤•à¤¾à¤‰à¤¨à¥à¤¹à¥‹à¤¸à¥\",\"fneedsapproval\":\"à¤œà¤¿à¤‰à¤à¤¦à¥‹ à¤¹à¥à¤¨à¥ à¤…à¤˜à¤¿ à¤ªà¤°à¤¿à¤µà¤¾à¤°à¤¹à¤°à¥‚à¤²à¤¾à¤ˆ à¤¸à¥à¤µà¥€à¤•à¥ƒà¤¤à¤¿à¤•à¥‹ à¤†à¤µà¤¶à¥à¤¯à¤•à¤¤à¤¾ à¤›\",\"colors\":\"à¤°à¤™à¤¹à¤°à¥‚\",\"ptitle\":\"à¤ªà¥ƒà¤·à¥à¤  à¤¶à¥€à¤°à¥à¤·à¤•\",\"picon\":\"à¤ªà¥ƒà¤·à¥à¤  à¤†à¤‡à¤•à¤¨\",\"pcontent\":\"à¤ªà¥ƒà¤·à¥à¤  à¤¸à¤¾à¤®à¤—à¥à¤°à¥€\",\"dmenu\":\"à¤¯à¤¸à¤²à¤¾à¤ˆ à¤®à¥‡à¤¨à¥à¤®à¤¾ à¤ªà¥à¤°à¤¦à¤°à¥à¤¶à¤¨ à¤—à¤°à¥à¤¨à¥à¤¹à¥‹à¤¸à¥\",\"stats_line_d\":\"à¤…à¤¨à¥à¤¤à¤¿à¤® à¥­ à¤¦à¤¿à¤¨à¤•à¥‹ à¤²à¤¾à¤—à¤¿ à¤¤à¤¥à¥à¤¯à¤¾à¤™à¥à¤•\",\"stats_line_m\":\"à¤¯à¤¸ à¤µà¤°à¥à¤·à¤•à¥‹ à¤²à¤¾à¤—à¤¿ à¤¤à¤¥à¥à¤¯à¤¾à¤™à¥à¤•\",\"planalert\":\"à¤¯à¥‹à¤œà¤¨à¤¾à¤¹à¤°à¥‚ à¤¸à¤«à¤²à¤¤à¤¾à¤ªà¥‚à¤°à¥à¤µà¤• à¤¬à¤šà¤¤ à¤—à¤°à¤¿à¤¯à¥‹à¥¤\"}}');

-- --------------------------------------------------------

--
-- Table structure for table `Ghimire_members`
--

CREATE TABLE `Ghimire_members` (
  `id` int(11) NOT NULL,
  `author` int(10) UNSIGNED DEFAULT 0,
  `user` varchar(200) DEFAULT NULL,
  `family` smallint(6) UNSIGNED DEFAULT 0,
  `date` int(10) UNSIGNED DEFAULT NULL,
  `firstname` varchar(100) DEFAULT NULL,
  `lastname` varchar(100) DEFAULT NULL,
  `gender` tinyint(1) UNSIGNED DEFAULT 0,
  `birth` varchar(100) DEFAULT NULL,
  `death` tinyint(1) UNSIGNED DEFAULT 0,
  `type` tinyint(1) UNSIGNED DEFAULT 0,
  `photo` varchar(255) DEFAULT NULL,
  `email` varchar(200) DEFAULT NULL,
  `site` varchar(200) DEFAULT NULL,
  `tel` varchar(15) DEFAULT NULL,
  `mobile` varchar(15) DEFAULT NULL,
  `birthplace` varchar(255) DEFAULT NULL,
  `deathplace` varchar(255) DEFAULT NULL,
  `profession` varchar(255) DEFAULT NULL,
  `company` varchar(255) DEFAULT NULL,
  `interests` varchar(255) DEFAULT NULL,
  `bio` mediumtext DEFAULT NULL,
  `level` tinyint(1) UNSIGNED DEFAULT 0,
  `parent` int(11) UNSIGNED DEFAULT 0,
  `birthday` tinyint(2) UNSIGNED DEFAULT 0,
  `birthmonth` tinyint(2) UNSIGNED DEFAULT 0,
  `birthyear` smallint(4) UNSIGNED DEFAULT 0,
  `deathday` tinyint(2) UNSIGNED DEFAULT 0,
  `deathmonth` tinyint(2) UNSIGNED DEFAULT 0,
  `deathyear` smallint(4) UNSIGNED DEFAULT 0,
  `birthdate` bigint(20) DEFAULT 0,
  `mariagedate` bigint(20) DEFAULT 0,
  `deathdate` bigint(20) DEFAULT 0,
  `facebook` varchar(255) DEFAULT NULL,
  `instagram` varchar(255) DEFAULT NULL,
  `twitter` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Ghimire_notifications`
--

CREATE TABLE `Ghimire_notifications` (
  `id` int(11) NOT NULL,
  `author` int(10) UNSIGNED DEFAULT NULL,
  `user` int(10) UNSIGNED DEFAULT NULL,
  `type` varchar(100) DEFAULT NULL,
  `date` int(10) UNSIGNED DEFAULT NULL,
  `item` int(10) UNSIGNED DEFAULT NULL,
  `nread` tinyint(1) UNSIGNED DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Ghimire_pages`
--

CREATE TABLE `Ghimire_pages` (
  `slug` varchar(255) DEFAULT NULL,
  `id` int(11) NOT NULL,
  `icon` varchar(100) DEFAULT NULL,
  `date` int(11) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `content` longtext DEFAULT NULL,
  `header` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Dumping data for table `Ghimire_pages`
--

INSERT INTO `Ghimire_pages` (`slug`, `id`, `icon`, `date`, `title`, `content`, `header`) VALUES
('contact-us', 1, 'far fa-envelope-open', 1586270779, 'Contact us', 'Craeted By: ShyamKumarKshetri\r\nà¤¯à¤¦à¤¿ à¤•à¥à¤¨à¥ˆ à¤¸à¤®à¤¸à¥à¤¯à¤¾ à¤µà¤¾ à¤¸à¤®à¤¸à¥à¤¯à¤¾ à¤› à¤­à¤¨à¥‡, à¤¤à¤²à¤•à¤¾ à¤¸à¤¾à¤®à¤¾à¤œà¤¿à¤• à¤®à¤¿à¤¡à¤¿à¤¯à¤¾ à¤²à¤¿à¤™à¥à¤•à¤¹à¤°à¥‚ à¤®à¤¾à¤°à¥à¤«à¤¤ à¤®à¤²à¤¾à¤ˆ à¤¸à¤®à¥à¤ªà¤°à¥à¤• à¤—à¤°à¥à¤¨ à¤¨à¤¹à¤šà¤•à¤¿à¤šà¤¾à¤‰à¤¨à¥à¤¹à¥‹à¤¸à¥:\r\n\r\n[ul]\r\n[li]à¤«à¥‡à¤¸à¤¬à¥à¤•:[url=https://www.facebook.com/shyamchhetri0][color=#2ecc40]www.facebook.com/shyamchhetri0[/color][/url][/li]\r\n[li]à¤µà¥à¤¹à¤¾à¤Ÿà¥à¤¸à¤à¤ª:[url=https://wa.me/+9779867366483][color=#2ecc40]+à¥¯à¥­à¥­ à¥¯à¥®à¥¬à¥­à¥©à¥¬à¥¬à¥ªà¥®à¥©[/color][/url][/li]\r\n[/ul]\r\n\r\nà¤¤à¤ªà¤¾à¤ˆà¤‚à¤²à¤¾à¤ˆ à¤¸à¤§à¥ˆà¤‚ à¤¸à¥à¤µà¤¾à¤—à¤¤ à¤›, à¤° à¤® à¤¤à¤ªà¤¾à¤ˆà¤‚à¤²à¤¾à¤ˆ à¤¸à¤¹à¤¯à¥‹à¤— à¤—à¤°à¥à¤¨ à¤§à¥‡à¤°à¥ˆ à¤–à¥à¤¸à¥€ à¤¹à¥à¤¨à¥‡à¤›à¥ :)', 1),
('about-us', 2, 'far fa-question-circle', 1586270416, 'About us', '[quote]\r\nà¤²à¤—à¤­à¤— à¤µà¤¿à¤•à¥à¤°à¤® à¤¸à¤®à¥à¤µà¤¤ 1805 à¤•à¥‹à¤•à¥à¤°à¤¾ à¤¹à¥‹ à¤­à¤¾à¤°à¤¤à¤®à¤¾ à¤¹à¤¿à¤¨à¥à¤¦à¥ à¤° à¤®à¥à¤¸à¥à¤²à¤¿à¤®à¤•à¥‹ à¤²à¤¡à¤¾à¤‡ à¤à¤—à¤¡à¤¾ à¤®à¤¾à¤° à¤ªà¤¿à¤Ÿ à¤¡à¤™à¥à¤—à¤¾ à¤«à¥ˆà¤²à¤¿à¤à¤•à¥‹ à¤¥à¤¿à¤¯à¥‹à¥¤ à¤®à¥à¤¸à¥à¤²à¤¿à¤®à¤•à¥‹ à¤¬à¤¸à¤¾à¤‡ à¤§à¥‡à¤°à¥ˆ à¤­à¤à¤•à¥‹ à¤¹à¥à¤¨à¤¾à¤²à¥‡, à¤®à¥à¤¸à¥à¤²à¤¿à¤®à¤²à¥‡ à¤¹à¤¿à¤¨à¥à¤¦à¥à¤²à¤¾à¤‡ à¤­à¥‡à¤Ÿà¥à¤¯à¥‹ à¤•à¤¿ à¤®à¤¾à¤°à¥à¤¨à¥‡ à¤ªà¤¿à¤Ÿà¥à¤¨à¥‡ à¤° à¤œà¤¿à¤‰à¤¦à¥‹ à¤œà¤²à¤¾à¤‰à¤¨à¥‡ à¤…à¤¨à¤¿ à¤˜à¤° à¤œà¤²à¤¾à¤‰à¤¨à¥‡ à¤šà¤²à¤¿à¤°à¤¹à¥‡à¤•à¥‹ à¤¥à¤¿à¤¯à¥‹à¥¤ \r\nà¤¹à¤¿à¤¨à¥à¤¦à¥à¤œà¤¾à¤¤à¤¿ à¤†à¤«à¥à¤¨à¥‹ à¤§à¤°à¥à¤® à¤œà¤¾à¤¤ à¤¬à¤‚à¤¶ à¤¬à¤šà¤¾à¤‰à¤¨à¤•à¥‹ à¤²à¤¾à¤—à¥€, à¤†à¤«à¥à¤¨à¥‹ à¤¬à¤¾à¤² à¤¬à¤šà¥à¤šà¤¾ à¤ªà¤¤à¥à¤¨à¤¿ à¤° à¤†à¤«à¥ à¤¬à¤šà¥à¤¨à¤•à¥‹ à¤²à¤¾à¤—à¥€ à¤­à¤¾à¤—à¥à¤¦à¥ˆ à¤²à¥à¤•à¥à¤¦à¥ˆ à¤­à¤¾à¤°à¤¤ à¤›à¥‹à¤¡à¥‡à¤° à¤¨à¥‡à¤ªà¤¾à¤² à¤­à¤¿à¤¤à¥à¤°à¤¿à¤¨à¥‡ à¤•à¥à¤°à¤® à¤šà¤²à¤¿à¤°à¤¹à¥‡à¤•à¥‹ à¤¥à¤¿à¤¯à¥‹à¥¤ à¤¤à¥à¤¯à¤¤à¤¿ à¤¬à¥‡à¤²à¤¾ à¤•à¥à¤¨à¥ˆ à¤¥à¤° à¤œà¤¾à¤¤/à¤­à¤¾à¤¤ à¤­à¤¨à¥à¤¨à¥‡ à¤¥à¤¿à¤à¤¨, à¤¹à¤¿à¤¨à¥à¤¦à¥ à¤œà¤¾à¤¤à¤¿à¤•à¥‹ à¤…-à¤†à¤«à¥à¤¨à¥‹ à¤—à¥‹à¤¤à¥à¤° à¤¥à¤¿à¤¯à¥‹, à¤…à¤¨à¤¿ à¤†à¤«à¥à¤²à¤¾à¤‡ à¤¬à¥à¤°à¤¾à¤¹à¥à¤®à¤£ à¤ªà¥à¤œà¤¾à¤°à¤¿à¤•à¥‹ à¤°à¥à¤ªà¤®à¤¾ à¤šà¤¿à¤¨à¥à¤¦à¤¥à¥‡à¥¤\r\n\r\n[b]à¤¹à¤¾à¤®à¥à¤°à¥‹ à¤ªà¥à¤°à¥à¤–à¤¾à¤•à¥‹ à¤˜à¤¿à¤®à¤¿à¤°à¥‡ à¤¥à¤° à¤•à¤¸à¤°à¥€ à¤œà¥‹à¤¡à¤¿à¤¨ à¤ªà¥à¤—à¥à¤¯à¥‹[/b]\r\nà¤¹à¤¾à¤®à¥à¤°à¥‹à¤ªà¥à¤°à¥à¤–à¤¾à¤•à¥‹ à¤¬à¤¸à¤¾à¤‡ à¤­à¤¾à¤°à¤¤à¤•à¥‹ à¤¬à¤¿à¤¨à¥à¤§à¤µà¤¾à¤¸à¤¿à¤¨à¥€ à¤ à¤¾à¤‰à¤à¤®à¤¾ à¤°à¤¹à¥‡à¤•à¥‹ à¤¥à¤¿à¤¯à¥‹à¥¤ à¤¸à¥à¤°à¥‹à¤¤ à¤…à¤¨à¥à¤¸à¤¾à¤° à¤‰à¤œà¥à¤¯à¤¨ à¤¶à¤¹à¤°à¤•à¤¾ à¤°à¤¾à¤œà¤¾ à¤µà¤¿à¤•à¥à¤°à¤® à¤†à¤¦à¤¿à¤¤à¥à¤¯à¤•à¤¾ à¤ªà¥à¤°à¥‹à¤¹à¤¿à¤¤ à¤—à¥à¤£à¤ªà¤¾à¤² à¤µà¥à¤¯à¤¾à¤¸ \r\nà¤µà¤¿à¤•à¥à¤°à¤® à¤¸à¤®à¥à¤µà¤¤ 1805 à¤®à¤¾à¤¹à¤¿à¤¨à¥à¤¦à¥ à¤° à¤®à¥à¤¸à¥à¤²à¤¿à¤®à¤•à¥‹ à¤²à¤¡à¤¾à¤‡ à¤¹à¥à¤à¤¦à¤¾, à¤†à¤«à¥à¤¨à¥‹ à¤œà¥à¤¯à¤¾à¤¨ à¤¬à¤šà¤¾à¤‰à¤¨à¤•à¥‹ à¤²à¤¾à¤—à¤¿ à¤‰à¤œà¥à¤œà¤¯à¤¨ à¤¶à¤¹à¤° à¤¦à¥‡à¤–à¤¿ à¤•à¥à¤®à¤¾à¤‰, à¤—à¤¡à¤µà¤¾à¤² à¤ªà¤¶à¥à¤šà¤¿à¤® à¤¨à¥‡à¤ªà¤¾à¤² à¤–à¤²à¤™à¥à¤—à¤¾ à¤¹à¥à¤à¤¦à¥ˆ à¤œà¥à¤®à¥à¤²à¤¾à¤•à¥‹ à¤¸à¤¿à¤‚à¤œà¤¾ à¤­à¤¨à¥à¤¨à¥‡ à¤¦à¥‡à¤¶ à¤¬à¤¾à¤Ÿ à¤¡à¥à¤²à¥à¤¦à¥ˆ à¤˜à¥à¤®à¥à¤¦à¥ˆ à¤¨à¥‡à¤ªà¤¾à¤²à¤•à¥‹ à¤®à¤§à¥à¤¯ à¤ªà¤¹à¤¾à¤¡ à¤¸à¤®à¥à¤® à¤†à¤‡ à¤ªà¥à¤—à¥‡à¤•à¤¾ à¤¥à¤¿à¤à¥¤à¤—à¤‚à¤—à¤¾à¤•à¥‹ à¤®à¥ˆà¤¦à¤¾à¤¨ à¤¦à¥‡à¤–à¤¿ à¤ªà¤¹à¤¾à¤¡ à¤¤à¤¿à¤° à¤¸à¤°à¥à¤¦à¥ˆ à¤†à¤¾à¤«à¥à¤¨à¥‹ à¤¬à¥Œà¤§à¥à¤¦à¤¿à¤• à¤—à¥à¤¯à¤¾à¤¨ à¤° à¤ªà¤°à¤®à¤ªà¤°à¤¾ à¤à¤²à¥à¤•à¤¾à¤‰à¤¦à¥ˆà¥¤ à¤¨à¤¿à¤•à¥ˆ à¤²à¤¾à¤®à¥‹ à¤¯à¤¾à¤¤à¥à¤°à¤¾ à¤–à¤¸ à¤¬à¥à¤°à¤¾à¤¹à¥à¤®à¤£à¤•à¥‹ à¤ à¥à¤²à¥‹ à¤¬à¤¸à¤¾à¤‡ à¤¸à¤°à¤¾à¤‡ à¤¤à¤° à¤à¤‰à¤Ÿà¤¾ à¤¸à¤¾à¤¨à¥‹ à¤®à¤¹à¤¤à¥à¤¤à¤µà¤ªà¥à¤°à¥à¤£ à¤¹à¤¿à¤¸à¥à¤¸à¤¾ à¤µà¤¿à¤•à¥à¤°à¤® à¤¸à¤®à¥à¤µà¤¤ 1806 à¤®à¤¾ à¤‡à¤¸à¥à¤®à¤¾ à¤°à¤¾à¤œà¥à¤¯ à¤—à¥à¤²à¥à¤®à¤¿ à¤œà¤¿à¤²à¥à¤²à¤¾à¤•à¥‹ à¤˜à¤®à¤¿à¤° à¤­à¤¨à¥à¤¨à¥‡ à¤—à¤¾à¤‰à¤à¤®à¤¾ à¤¬à¤¸à¥‹à¤µà¤¾à¤¸ à¤—à¤°à¥à¤¨à¥ à¤­à¤¯à¥‹ à¤¤à¥à¤¯à¤¤à¤¿ à¤¬à¥‡à¤²à¤¾ 22 à¤¸à¥‡ 24 à¤¸à¥‡ à¤°à¤¾à¤œà¥à¤¯ à¤¥à¤¿à¤¯à¥‹à¥¤ à¤¹à¤¾à¤®à¥à¤°à¥‹ à¤ªà¥à¤°à¥à¤µà¤œà¤¹à¤°à¥ à¤‡à¤¸à¥à¤®à¤¾ à¤°à¤¾à¤œà¥à¤¯à¤•à¥‹ à¤ªà¥à¤°à¤¾à¤¨à¤¾ à¤¬à¥à¤°à¤¾à¤¹à¥à¤®à¤£ à¤­à¤¯à¤•à¥‹ à¤¹à¥à¤¨à¤¾à¤²à¥‡ à¤‡à¤¸à¥à¤®à¤¾à¤²à¥€ à¤°à¤¾à¤œà¤¾à¤•à¤¾ à¤®à¥à¤² à¤ªà¥à¤°à¥‹à¤¹à¤¿à¤¤ à¤¹à¥à¤¨à¥‡ à¤…à¤µà¤¸à¤° à¤ªà¤¾à¤‰à¤¨à¥ à¤­à¤¯à¥‹ à¤° à¤‡à¤¸à¥à¤®à¤¾à¤•à¥‹ à¤®à¥Œà¤œà¤¾à¤®à¤¾ à¤°à¤¾à¤œà¤¾à¤µà¥ƒà¤¤à¤¾ à¤ªà¤¾à¤à¤° à¤¸à¥à¤¥à¤¾à¤¯à¥€ à¤°à¥à¤ªà¤®à¤¾ à¤¬à¤¸à¥‹à¤µà¤¾à¤¸ à¤—à¤°à¥à¤¨à¥ à¤­à¤¯à¥‹à¥¤ à¤˜à¤®à¤¿à¤° à¤­à¤¨à¥à¤¨à¥‡ à¤ à¤¾à¤‰à¤à¤®à¤¾ à¤¬à¤¸à¥à¤¨à¥ à¤­à¤à¤•à¥‹ à¤¹à¥à¤à¤¦à¤¾ à¤˜à¤®à¤¿à¤°à¥‡/à¤˜à¤¿à¤®à¤¿à¤°à¥‡à¤•à¥‹ à¤¨à¤¾à¤® à¤¬à¤¾à¤Ÿ à¤¸à¤®à¥à¤¬à¥‹à¤§à¤¨ à¤—à¤°à¥‡à¤•à¥‹ à¤¹à¥à¤¨à¤¾à¤²à¥‡ à¤ªà¤›à¤¿à¤•à¥‹ à¤ªà¥à¤¸à¥à¤¤à¤¾à¤²à¥‡ à¤†à¤«à¥à¤¨à¥‹ à¤¨à¤¾à¤®à¤•à¥‹ à¤ªà¤›à¤¾à¤¡à¥€ à¤˜à¤¿à¤®à¤¿à¤°à¥‡/à¤˜à¤®à¤¿à¤°à¥‡ à¤°à¤¾à¤–à¥‡à¤•à¥‹ à¤¹à¥à¤¨à¤¾à¤²à¥‡ à¤˜à¤¿à¤®à¤¿à¤°à¥‡ à¤¥à¤° à¤¹à¥à¤¨ à¤—à¤à¤•à¥‹ à¤®à¤¾à¤¨à¥à¤¯à¤¤à¤¾ à¤›à¥¤ à¤¹à¤¾à¤®à¥à¤°à¥‹ à¤˜à¤¿à¤®à¤¿à¤°à¥‡à¤•à¥‹ à¤ªà¥à¤°à¤¥à¤® à¤ªà¥à¤°à¥à¤–à¤¾ à¤µà¤¿à¤•à¥à¤°à¤® à¤†à¤¦à¤¿à¤¤à¥à¤¯ à¤•à¤¾ à¤ªà¥à¤°à¥‹à¤¹à¤¿à¤¤ à¤—à¥à¤£à¤ªà¤¾à¤² à¤¬à¥à¤¯à¤¾à¤¸ à¤•à¤¾ à¤¤à¤¿à¤¨ à¤­à¤¾à¤‡ à¤›à¥‹à¤°à¤¾ à¤®à¤§à¥à¤¯ à¤à¤• à¤­à¤¾à¤‡à¤²à¤¾à¤‡ à¤—à¥‹à¤°à¥à¤–à¤¾à¤•à¤¾ à¤°à¤¾à¤œà¤¾à¤²à¥‡ à¤²à¤—à¥‡à¤•à¤¾ à¤° à¤à¤• à¤­à¤¾à¤‡ à¤²à¤¾à¤ˆ à¤²à¤®à¥à¤œà¥à¤™à¥à¤—à¤•à¤¾ à¤°à¤¾à¤œà¤¾à¤²à¥‡ à¤²à¤—à¥‡à¤•à¤¾ à¤° à¤¹à¤¾à¤®à¥à¤°à¥‹ à¤ªà¥à¤°à¥à¤–à¤¾ à¤¶à¥à¤°à¤¿à¤•à¥ƒà¤·à¥à¤£ à¤…à¤—à¥à¤¨à¤¿à¤¹à¥‹à¤¤à¥à¤°à¥€ à¤¬à¥à¤°à¤¾à¤¹à¥à¤®à¤£ à¤—à¥à¤²à¥à¤®à¤¿à¤®à¥ˆ à¤¬à¤¸à¥‡à¤•à¤¾ à¤‰à¤¨à¤¿ à¤¬à¤¦à¥à¤°à¤¿à¤•à¤¾à¤¶à¥à¤°à¤® à¤®à¤¾ à¤§à¥‡à¤°à¥ˆ à¤µà¤°à¥à¤· à¤…à¤§à¥à¤¯à¤¯à¤¨ à¤—à¤°à¥‡à¤•à¤¾ à¤ªà¥à¤°à¤•à¤¾à¤£ à¤µà¤¿à¤¦à¥à¤µà¤¾à¤¨ à¤° à¤¸à¤¿à¤¦à¥à¤µà¤¾à¤¨à¥à¤¤ à¤®à¤¨à¥à¤¤à¥à¤°à¤•à¤¾ à¤œà¥à¤žà¤¾à¤¤à¤¾ à¤¸à¤®à¥‡à¤¤ à¤­à¤à¤•à¤¾à¤²à¥‡ à¤¤à¤¤à¥à¤•à¤¾à¤²à¤¿à¤¨ à¤‡à¤¸à¥à¤®à¤¾ à¤°à¤¾à¤œà¥à¤¯à¤•à¥‹ à¤°à¤¾à¤œà¤—à¥à¤°à¥ à¤­à¤‡ à¤‰à¤šà¥à¤š à¤ªà¤¦ à¤° à¤ªà¥à¤°à¤¤à¤¿à¤·à¥à¤ à¤¾ à¤ªà¥à¤°à¤¾à¤ªà¥à¤¤ à¤—à¤°à¥‡à¤•à¤¾ à¤¥à¤¿à¤à¥¤ à¤ªà¤›à¤¿ à¤‰à¤¨à¤•à¤¾ à¤¸à¤¨à¥à¤¤à¤¾à¤¨à¤²à¥‡ à¤ªà¤¨à¤¿ à¤‡à¤¸à¥à¤®à¤¾ à¤°à¤¾à¤œà¥à¤¯ à¤¦à¤°à¤¬à¤¾à¤°à¤®à¤¾ à¤°à¤¾à¤œà¤—à¥à¤°à¥à¤•à¥‹ à¤ªà¤¦à¤µà¥€à¤®à¤¾ à¤ªà¥à¤°à¤¤à¤¿à¤·à¥à¤ à¤¾ à¤ªà¤¾à¤à¤•à¤¾ à¤¥à¤¿à¤à¥¤\r\nà¤—à¥à¤£à¤ªà¤¾à¤² à¤¬à¥à¤¯à¤¾à¤¸à¤•à¤¾à¤¤à¤¿à¤¨ à¤¸à¤¨à¤¤à¤¾à¤¨ à¤®à¤§à¥à¤¯ à¤—à¥à¤²à¥à¤®à¤¿à¤®à¥ˆ à¤‡à¤¸à¥à¤®à¤¾ à¤°à¤¾à¤œà¥à¤¯à¤®à¤¾ à¤¬à¤¸à¥‡à¤•à¤¾ à¤à¤• à¤¸à¤¨à¤¤à¤¾à¤¨ à¤¶à¥à¤°à¤¿à¤•à¥ƒà¤·à¥à¤£ à¤…à¤—à¥à¤¨à¤¿à¤¹à¥‹à¤¤à¥à¤°à¥€ à¤¬à¥à¤°à¤¾à¤¹à¥à¤®à¤£ à¤¹à¥à¤¨à¥¤\r\n\r\n[b]à¤—à¥à¤²à¥à¤®à¤¿ à¤° à¤˜à¤®à¤¿à¤°à¤•à¥‹ à¤‰à¤¤à¥à¤ªà¤¤à¥à¤¤à¤¿[/b]\r\nà¤—à¥à¤²à¥à¤®à¤¿à¤•à¥‹à¤¨à¤¾à¤® à¤¸à¤‚à¤¸à¥à¤•à¥ƒà¤¤ à¤¶à¤¬à¥à¤¦ `à¤—à¥à¤²à¥à¤®Â´à¤¬à¤¾à¤Ÿ à¤†à¤à¤•à¥‹ à¤¹à¥‹ à¤œà¤¸à¤•à¥‹ à¤…à¤°à¥à¤¥ à¤¸à¥ˆà¤¨à¤¿à¤• à¤ªà¤²à¥à¤Ÿà¤¨ à¤¹à¥à¤¨à¥à¤›, à¤²à¤¿à¤šà¥à¤›à¤µà¤¿ à¤•à¤¾à¤² à¤° à¤®à¤§à¥à¤¯ à¤•à¤¾à¤²à¤®à¤¾ à¤¸à¥ˆà¤¨à¤¿à¤• à¤›à¤¾à¤‰à¤¨à¤¿ à¤ªà¤¨à¤¿ à¤¥à¤¿à¤¯à¥‹, à¤¤à¥à¤¯à¤¸à¥ˆà¤²à¥‡ à¤—à¥à¤²à¥à¤®à¤¿ à¤¨à¤¾à¤® à¤°à¤¹à¥‡à¤•à¥‹ à¤®à¤¾à¤¨à¤¿à¤¨à¥à¤›à¥¤\r\n\r\nà¤—à¥à¤²à¥à¤®à¤¿à¤•à¥‹ à¤˜à¤®à¤¿à¤° à¤­à¤¨à¥à¤¨à¥‡ à¤ à¤¾à¤‰à¤à¤²à¤¾à¤‡ à¤ªà¤¹à¤¿à¤²à¥‡ à¤¸à¤¿à¤¸à¥à¤¨à¥‡ à¤¡à¤¾à¤à¤¡à¤¾ à¤­à¤¨à¥à¤¨à¥‡ à¤—à¤°à¤¿à¤¨à¥à¤¥à¥à¤¯à¥‹ à¤° à¤à¤‰à¤Ÿà¤¾ à¤˜à¤°à¤•à¥‹ à¤­à¤¿à¤Ÿà¥à¤Ÿà¤¾à¤®à¤¾ à¤ à¥à¤²à¥ˆ à¤§à¤®à¤¿à¤°à¤¾à¤•à¥‹ à¤—à¥‹à¤²à¥‹ à¤²à¤¾à¤—à¥‡à¤•à¥‹ à¤¹à¥à¤¨à¤¾à¤²à¥‡, à¤§à¤®à¤¿à¤°à¤¾-à¤§à¤®à¤¿à¤°-à¤§à¤®à¤¿à¤° à¤­à¤¨à¥à¤¦à¤¾ à¤­à¤¨à¥à¤¦à¥ˆ à¤˜à¤®à¤¿à¤° à¤¨à¤¾à¤® à¤¹à¥à¤¨ à¤—à¤à¤•à¥‹ à¤¥à¤¿à¤¯à¥‹à¥¤\r\n\r\nà¤¸à¥à¤°à¥‹à¤¤ à¤…à¤¨à¥à¤¸à¤¾à¤° à¤•à¤¾à¤¸à¥à¤•à¤¿ à¤•à¥‹ à¤•à¤¾à¤¸à¥à¤•à¤¿ à¤•à¥‹à¤Ÿ à¤° à¤—à¥à¤²à¥à¤®à¤¿à¤•à¥‹ à¤˜à¤®à¤¿à¤° à¤­à¤¨à¥à¤¨à¥‡ à¤ à¤¾à¤‰à¤à¤²à¤¾à¤‡ à¤˜à¤¿à¤®à¤¿à¤°à¥‡à¤¹à¤°à¥à¤•à¥‹ à¤ªà¥à¤°à¤¾à¤¨à¥‹ à¤¥à¤²à¥‹ à¤®à¤¾à¤¨à¤¿à¤¨à¥à¤›à¥¤\r\n\r\n[b]à¤—à¥‹à¤¤à¥à¤° à¤° à¤ªà¥à¤°à¤µà¤°[/b]\r\nà¤¹à¤°à¥‡à¤• à¤µà¤‚à¤¶à¤•à¥‹à¤šà¤¿à¤¨à¤¾à¤°à¥€à¤®à¤¾ à¤—à¥‹à¤¤à¥à¤° à¤° à¤ªà¥à¤°à¤µà¤° à¤•à¥‹ à¤ à¥à¤²à¥‹ à¤­à¥à¤®à¤¿à¤•à¤¾ à¤¹à¥à¤¨à¥à¤› à¤˜à¤¿à¤®à¤¿à¤°à¥‡à¤•à¥‹ à¤—à¥‹à¤¤à¥à¤° à¤•à¤¾à¤¶à¥à¤¯à¤ª à¤¹à¥‹, à¤¯à¥‹ à¤—à¥‹à¤¤à¥à¤° à¤¬à¥à¤°à¤¾à¤¹à¥à¤®à¤¦à¥‡à¤µ à¤•à¤¾ à¤®à¤¾à¤¨à¤¸ à¤ªà¥à¤¤à¥à¤° à¤®à¤°à¤¿à¤šà¤¿ à¤•à¤¾ à¤¸à¤¨à¥à¤¤à¤¾à¤¨ à¤°à¤¿à¤¸à¥€ à¤•à¤¶à¥à¤¯à¤¾à¤ª à¤¬à¤¾à¤Ÿ à¤šà¤²à¥‡à¤•à¥‹ à¤®à¤¾à¤¨à¤¿à¤¨à¥à¤›à¥¤à¤¸à¤ªà¥à¤¤ à¤°à¤¿à¤¸à¥€ à¤…à¤°à¥à¤¥à¤¾à¤¤ à¤¸à¤¾à¤¤ à¤°à¤¿à¤¸à¥€ à¤®à¤§à¥à¤¯ à¤•à¤¶à¥à¤¯à¤¾à¤ª à¤°à¤¿à¤¸à¥€ à¤®à¤¹à¤¾à¤¨ à¤œà¥à¤žà¤¾à¤¨à¤¿ à¤¬à¥à¤¦à¥à¤¦à¤¿à¤œà¤¿à¤µà¥€ à¤­à¤à¤•à¥‹ à¤¹à¥à¤¨à¤¾à¤²à¥‡ à¤•à¤¶à¥à¤¯à¤¾à¤ª à¤°à¤¿à¤¸à¥€à¤²à¤¾à¤ˆ à¤¸à¥ƒà¤·à¥à¤Ÿà¤¿ à¤•à¤°à¥à¤¤à¤¾ à¤­à¤¨à¤¿à¤¨à¥à¤› à¤‰à¤à¤¹à¤¾à¤²à¤¾à¤‡ à¤¸à¥ƒà¤·à¥à¤Ÿà¤¿ à¤¸à¥ƒà¤œà¤¨à¤¾ à¤—à¤°à¥à¤¨à¥‡ à¤¶à¥à¤°à¥à¤¯ à¤ªà¥à¤°à¤¾à¤ªà¥à¤¤ à¤­à¤à¤•à¥‹ à¤¥à¤¿à¤¯à¥‹à¥¤à¤•à¤¶à¥à¤¯à¤¾à¤ª à¤°à¤¿à¤¸à¥€à¤²à¤¾à¤ˆ à¤ªà¥à¤°à¤¾à¤£ à¤…à¤¨à¥à¤¸à¤¾à¤° à¤§à¥‡à¤°à¥ˆ à¤œà¤¿à¤µà¤•à¥‹ à¤ªà¤¿à¤¤à¤¾ à¤ªà¤¨à¤¿ à¤­à¤¨à¤¿à¤à¤•à¥‹ à¤›à¥¤ à¤¬à¥à¤°à¤¾à¤¹à¥à¤®à¤¦à¥‡à¤µ à¤•à¤¾ à¤®à¤¾à¤¨à¤¸ à¤ªà¥à¤¤à¥à¤° à¤¸à¤ªà¥à¤¤ à¤°à¤¿à¤¸à¥€ à¤²à¤¾à¤‡ à¤­à¤—à¤µà¤¾à¤¨ à¤¶à¤¿à¤µ à¤†à¤«à¥ˆ à¤—à¥à¤°à¥ à¤­à¤à¤° à¤œà¥à¤žà¤¾à¤¨ à¤¶à¤¿à¤•à¥à¤·à¤¾ à¤¦à¤¿à¤¨à¥à¤­à¤à¤•à¥‹ à¤¥à¤¿à¤¯à¥‹, à¤¸à¤ªà¥à¤¤ à¤°à¤¿à¤¸à¥€ à¤•à¥‹ à¤¨à¤¾à¤® à¤¯à¤¸ à¤ªà¥à¤°à¤•à¤¾à¤° à¤°à¤¹à¥‡à¤•à¥‹ à¤› :- à¤•à¤¶à¥à¤¯à¤ª,à¤…à¤¤à¥à¤°à¤¿, à¤­à¤¾à¤°à¤¦à¥à¤µà¤¾à¤œ, à¤µà¤¿à¤¶à¥à¤°à¥à¤µà¤¾à¤®à¤¿à¤¤à¥à¤°, à¤—à¥Œà¤¤à¤®,à¤œà¤®à¤¦à¤—à¥à¤¨à¤¿ à¤° à¤µà¤¶à¤¿à¤·à¥à¤ à¥¤\r\n\r\nà¤ªà¥à¤°à¤µà¤° à¤¤à¤¿à¤¨ à¤ªà¥à¤°à¤•à¤¾à¤° à¤•à¤¾ à¤°à¤¹à¥‡à¤•à¤¾ à¤›à¤¨ à¤ªà¥à¤°à¤µà¤° à¤šà¥ˆ à¤—à¥‹à¤¤à¥à¤° à¤­à¤¿à¤¤à¥à¤° à¤®à¥à¤² à¤ªà¥à¤°à¥à¤–à¤¾ à¤šà¤¿à¤¨à¤¾à¤‰à¤¨à¥‡ à¤˜à¤¿à¤®à¤¿à¤°à¥‡à¤¹à¤°à¥à¤•à¥‹ à¤¹à¤•à¤®à¤¾ à¤•à¤¶à¥à¤¯à¤¾à¤ª à¤…à¤µà¤¤à¤¶à¤¾à¤° à¤° à¤¨à¥ˆà¤§à¥à¤°à¥à¤µ à¤¹à¥à¤¨, à¤¤à¥à¤°à¤¿ à¤†à¤°à¥à¤·à¤¿à¤¯ à¤ªà¥à¤°à¤µà¤° à¤­à¤¨à¤¿à¤¨à¥à¤›à¥¤\r\n\r\nà¤ªà¥à¤°à¤µà¤° à¤•à¥‹ à¤®à¤¹à¤¤à¥à¤µ à¤¯à¤œà¥à¤ž à¤—à¤°à¥à¤¦à¤¾ à¤µà¤¾ à¤¶à¤¨à¥à¤§à¥à¤¯à¤¾-à¤µà¤¨à¥à¤§à¤¨ à¤œà¤¸à¥à¤¤à¤¾ à¤¨à¤¿à¤¤à¥à¤¯ à¤•à¥à¤°à¤®à¤®à¤¾ à¤†à¤«à¥à¤¨à¥‹ à¤ªà¥à¤°à¤µà¤° à¤‰à¤šà¥à¤šà¤¾à¤¹à¤°à¤£ à¤—à¤°à¥à¤¨à¥‡ à¤šà¤²à¤¨ à¤›à¥¤ à¤¯à¤¸à¥à¤²à¥‡ à¤†à¤«à¥à¤¨à¥‹ à¤µà¤‚à¤¶ à¤ªà¤°à¤®à¤ªà¤°à¤¾ à¤° à¤¶à¥à¤¦à¥à¤§à¤§à¤¤à¤¾ à¤²à¤¾à¤ˆ à¤¸à¤®à¥à¤à¤¾à¤‰à¤›, à¤° à¤…à¤°à¥à¤•à¥‹ à¤®à¤¹à¤¤à¥à¤µà¤ªà¥à¤°à¥à¤£ à¤•à¥à¤°à¤¾ à¤à¤‰à¤Ÿà¥ˆ à¤—à¥‹à¤¤à¥à¤° à¤° à¤ªà¥à¤°à¤µà¤°à¤®à¤¾ à¤¬à¤¿à¤¹à¥‡à¤µà¤¾à¤°à¥€ à¤šà¤²à¥à¤¦à¥ˆà¤¨à¥¤ à¤à¤‰à¤Ÿà¥ˆ à¤—à¥‹à¤¤à¥à¤° à¤° à¤ªà¥à¤°à¤µà¤° à¤­à¤¿à¤¤à¥à¤° à¤¬à¤¿à¤¹à¥‡ à¤—à¤°à¥à¤¨à¥ à¤¹à¥à¤¦à¥ˆà¤¨, à¤¯à¤¸à¥à¤²à¥‡ à¤µà¤‚à¤¶ à¤­à¤¿à¤¤à¥à¤° à¤†à¤¨à¥à¤µà¤¾à¤¨à¥à¤¸à¤¿à¤• à¤µà¤¿à¤µà¤¿à¤§à¤¤à¤¾ à¤ªà¤¨à¤¿ à¤•à¤¾à¤¯à¤® à¤°à¤¾à¤–à¥à¤› à¤…à¤¨à¤¿ à¤†à¤§à¥à¤¯à¤¾à¤¤à¥à¤®à¤¿à¤• à¤¹à¤¿à¤¸à¤¾à¤µà¤²à¥‡ à¤ªà¤¨à¤¿ à¤®à¤¹à¤¤à¥à¤µà¤ªà¥à¤°à¥à¤£ à¤®à¤¾à¤¨à¤¿à¤¨à¥à¤›, à¤¬à¤¾à¤¹à¤¿à¤° à¤¬à¤¿à¤µà¤¾à¤¹ à¤—à¤°à¥à¤¨à¥‡ à¤šà¤²à¤¨ à¤¬à¤¹à¤¿à¤° à¤¬à¤¿à¤µà¤¾à¤¹ à¤¯à¤¸à¥ˆà¤®à¤¾ à¤†à¤§à¤¾à¤°à¤¿à¤¤ à¤°à¤¹à¥‡à¤•à¥‹ à¤›à¥¤ à¤šà¤¾à¤° à¤œà¤¾à¤¤ 36 à¤µà¤°à¥à¤£à¤•à¥‹ à¤¸à¤¾à¤à¤¾ à¤«à¥à¤²à¤¬à¤¾à¤°à¥€à¤®à¤¾ à¤«à¥à¤²à¥‡à¤° à¤à¤•à¤¤à¤¾à¤•à¥‹ à¤®à¤¾à¤²à¤¾à¤®à¤¾ à¤‰à¤¨à¤¿à¤à¤•à¥‹ à¤¹à¤¾à¤®à¤¿ à¤¨à¥‡à¤ªà¤¾à¤²à¥€à¤¹à¤°à¥à¤®à¤¾\r\n\r\n[b]à¤•à¥à¤² à¤¦à¥‡à¤µà¤¤à¤¾[/b]\r\nà¤¹à¤°à¥‡à¤• à¤•à¥à¤²à¤•à¤¾à¤†à¤«à¥à¤¨à¥ˆ à¤¦à¥‡à¤µà¤¤à¤¾ à¤¹à¥à¤¨à¥à¤›à¤¨ à¤¸à¤¬à¥ˆà¤•à¥‹ à¤…-à¤†à¤«à¥à¤¨à¥‹ à¤•à¥à¤² à¤¦à¥‡à¤µà¤¤à¤¾ à¤¹à¥à¤¨à¥à¤›à¤¨, à¤¸à¥à¤°à¥‹à¤¤ à¤…à¤¨à¥à¤¸à¤¾à¤° à¤˜à¤¿à¤®à¤¿à¤°à¥‡à¤•à¥‹ \r\nà¤•à¥à¤² à¤¦à¥‡à¤µà¤¤à¤¾à¤®à¤¸à¥à¤Ÿ à¤¹à¥à¤¨, à¤®à¤¸à¥à¤Ÿ à¤¦à¥‡à¤µà¤¤à¤¾ à¤–à¤¾à¤¸ à¤—à¤°à¥€ à¤ªà¤¶à¥à¤šà¤¿à¤®à¥€ à¤ªà¤¹à¤¾à¤¡à¥€ à¤–à¤¸ à¤¸à¤®à¥à¤¦à¤¾à¤¯à¤®à¤¾ à¤¨à¤¿à¤•à¥ˆ à¤®à¤¾à¤¨à¤¿à¤¨à¥à¤›à¤¨à¥¤\r\nà¤¬à¥à¤°à¤¾à¤¹ à¤­à¤¾à¤‡ à¤¬à¥à¤°à¤¹à¤¾à¤®à¤¸à¥à¤Ÿ à¤° à¤¨à¤µ à¤¦à¥à¤°à¥à¤—à¤¾ à¤­à¤—à¤¿à¤¨à¤¿à¤•à¤¾ à¤°à¥à¤ªà¤®à¤¾ à¤ªà¥à¤œà¤¾ à¤¹à¥à¤¨à¥à¤›à¥¤ \r\nà¤®à¤¸à¥à¤Ÿ à¤­à¤¨à¥‡à¤•à¤¾à¤–à¤¾à¤¸ à¤—à¤°à¥€ à¤­à¤¾à¤¨à¥à¤œà¤¾ à¤¹à¥à¤¨ à¤•à¥à¤² à¤¦à¥‡à¤µà¤¤à¤¾ à¤¹à¥à¤¨, à¤¬à¥à¤°à¤¾à¤¹ à¤­à¤¾à¤‡ à¤®à¤¾à¤®à¤¾à¤¹à¤°à¥à¤²à¥‡ à¤–à¤¿à¤° à¤ªà¤•à¤¾à¤à¤•à¤¾, à¤–à¤¿à¤° à¤–à¤¾à¤¨à¥‡ à¤•à¥à¤°à¤®à¤®à¤¾ à¤­à¤¾à¤¨à¥à¤œà¤¾à¤²à¤¾à¤‡ à¤—à¥‹à¤ à¤®à¤¾ à¤°à¤¹à¥‡à¤•à¥‹ à¤—à¤¾à¤à¤‡ à¤­à¥‹à¤•à¥‹ à¤°à¤¹à¥‡à¤•à¥‹ à¤—à¥‹à¤ à¤®à¤¾ à¤—à¤‡ à¤‰à¤•à¥à¤¤ à¤—à¤¾à¤à¤‡à¤²à¤¾à¤‡ à¤˜à¤¾à¤à¤¸ à¤¹à¤¾à¤²à¤¿à¤¦à¤¿à¤¨à¥ à¤­à¤¨à¥à¤¨à¥‡ à¤†à¤¦à¥‡à¤¶ à¤­à¤ à¤ªà¤›à¤¿ à¤­à¤¾à¤¨à¥à¤œà¤¾ à¤¶à¥à¤°à¤¿ à¤—à¥‹à¤ à¤®à¤¾ à¤ªà¥à¤—à¤¿ à¤—à¤¾à¤à¤‡à¤²à¤¾à¤‡ à¤˜à¤¾à¤à¤¸ à¤¹à¤¾à¤²à¤¿à¤¸à¤•à¥‡ à¤ªà¤›à¤¿ à¤«à¤à¤°à¥à¤•à¤¦à¤¾ à¤®à¤¾à¤®à¤¾ à¤¹à¤°à¥à¤²à¥‡ à¤–à¤¿à¤° à¤–à¤¾à¤à¤° à¤¸à¤•à¤¿à¤¸à¤•à¥‡à¤•à¤¾,à¤­à¤¾à¤¨à¥à¤œà¤¾ à¤•à¥à¤°à¥‹à¤§ à¤†à¤µà¥‡à¤—à¤®à¤¾ à¤†à¤‡ à¤‰à¤•à¥à¤¤ à¤—à¥‹à¤ à¤®à¤¾ à¤—à¤‡ à¤à¥à¤¨à¥à¤¦à¤¿à¤à¤° à¤¨à¤¿à¤§à¤¨ à¤­à¤à¤•à¥‹ à¤¯à¤¥à¤¾à¤°à¥à¤¤ à¤ªà¥à¤°à¤®à¤¾à¤£ à¤°à¤¹à¥‡à¤•à¥‹ à¤›, à¤¤à¥à¤¯à¤¹à¤¿ à¤¯à¤¥à¤¾à¤°à¥à¤¤ à¤…à¤¨à¥à¤¸à¤¾à¤° à¤•à¥à¤¨à¥ˆ à¤ªà¥à¤œà¤¾à¤®à¤¾ à¤®à¤¸à¥à¤Ÿ à¤¬à¥à¤°à¤¾à¤¹ à¤²à¤¾à¤ˆ à¤¸à¥à¤°à¥à¤®à¤¾ à¤–à¤¿à¤° à¤šà¤¦à¤¾à¤‰à¤¨à¥‡ à¤° à¤—à¥‹à¤ à¤®à¤¾ à¤§à¤¾à¤° à¤§à¥à¤ª à¤¦à¤¿à¤¨à¥‡ à¤šà¤²à¤¨ à¤°à¤¹à¥‡à¤•à¥‹ à¤›à¥¤\r\n\r\nà¤ªà¤¶à¥à¤šà¤¿à¤® à¤¤à¤¿à¤° à¤®à¤¸à¥à¤Ÿ à¤•à¥‹ à¤•à¥à¤² à¤ªà¥à¤œà¤¾ à¤µà¤¿à¤¶à¥‡à¤· à¤µà¤¿à¤§à¤¿ à¤…à¤¨à¥à¤¸à¤¾à¤° à¤ªà¥à¤°à¤¾à¤¯ à¤¦à¤¶à¥ˆ à¤° à¤®à¤¾à¤‚à¤˜à¥‡ à¤¸à¤‚à¤•à¥à¤°à¤¾à¤¨à¥à¤¤à¤¿à¤®à¤¾ à¤—à¤°à¥à¤¨à¥‡ à¤šà¤²à¤¨ à¤›, \r\nà¤ªà¥à¤°à¥à¤µ à¤¤à¤¿à¤° à¤¬à¥ˆà¤¸à¤¾à¤– à¤ªà¥à¤°à¥à¤¨à¤¿à¤®à¤¾à¤° à¤®à¤‚à¤¸à¤¿à¤° à¤ªà¥à¤°à¥à¤¨à¤¿à¤®à¤¾ à¤—à¤°à¥à¤¨à¥‡ à¤šà¤²à¤¨ à¤› à¤° à¤®à¤§à¥à¤¯ à¤­à¥‡à¤— à¤®à¤§à¥à¤¯ à¤ªà¤¹à¤¾à¤¡à¤®à¤¾ à¤¸à¤¾à¤‰à¤¨à¥‡ à¤”à¤‚à¤¸à¥€ à¤° à¤®à¤‚à¤¸à¤¿à¤° à¤ªà¥à¤°à¥à¤¨à¤¿à¤®à¤¾ à¤®à¤¾ à¤®à¤¸à¥à¤Ÿ à¤•à¥‹ à¤•à¥à¤² à¤ªà¥à¤œà¤¾ à¤ªà¥à¤°à¥à¤–à¤¾à¤²à¥‡ à¤—à¤°à¥à¤¦à¥ˆ à¤†à¤à¤•à¥‹ à¤šà¤²à¤¨à¤šà¤²à¥à¤¤à¤¿ à¤° à¤µà¤¿à¤§à¤¿ à¤…à¤¨à¥à¤¸à¤¾à¤° à¤—à¤°à¤¿à¤à¤•à¥‹ à¤›à¥¤\r\nà¤®à¤¸à¥à¤Ÿ à¤•à¥‹à¤•à¥à¤² à¤ªà¥à¤œà¤¾ à¤šà¤¾à¤®à¤² à¤Ÿà¤¿à¤•à¤¾ à¤§à¥à¤ª à¤¦à¤¿à¤ª à¤¬à¤¾à¤²à¥‡à¤° à¤° à¤•à¤¤à¤¿à¤ªà¤¯ à¤…à¤µà¤¸à¥à¤¥à¤¾à¤®à¤¾ à¤ªà¤¶à¥ à¤¬à¤²à¤¿ à¤¸à¤¹à¤¿à¤¤ à¤ªà¤¨à¤¿ à¤ªà¥à¤œà¤¾ à¤¹à¥à¤¨à¥à¤›, à¤¦à¥‹à¤²à¤–à¤¾ à¤° à¤•à¤°à¥à¤£à¤¾à¤²à¥€ à¤¤à¤¿à¤° à¤à¤¾à¤•à¥à¤°à¤¿à¤²à¥‡ \r\nà¤®à¤¸à¥à¤Ÿ à¤¦à¥‡à¤µà¤¤à¤¾à¤²à¤¾à¤ˆ à¤¶à¤°à¤¿à¤°à¤®à¤¾à¤‰à¤¤à¤¾à¤°à¥‡à¤° à¤ªà¥à¤œà¤¾ à¤—à¤°à¥à¤¨à¥‡ à¤ªà¤°à¤®à¤ªà¤°à¤¾ à¤ªà¤¾à¤‡à¤¨à¥à¤›à¥¤ à¤¶à¤¨à¤¾à¤°à¥à¤¤à¤¨ à¤§à¤°à¥à¤®à¤•à¥‹ à¤¸à¤®à¤¾à¤µà¥‡à¤¶à¥€ à¤šà¤°à¤¿à¤¤à¥à¤°à¤•à¥‹ à¤°à¤¾à¤®à¥à¤°à¥‹ à¤‰à¤¦à¤¾à¤¹à¤°à¤£à¥€à¤¯ à¤µà¥ˆà¤¦à¥à¤§à¤¿à¤• à¤ªà¤°à¤®à¤ªà¤°à¤¾ à¤° à¤¸à¥à¤¥à¤¾à¤¨à¤¿à¤¯ à¤²à¥‹à¤• à¤µà¤¿à¤¶à¥à¤µà¤¾à¤¸ à¤œà¤¸à¥à¤¤à¥ˆ à¤¨à¤¾à¤— à¤ªà¥à¤œà¤¾ à¤­à¥à¤®à¤¿ à¤ªà¥à¤œà¤¾ à¤ªà¤¨à¤¿ à¤®à¤¿à¤¸à¤¿à¤à¤•à¥‹ à¤›à¥¤\r\n\r\n[b]à¤¸à¤¾à¤®à¤¾à¤œà¤¿à¤• à¤µà¤°à¥à¤—à¥€à¤•à¤°à¤£[/b]\r\nà¤˜à¤¿à¤®à¤¿à¤°à¥‡à¤¹à¤°à¥à¤²à¤¾à¤ˆ à¤ªà¥à¤°à¥à¤µà¤¿à¤¯à¤¾ à¤‰à¤ª à¤¸à¤®à¥à¤¹ à¤…à¤¨à¥à¤¸à¤¾à¤° à¤‰à¤ªà¤¾à¤§à¥à¤¯à¤¾à¤¯ à¤¬à¤¾à¤¹à¥à¤¨ à¤…à¤¨à¥à¤¤à¤°à¤—à¤¤ à¤®à¤¾à¤¨à¤¿à¤¨à¥à¤› à¤¬à¤¸à¤¾à¤‡ à¤¸à¤°à¤¾à¤‡à¤•à¥‹ à¤†à¤§à¤¾à¤°à¤®à¤¾ à¤•à¤°à¥à¤£à¤¾à¤²à¥€ à¤¨à¤¦à¤¿à¤²à¤¾à¤ˆ à¤†à¤§à¤¾à¤° à¤®à¤¾à¤¨à¥‡à¤° à¤­à¥Œà¤—à¥‹à¤²à¤¿à¤• à¤ªà¤¹à¤¿à¤šà¤¾à¤¨à¤®à¤¾ à¤¦à¥à¤ˆ à¤ à¤¾à¤à¤‰à¤®à¤¾ à¤µà¤¿à¤­à¤¾à¤œà¤¨ à¤—à¤°à¤¿à¤à¤•à¥‹ à¤›à¥¤à¤ªà¥à¤°à¥à¤µ à¤¤à¤¿à¤° à¤¬à¤¸à¥‹à¤¬à¤¾à¤¸ à¤—à¤°à¥à¤¨à¥‡à¤²à¤¾à¤‡ à¤ªà¥à¤°à¥à¤µà¤¿à¤¯à¤¾ à¤° à¤ªà¤¶à¥à¤šà¤¿à¤® à¤¤à¤¿à¤° à¤¬à¤¸à¥‹à¤¬à¤¾à¤¸ à¤—à¤°à¥à¤¨à¥‡à¤²à¤¾à¤‡ à¤•à¥à¤®à¤¾à¤ˆ (à¤‰à¤®à¤¾à¤‡) à¤­à¤¨à¥à¤¨à¥‡ à¤šà¤²à¤¨ à¤šà¤²à¥‡à¤•à¥‹ à¤¹à¥‹à¥¤à¤¸à¤¾à¤®à¤¾à¤œà¤¿à¤• à¤¤à¤¹à¤®à¤¾ à¤¯à¤¸à¤®à¤¾ à¤•à¥‹ à¤ à¥à¤²à¥‹ à¤•à¥‹ à¤¸à¤¾à¤¨à¥‹ à¤­à¤¨à¥à¤¨à¥‡ à¤šà¥ˆ à¤¹à¥‹à¤‡à¤¨à¥¤\r\n\r\nà¤ªà¤¹à¤¿à¤²à¥‡à¤•à¥‹ à¤¸à¤®à¤¯à¤®à¤¾ à¤¸à¤®à¤¸à¥à¤¤ à¤˜à¤¿à¤®à¤¿à¤°à¥‡à¤¹à¤°à¥ à¤‰à¤ªà¤¾à¤§à¥à¤¯à¤¾à¤¯ à¤¬à¤¾à¤¹à¥à¤¨ à¤¹à¥à¤¨à¥à¤¹à¥à¤¨à¥à¤¥à¥à¤¯à¥‹,à¤‰à¤ªà¤¾à¤§à¥à¤¯à¤¾à¤¯à¤•à¥‹ à¤…à¤°à¥à¤¥ à¤­à¤¨à¥‡à¤•à¥‹ à¤µà¥‡à¤¦ à¤ªà¥à¤°à¤¾à¤£ à¤µà¥‡à¤¦à¤¾à¤™à¥à¤— à¤ªà¤¢à¤¾à¤‰à¤¨à¥‡ à¤œà¤¾à¤¨à¥à¤¨à¥‡ à¤…à¤°à¥à¤¥à¤¾à¤¤ à¤µà¤¿à¤¦à¥à¤§à¤µà¤¾à¤¨ à¤ªà¥à¤°à¥‹à¤¹à¤¿à¤¤ à¤­à¤¨à¥à¤¨à¥‡ à¤¬à¥à¤à¤¿à¤¨à¥à¤›à¥¤à¤…à¤¹à¤¿à¤²à¥‡à¤•à¥‹ à¤¸à¤®à¤¯à¤®à¤¾ à¤•à¤¤à¤¿à¤ªà¤¯ à¤˜à¤¿à¤®à¤¿à¤°à¥‡à¤¹à¤°à¥ à¤‰à¤ªà¤¾à¤§à¥à¤¯à¤¾à¤¯ à¤¬à¤¾à¤¹à¥à¤¨ à¤¦à¥‡à¤–à¤¿ à¤–à¤¸à¥‡à¤° à¤œà¥ˆà¤¸à¥€ à¤ªà¤¨à¤¿ à¤¹à¥à¤¨à¥à¤¹à¥à¤¨à¥à¤›, à¤¤à¥à¤¯à¤¤à¤¿ à¤¬à¥‡à¤²à¤¾ à¤¬à¥‡à¤‡à¤¤à¤¾ à¤° à¤²à¥‡à¤‡à¤¤à¤¾ à¤­à¤¨à¥à¤¨à¥‡ à¤šà¤²à¤¨ à¤¥à¤¿à¤¯à¥‹à¥¤\r\nà¤®à¤¾à¤—à¥‡à¤° à¤•à¤¨à¥à¤¯à¤¾à¤¦à¤¾à¤¨ à¤—à¤°à¤¿à¤¬à¤¿à¤µà¤¾à¤¹ à¤—à¤°à¥‡à¤•à¥‹ à¤²à¤¾à¤‡ à¤¬à¥‡à¤‡à¤¤à¤¾ à¤­à¤¨à¥à¤¨à¥‡ à¤šà¤²à¤¨ à¤¥à¤¿à¤¯à¥‹ à¤° à¤‰à¤¨à¤•à¤¾ à¤¸à¤¨à¤¤à¤¾à¤¨ à¤²à¤¾à¤ˆ à¤‰à¤ªà¤¾à¤§à¥à¤¯à¤¾à¤¯  à¤˜à¤¿à¤®à¤¿à¤°à¥‡à¤•à¥‹ à¤°à¥à¤ªà¤®à¤¾ à¤šà¤¿à¤¨à¤¿à¤¨à¥à¤› à¤­à¤¨à¥‡ à¤†à¤«à¥à¤¨à¥ˆ à¤®à¤¨ à¤®à¤°à¥à¤œà¤¿à¤²à¥‡ à¤®à¤¹à¤¿à¤²à¤¾ (à¤¬à¤¿à¤¦à¥à¤µà¤¾) à¤¬à¤¿à¤µà¤¾à¤¹ à¤—à¤°à¥‡à¤•à¥‹ à¤²à¤¾à¤‡ à¤µà¤¾ à¤¦à¥‹à¤¸à¥à¤°à¥‹ à¤¬à¤¿à¤µà¤¾à¤¹ à¤—à¤°à¥‡à¤•à¥‹ à¤²à¤¾à¤‡ à¤²à¥‡à¤‡à¤¤à¤¾ à¤­à¤¨à¥à¤¨à¥‡ à¤šà¤²à¤¨ à¤¥à¤¿à¤¯à¥‹ à¤° à¤‰à¤¨à¤•à¤¾ à¤¸à¤¨à¤¤à¤¾à¤¨ à¤²à¤¾à¤ˆ à¤œà¥ˆà¤¸à¥€ à¤˜à¤¿à¤®à¤¿à¤°à¥‡à¤•à¥‹ à¤°à¥à¤ªà¤®à¤¾ à¤šà¤¿à¤¨à¤¿à¤¨à¥à¤›\r\n[/quote]', 1),
('privacy-policy', 3, 'fas fa-user-secret', 1586271295, 'Privacy Policy', '[size=6]à¤—à¥‹à¤ªà¤¨à¥€à¤¯à¤¤à¤¾ à¤¨à¥€à¤¤à¤¿[/size]\r\n\r\nà¤¯à¥‹ à¤—à¥‹à¤ªà¤¨à¥€à¤¯à¤¤à¤¾ à¤¨à¥€à¤¤à¤¿ à¤‰à¤•à¥à¤¤ website à¤®à¤¾ à¤‰à¤ªà¤²à¤¬à¥à¤§ Ghimire Family à¤µà¥‡à¤¬à¤¸à¤¾à¤‡à¤Ÿà¤•à¥‹ à¤²à¤¾à¤—à¤¿ à¤²à¤¾à¤—à¥‚ à¤¹à¥à¤¨à¥à¤›à¥¤ à¤®à¥‡à¤°à¥‹ à¤®à¥à¤–à¥à¤¯ à¤ªà¥à¤°à¤¾à¤¥à¤®à¤¿à¤•à¤¤à¤¾à¤¹à¤°à¥‚à¤®à¤¾ à¤à¤• à¤¤à¤ªà¤¾à¤ˆà¤‚à¤¹à¤°à¥‚à¤•à¥‹ à¤—à¥‹à¤ªà¤¨à¥€à¤¯à¤¤à¤¾ à¤¹à¥‹à¥¤ à¤¯à¤¸ à¤—à¥‹à¤ªà¤¨à¥€à¤¯à¤¤à¤¾ à¤¨à¥€à¤¤à¤¿à¤®à¤¾ à¤®à¤²à¥‡ à¤¸à¤™à¥à¤•à¤²à¤¨ à¤—à¤°à¥à¤¨à¥‡ à¤° à¤°à¥‡à¤•à¤°à¥à¤¡ à¤—à¤°à¥à¤¨à¥‡ à¤œà¤¾à¤¨à¤•à¤¾à¤°à¥€à¤•à¤¾ à¤ªà¥à¤°à¤•à¤¾à¤°à¤¹à¤°à¥‚ à¤° à¤® à¤¯à¤¸à¤²à¤¾à¤ˆ à¤•à¤¸à¤°à¥€ à¤ªà¥à¤°à¤¯à¥‹à¤— à¤—à¤°à¥à¤›à¥ à¤­à¤¨à¥à¤¨à¥‡ à¤¬à¤¾à¤°à¥‡ à¤¸à¤®à¤¾à¤µà¥‡à¤¶ à¤—à¤°à¤¿à¤à¤•à¥‹ à¤›à¥¤\r\n\r\nà¤¯à¤¦à¤¿ à¤¤à¤ªà¤¾à¤ˆà¤‚à¤¸à¤à¤— à¤®à¥‡à¤°à¥‹ à¤—à¥‹à¤ªà¤¨à¥€à¤¯à¤¤à¤¾ à¤¨à¥€à¤¤à¤¿à¤•à¥‹ à¤¬à¤¾à¤°à¥‡à¤®à¤¾ à¤¥à¤ª à¤ªà¥à¤°à¤¶à¥à¤¨à¤¹à¤°à¥‚ à¤›à¤¨à¥ à¤µà¤¾ à¤¥à¤ª à¤œà¤¾à¤¨à¤•à¤¾à¤°à¥€ à¤šà¤¾à¤¹à¤¨à¥à¤¹à¥à¤¨à¥à¤› à¤­à¤¨à¥‡, à¤•à¥ƒà¤ªà¤¯à¤¾ à¤®à¤²à¤¾à¤ˆ à¤¯à¥€ à¤®à¤¾à¤§à¥à¤¯à¤®à¤¬à¤¾à¤Ÿ à¤¸à¤®à¥à¤ªà¤°à¥à¤• à¤—à¤°à¥à¤¨à¥à¤¹à¥‹à¤¸à¥:\r\n[url=https://www.facebook.com/shyamchhetri0]à¤«à¥‡à¤¸à¤¬à¥à¤•[/url] à¤µà¤¾[url=https://wa.me/+9779867366483]à¤µà¥à¤¹à¤¾à¤Ÿà¥à¤¸à¤à¤ª[/url]\r\n\r\nà¤¯à¥‹ à¤—à¥‹à¤ªà¤¨à¥€à¤¯à¤¤à¤¾ à¤¨à¥€à¤¤à¤¿ à¤…à¤¨à¤²à¤¾à¤‡à¤¨ à¤—à¤¤à¤¿à¤µà¤¿à¤§à¤¿à¤¹à¤°à¥‚à¤®à¤¾ à¤®à¤¾à¤¤à¥à¤° à¤²à¤¾à¤—à¥‚ à¤¹à¥à¤¨à¥à¤› à¤° à¤¯à¤¸ à¤µà¥‡à¤¬à¤¸à¤¾à¤‡à¤Ÿà¤®à¤¾ à¤­à¥à¤°à¤®à¤£à¤•à¤°à¥à¤¤à¤¾à¤¹à¤°à¥‚à¤²à¥‡ à¤¸à¤¾à¤à¤¾ à¤—à¤°à¥‡à¤•à¥‹ à¤°/à¤µà¤¾ à¤¸à¤™à¥à¤•à¤²à¤¨ à¤—à¤°à¤¿à¤à¤•à¥‹ à¤œà¤¾à¤¨à¤•à¤¾à¤°à¥€à¤•à¥‹ à¤¸à¤®à¥à¤¬à¤¨à¥à¤§à¤®à¤¾ à¤®à¤¾à¤¨à¥à¤¯ à¤¹à¥à¤¨à¥à¤›à¥¤ à¤¯à¥‹ à¤¨à¥€à¤¤à¤¿ à¤…à¤«à¤²à¤¾à¤‡à¤¨ à¤µà¤¾ à¤¯à¤¸ à¤µà¥‡à¤¬à¤¸à¤¾à¤‡à¤Ÿ à¤­à¤¨à¥à¤¦à¤¾ à¤…à¤¨à¥à¤¯ à¤®à¤¾à¤§à¥à¤¯à¤®à¤¬à¤¾à¤Ÿ à¤¸à¤™à¥à¤•à¤²à¤¨ à¤—à¤°à¤¿à¤à¤•à¥‹ à¤•à¥à¤¨à¥ˆ à¤ªà¤¨à¤¿ à¤œà¤¾à¤¨à¤•à¤¾à¤°à¥€à¤®à¤¾ à¤²à¤¾à¤—à¥‚ à¤¹à¥à¤à¤¦à¥ˆà¤¨à¥¤\r\n\r\n[b]à¤¸à¤¹à¤®à¤¤à¤¿[/b]\r\n\r\nà¤®à¥‡à¤°à¥‹ à¤µà¥‡à¤¬à¤¸à¤¾à¤‡à¤Ÿ à¤ªà¥à¤°à¤¯à¥‹à¤— à¤—à¤°à¥‡à¤°, à¤¤à¤ªà¤¾à¤ˆà¤‚à¤²à¥‡ à¤¯à¤¸ à¤—à¥‹à¤ªà¤¨à¥€à¤¯à¤¤à¤¾ à¤¨à¥€à¤¤à¤¿à¤²à¤¾à¤ˆ à¤¸à¥à¤µà¥€à¤•à¤¾à¤° à¤—à¤°à¥à¤¨à¥à¤­à¤à¤•à¥‹ à¤° à¤¯à¤¸à¤•à¥‹ à¤¸à¤°à¥à¤¤à¤¹à¤°à¥‚à¤¸à¤à¤— à¤¸à¤¹à¤®à¤¤ à¤¹à¥à¤¨à¥à¤­à¤à¤•à¥‹ à¤®à¤¾à¤¨à¤¿à¤¨à¥à¤›à¥¤\r\n\r\nà¤®à¥ˆà¤²à¥‡ à¤¸à¤™à¥à¤•à¤²à¤¨ à¤—à¤°à¥à¤¨à¥‡ à¤œà¤¾à¤¨à¤•à¤¾à¤°à¥€\r\nà¤¤à¤ªà¤¾à¤ˆà¤‚à¤²à¤¾à¤‡ à¤ªà¥à¤°à¤¦à¤¾à¤¨ à¤—à¤°à¥à¤¨ à¤²à¤—à¤¾à¤‡à¤à¤•à¥‹ à¤µà¥à¤¯à¤•à¥à¤¤à¤¿à¤—à¤¤ à¤œà¤¾à¤¨à¤•à¤¾à¤°à¥€, à¤° à¤¤à¤ªà¤¾à¤ˆà¤‚à¤²à¤¾à¤ˆ à¤¯à¥‹ à¤•à¤¿à¤¨ à¤ªà¥à¤°à¤¦à¤¾à¤¨ à¤—à¤°à¥à¤¨ à¤²à¤—à¤¾à¤‡à¤à¤•à¥‹ à¤­à¤¨à¥à¤¨à¥‡ à¤•à¤¾à¤°à¤£à¤¹à¤°à¥‚, à¤¤à¤ªà¤¾à¤ˆà¤‚à¤²à¥‡ à¤†à¤«à¥à¤¨à¥‹ à¤µà¥à¤¯à¤•à¥à¤¤à¤¿à¤—à¤¤ à¤œà¤¾à¤¨à¤•à¤¾à¤°à¥€ à¤ªà¥à¤°à¤¦à¤¾à¤¨ à¤—à¤°à¥à¤¨à¥‡ à¤¬à¤¿à¤¨à¥à¤¦à¥à¤®à¤¾ à¤¤à¤ªà¤¾à¤ˆà¤‚à¤²à¤¾à¤ˆ à¤¸à¥à¤ªà¤·à¥à¤Ÿ à¤°à¥‚à¤ªà¤®à¤¾ à¤¬à¤¤à¤¾à¤‰à¤¨à¥‡ à¤›à¥à¥¤\r\nà¤¯à¤¦à¤¿à¤¤à¤ªà¤¾à¤ˆà¤‚à¤²à¥‡ à¤®à¤²à¤¾à¤ˆ à¤¸à¥€à¤§à¥ˆ à¤¸à¤®à¥à¤ªà¤°à¥à¤• à¤—à¤°à¥à¤¨à¥à¤­à¤¯à¥‹ à¤­à¤¨à¥‡, à¤®à¥ˆà¤²à¥‡ à¤¤à¤ªà¤¾à¤ˆà¤‚à¤•à¥‹ à¤¬à¤¾à¤°à¥‡à¤®à¤¾ à¤¥à¤ª à¤œà¤¾à¤¨à¤•à¤¾à¤°à¥€ à¤ªà¥à¤°à¤¾à¤ªà¥à¤¤ à¤—à¤°à¥à¤¨ à¤¸à¤•à¥à¤›à¥ à¤œà¤¸à¥à¤¤à¥ˆ à¤¤à¤ªà¤¾à¤ˆà¤‚à¤•à¥‹ à¤¨à¤¾à¤®, à¤‡à¤®à¥‡à¤² à¤ à¥‡à¤—à¤¾à¤¨à¤¾, à¤«à¥‹à¤¨ à¤¨à¤®à¥à¤¬à¤°, à¤¤à¤ªà¤¾à¤ˆà¤‚à¤²à¥‡ à¤®à¤²à¤¾à¤ˆ à¤ªà¤ à¤¾à¤‰à¤¨ à¤¸à¤•à¥à¤¨à¥à¤¹à¥à¤¨à¥‡ à¤¸à¤¨à¥à¤¦à¥‡à¤¶ à¤°/à¤µà¤¾ à¤…à¤¨à¥à¤²à¤—à¥à¤¨à¤•à¤¹à¤°à¥‚à¤•à¥‹ à¤¸à¤¾à¤®à¤—à¥à¤°à¥€, à¤° à¤¤à¤ªà¤¾à¤ˆà¤‚à¤²à¥‡ à¤ªà¥à¤°à¤¦à¤¾à¤¨ à¤—à¤°à¥à¤¨ à¤°à¥‹à¤œà¥à¤¨ à¤¸à¤•à¥à¤¨à¥à¤¹à¥à¤¨à¥‡ à¤•à¥à¤¨à¥ˆ à¤ªà¤¨à¤¿ à¤…à¤¨à¥à¤¯ à¤œà¤¾à¤¨à¤•à¤¾à¤°à¥€à¥¤\r\nà¤œà¤¬ à¤¤à¤ªà¤¾à¤ˆà¤‚à¤²à¥‡à¤–à¤¾à¤¤à¤¾à¤•à¥‹ à¤²à¤¾à¤—à¤¿ à¤¦à¤°à¥à¤¤à¤¾ à¤—à¤°à¥à¤¨à¥à¤¹à¥à¤¨à¥à¤›, à¤®à¥ˆà¤²à¥‡ à¤¤à¤ªà¤¾à¤ˆà¤‚à¤•à¥‹ à¤¸à¤®à¥à¤ªà¤°à¥à¤• à¤œà¤¾à¤¨à¤•à¤¾à¤°à¥€, à¤œà¤¸à¥à¤¤à¥ˆ à¤¨à¤¾à¤®, à¤•à¤®à¥à¤ªà¤¨à¥€à¤•à¥‹ à¤¨à¤¾à¤®, à¤ à¥‡à¤—à¤¾à¤¨à¤¾, à¤‡à¤®à¥‡à¤² à¤ à¥‡à¤—à¤¾à¤¨à¤¾, à¤° à¤Ÿà¥‡à¤²à¤¿à¤«à¥‹à¤¨ à¤¨à¤®à¥à¤¬à¤° à¤œà¤¸à¥à¤¤à¤¾ à¤µà¤¸à¥à¤¤à¥à¤¹à¤°à¥‚ à¤¸à¥‹à¤§à¥à¤¨ à¤¸à¤•à¥à¤›à¥à¥¤\r\n\r\nà¤®à¥ˆà¤²à¥‡ à¤¤à¤ªà¤¾à¤ˆà¤‚à¤•à¥‹ à¤œà¤¾à¤¨à¤•à¤¾à¤°à¥€à¤²à¤¾à¤ˆ à¤•à¤¸à¤°à¥€ à¤ªà¥à¤°à¤¯à¥‹à¤— à¤—à¤°à¥à¤›à¥\r\nà¤®à¥ˆà¤²à¥‡à¤¸à¤™à¥à¤•à¤²à¤¨ à¤—à¤°à¥‡à¤•à¥‹ à¤œà¤¾à¤¨à¤•à¤¾à¤°à¥€à¤²à¤¾à¤ˆ à¤µà¤¿à¤­à¤¿à¤¨à¥à¤¨ à¤ªà¥à¤°à¤•à¤¾à¤°à¤²à¥‡ à¤ªà¥à¤°à¤¯à¥‹à¤— à¤—à¤°à¥à¤›à¥, à¤œà¤¸à¤®à¤¾ à¤¨à¤¿à¤®à¥à¤¨ à¤¶à¤¾à¤®à¤¿à¤² à¤›à¤¨à¥:\r\n[ul]\r\n[li]à¤®à¥‡à¤°à¥‹à¤µà¥‡à¤¬à¤¸à¤¾à¤‡à¤Ÿà¤²à¤¾à¤ˆ à¤ªà¥à¤°à¤¦à¤¾à¤¨, à¤¸à¤žà¥à¤šà¤¾à¤²à¤¨, à¤° à¤•à¤¾à¤¯à¤® à¤°à¤¾à¤–à¥à¤¨[/li]\r\n[li]à¤®à¥‡à¤°à¥‹ à¤µà¥‡à¤¬à¤¸à¤¾à¤‡à¤Ÿà¤²à¤¾à¤ˆ à¤¸à¥à¤§à¤¾à¤° à¤¤à¤¥à¤¾ à¤¸à¤‚à¤¸à¥à¤¥à¤¾à¤—à¤¤ à¤¬à¤¨à¤¾à¤‰à¤¨, à¤° à¤µà¤¿à¤¸à¥à¤¤à¤¾à¤° à¤—à¤°à¥à¤¨[/li]\r\n[li]à¤¤à¤ªà¤¾à¤ˆà¤‚à¤²à¥‡ à¤®à¥‡à¤°à¥‹ à¤µà¥‡à¤¬à¤¸à¤¾à¤‡à¤Ÿà¤²à¤¾à¤ˆ à¤•à¤¸à¤°à¥€ à¤ªà¥à¤°à¤¯à¥‹à¤— à¤—à¤°à¥à¤¨à¥à¤¹à¥à¤¨à¥à¤› à¤­à¤¨à¥à¤¨à¥‡ à¤•à¥à¤°à¤¾ à¤¬à¥à¤à¥à¤¨ à¤° à¤µà¤¿à¤¶à¥à¤²à¥‡à¤·à¤£ à¤—à¤°à¥à¤¨[/li]\r\n[li]à¤¨à¤¯à¤¾à¤ à¤‰à¤¤à¥à¤ªà¤¾à¤¦à¤¨à¤¹à¤°à¥‚, à¤¸à¥‡à¤µà¤¾à¤¹à¤°à¥‚, à¤µà¤¿à¤¶à¥‡à¤·à¤¤à¤¾à¤¹à¤°à¥‚, à¤° à¤•à¤¾à¤°à¥à¤¯à¤•à¥à¤·à¤®à¤¤à¤¾à¤¹à¤°à¥‚ à¤µà¤¿à¤•à¤¾à¤¸ à¤—à¤°à¥à¤¨[/li]\r\n[li]à¤¤à¤ªà¤¾à¤ˆà¤‚à¤¸à¤à¤— à¤¸à¥€à¤§à¥ˆ à¤¸à¤®à¥à¤ªà¤°à¥à¤• à¤—à¤°à¥à¤¨, à¤œà¤¸à¤®à¤¾ à¤—à¥à¤°à¤¾à¤¹à¤• à¤¸à¥‡à¤µà¤¾, à¤µà¥‡à¤¬à¤¸à¤¾à¤‡à¤Ÿà¤¸à¤à¤— à¤¸à¤®à¥à¤¬à¤¨à¥à¤§à¤¿à¤¤ à¤…à¤ªà¤¡à¥‡à¤Ÿ à¤° à¤…à¤¨à¥à¤¯ à¤œà¤¾à¤¨à¤•à¤¾à¤°à¥€ à¤ªà¥à¤°à¤¦à¤¾à¤¨ à¤—à¤°à¥à¤¨, à¤° à¤µà¤¿à¤µà¤£à¤¨ à¤° à¤ªà¥à¤°à¤šà¤¾à¤°à¤•à¥‹ à¤²à¤¾à¤—à¤¿ à¤¸à¤®à¤¾à¤µà¥‡à¤¶ à¤›[/li]\r\n[li]à¤¤à¤ªà¤¾à¤ˆà¤‚à¤²à¤¾à¤ˆ à¤‡à¤®à¥‡à¤²à¤¹à¤°à¥‚ à¤ªà¤ à¤¾à¤‰à¤¨[/li]\r\n[li]à¤•à¤ªà¤Ÿà¤ªà¥‚à¤°à¥à¤£ à¤•à¤¾à¤°à¥à¤¯à¤¹à¤°à¥‚ à¤ªà¤¤à¥à¤¤à¤¾ à¤²à¤—à¤¾à¤‰à¤¨ à¤° à¤°à¥‹à¤•à¤¥à¤¾à¤® à¤—à¤°à¥à¤¨[/li]\r\n[/ul]\r\n\r\n[b]à¤²à¤— à¤«à¤¾à¤‡à¤²à¤¹à¤°à¥‚[/b]\r\n\r\nà¤®à¥ˆà¤²à¥‡ à¤²à¤— à¤«à¤¾à¤‡à¤²à¤¹à¤°à¥‚ à¤ªà¥à¤°à¤¯à¥‹à¤— à¤—à¤°à¥à¤¨à¥‡ à¤à¤• à¤®à¤¾à¤¨à¤• à¤ªà¥à¤°à¤•à¥à¤°à¤¿à¤¯à¤¾ à¤ªà¤¾à¤²à¤¨à¤¾ à¤—à¤°à¥à¤¦à¤›à¥à¥¤ à¤¯à¥€ à¤«à¤¾à¤‡à¤²à¤¹à¤°à¥‚à¤²à¥‡ à¤­à¥à¤°à¤®à¤£à¤•à¤°à¥à¤¤à¤¾à¤¹à¤°à¥‚à¤²à¥‡ à¤µà¥‡à¤¬à¤¸à¤¾à¤‡à¤Ÿà¤¹à¤°à¥‚ à¤­à¥à¤°à¤®à¤£ à¤—à¤°à¥à¤¦à¤¾ à¤¤à¤¿à¤¨à¥€à¤¹à¤°à¥‚à¤²à¤¾à¤ˆ à¤²à¤— à¤—à¤°à¥à¤¦à¤›à¤¨à¥à¥¤ à¤¸à¤¬à¥ˆ à¤¹à¥‹à¤¸à¥à¤Ÿà¤¿à¤™ à¤•à¤®à¥à¤ªà¤¨à¥€à¤¹à¤°à¥‚à¤²à¥‡ à¤¯à¤¸à¤²à¤¾à¤ˆ à¤—à¤°à¥à¤¦à¤›à¤¨à¥ à¤° à¤¯à¥‹ à¤¹à¥‹à¤¸à¥à¤Ÿà¤¿à¤™ à¤¸à¥‡à¤µà¤¾à¤¹à¤°à¥‚à¤•à¥‹ à¤µà¤¿à¤¶à¥à¤²à¥‡à¤·à¤£à¤•à¥‹ à¤à¤• à¤­à¤¾à¤— à¤¹à¥‹à¥¤ à¤²à¤— à¤«à¤¾à¤‡à¤²à¤¹à¤°à¥‚à¤¦à¥à¤µà¤¾à¤°à¤¾ à¤¸à¤™à¥à¤•à¤²à¤¨ à¤—à¤°à¤¿à¤à¤•à¥‹ à¤œà¤¾à¤¨à¤•à¤¾à¤°à¥€à¤®à¤¾ à¤‡à¤¨à¥à¤Ÿà¤°à¤¨à¥‡à¤Ÿ à¤ªà¥à¤°à¥‹à¤Ÿà¥‹à¤•à¤² (à¤†à¤ˆà¤ªà¥€) à¤ à¥‡à¤—à¤¾à¤¨à¤¾à¤¹à¤°à¥‚, à¤¬à¥à¤°à¤¾à¤‰à¤œà¤° à¤ªà¥à¤°à¤•à¤¾à¤°, à¤‡à¤¨à¥à¤Ÿà¤°à¤¨à¥‡à¤Ÿ à¤¸à¥‡à¤µà¤¾ à¤ªà¥à¤°à¤¦à¤¾à¤¯à¤• (à¤†à¤ˆà¤à¤¸à¤ªà¥€), à¤®à¤¿à¤¤à¤¿ à¤° à¤¸à¤®à¤¯ à¤¸à¥à¤Ÿà¥à¤¯à¤¾à¤®à¥à¤ª, à¤¸à¤¨à¥à¤¦à¤°à¥à¤­/à¤¨à¤¿à¤•à¤¾à¤¸ à¤ªà¥ƒà¤·à¥à¤ à¤¹à¤°à¥‚, à¤° à¤¸à¤®à¥à¤­à¤µà¤¤à¤ƒ à¤•à¥à¤²à¤¿à¤•à¤¹à¤°à¥‚à¤•à¥‹ à¤¸à¤‚à¤–à¥à¤¯à¤¾ à¤¸à¤®à¤¾à¤µà¥‡à¤¶ à¤¹à¥à¤¨ à¤¸à¤•à¥à¤›à¥¤ à¤¯à¥€ à¤•à¥à¤¨à¥ˆ à¤ªà¤¨à¤¿ à¤¯à¤¸à¥à¤¤à¥‹ à¤œà¤¾à¤¨à¤•à¤¾à¤°à¥€à¤¸à¤à¤— à¤¸à¤®à¥à¤¬à¤¨à¥à¤§à¤¿à¤¤ à¤›à¥ˆà¤¨à¤¨à¥ à¤œà¥à¤¨ à¤µà¥à¤¯à¤•à¥à¤¤à¤¿à¤—à¤¤ à¤°à¥‚à¤ªà¤®à¤¾ à¤ªà¤¹à¤¿à¤šà¤¾à¤¨ à¤¯à¥‹à¤—à¥à¤¯ à¤¹à¥‹à¥¤ à¤œà¤¾à¤¨à¤•à¤¾à¤°à¥€à¤•à¥‹ à¤‰à¤¦à¥à¤¦à¥‡à¤¶à¥à¤¯ à¤°à¥à¤à¤¾à¤¨à¤¹à¤°à¥‚à¤•à¥‹ à¤µà¤¿à¤¶à¥à¤²à¥‡à¤·à¤£ à¤—à¤°à¥à¤¨, à¤¸à¤¾à¤‡à¤Ÿà¤²à¤¾à¤ˆ à¤ªà¥à¤°à¤¶à¤¾à¤¸à¤¨ à¤—à¤°à¥à¤¨, à¤µà¥‡à¤¬à¤¸à¤¾à¤‡à¤Ÿà¤®à¤¾ à¤ªà¥à¤°à¤¯à¥‹à¤—à¤•à¤°à¥à¤¤à¤¾à¤¹à¤°à¥‚à¤•à¥‹ à¤—à¤¤à¤¿à¤µà¤¿à¤§à¤¿à¤²à¤¾à¤ˆ à¤Ÿà¥à¤°à¥à¤¯à¤¾à¤• à¤—à¤°à¥à¤¨, à¤° à¤œà¤¨à¤¸à¤¾à¤‚à¤–à¥à¤¯à¤¿à¤•à¥€à¤¯ à¤œà¤¾à¤¨à¤•à¤¾à¤°à¥€ à¤¸à¤™à¥à¤•à¤²à¤¨ à¤—à¤°à¥à¤¨ à¤¹à¥‹à¥¤\r\n\r\n[b]à¤•à¥à¤•à¥€à¤œ à¤° à¤µà¥‡à¤¬ à¤¬à¥€à¤•à¤¨à¤¹à¤°à¥‚[/b]\r\nà¤…à¤¨à¥à¤¯ à¤•à¥à¤¨à¥ˆà¤ªà¤¨à¤¿ à¤µà¥‡à¤¬à¤¸à¤¾à¤‡à¤Ÿ à¤œà¤¸à¥à¤¤à¥ˆ, à¤®à¥ˆà¤²à¥‡ \'à¤•à¥à¤•à¥€à¤œ\' à¤ªà¥à¤°à¤¯à¥‹à¤— à¤—à¤°à¥à¤¦à¤›à¥à¥¤ à¤¯à¥€ à¤•à¥à¤•à¥€à¤œà¤¹à¤°à¥‚ à¤­à¥à¤°à¤®à¤£à¤•à¤°à¥à¤¤à¤¾à¤¹à¤°à¥‚à¤•à¥‹ à¤ªà¥à¤°à¤¾à¤¥à¤®à¤¿à¤•à¤¤à¤¾à¤¹à¤°à¥‚, à¤° à¤µà¥‡à¤¬à¤¸à¤¾à¤‡à¤Ÿà¤®à¤¾ à¤­à¥à¤°à¤®à¤£à¤•à¤°à¥à¤¤à¤¾à¤²à¥‡ à¤ªà¤¹à¥à¤à¤š à¤—à¤°à¥‡à¤•à¥‹ à¤µà¤¾ à¤­à¥à¤°à¤®à¤£ à¤—à¤°à¥‡à¤•à¥‹ à¤ªà¥ƒà¤·à¥à¤ à¤¹à¤°à¥‚ à¤¸à¤¹à¤¿à¤¤à¤•à¥‹ à¤œà¤¾à¤¨à¤•à¤¾à¤°à¥€ à¤­à¤£à¥à¤¡à¤¾à¤°à¤£ à¤—à¤°à¥à¤¨ à¤ªà¥à¤°à¤¯à¥‹à¤— à¤—à¤°à¤¿à¤¨à¥à¤›à¥¤ à¤œà¤¾à¤¨à¤•à¤¾à¤°à¥€ à¤­à¥à¤°à¤®à¤£à¤•à¤°à¥à¤¤à¤¾à¤¹à¤°à¥‚à¤•à¥‹ à¤¬à¥à¤°à¤¾à¤‰à¤œà¤° à¤ªà¥à¤°à¤•à¤¾à¤° à¤°/à¤µà¤¾ à¤…à¤¨à¥à¤¯ à¤œà¤¾à¤¨à¤•à¤¾à¤°à¥€à¤•à¥‹ à¤†à¤§à¤¾à¤°à¤®à¤¾ à¤®à¥‡à¤°à¥‹ à¤µà¥‡à¤¬ à¤ªà¥‡à¤œ à¤¸à¤¾à¤®à¤—à¥à¤°à¥€à¤²à¤¾à¤ˆ à¤…à¤¨à¥à¤•à¥‚à¤²à¤¿à¤¤ à¤—à¤°à¥‡à¤° à¤ªà¥à¤°à¤¯à¥‹à¤—à¤•à¤°à¥à¤¤à¤¾à¤¹à¤°à¥‚à¤•à¥‹ à¤…à¤¨à¥à¤­à¤µà¤²à¤¾à¤ˆ à¤…à¤¨à¥à¤•à¥‚à¤²à¤¨ à¤—à¤°à¥à¤¨ à¤ªà¥à¤°à¤¯à¥‹à¤— à¤—à¤°à¤¿à¤¨à¥à¤›à¥¤\r\nà¤•à¥à¤•à¥€à¤œà¤•à¥‹à¤¬à¤¾à¤°à¥‡à¤®à¤¾ à¤¸à¤¾à¤®à¤¾à¤¨à¥à¤¯ à¤œà¤¾à¤¨à¤•à¤¾à¤°à¥€à¤•à¥‹ à¤²à¤¾à¤—à¤¿, à¤•à¥ƒà¤ªà¤¯à¤¾Â [url=https://www.cookieconsent.com/what-are-cookies/]\"What Are Cookies\"[/url] à¤ªà¤¢à¥à¤¨à¥à¤¹à¥‹à¤¸à¥à¥¤\r\n\r\n[b]à¤—à¥à¤—à¤² à¤¡à¤¬à¤²à¤•à¥à¤²à¤¿à¤• DART à¤•à¥à¤•à¥€[/b]\r\nà¤—à¥à¤—à¤² à¤®à¥‡à¤°à¥‹à¤¸à¤¾à¤‡à¤Ÿà¤®à¤¾ à¤à¤• à¤¤à¥‡à¤¸à¥à¤°à¥‹-à¤ªà¤•à¥à¤· à¤µà¤¿à¤•à¥à¤°à¥‡à¤¤à¤¾ à¤¹à¥‹à¥¤ à¤¯à¤¸à¤²à¥‡ à¤•à¥à¤•à¥€à¤œ, à¤œà¤¸à¤²à¤¾à¤ˆ DART à¤•à¥à¤•à¥€à¤œ à¤­à¤¨à¤¿à¤¨à¥à¤›, à¤ªà¥à¤°à¤¯à¥‹à¤— à¤—à¤°à¥à¤¦à¤›, à¤œà¥à¤¨ à¤®à¥‡à¤°à¤¾ à¤¸à¤¾à¤‡à¤Ÿ à¤­à¥à¤°à¤®à¤£à¤•à¤°à¥à¤¤à¤¾à¤¹à¤°à¥‚à¤²à¤¾à¤ˆ www.website.com à¤° à¤‡à¤¨à¥à¤Ÿà¤°à¤¨à¥‡à¤Ÿà¤®à¤¾ à¤°à¤¹à¥‡à¤•à¤¾ à¤…à¤¨à¥à¤¯ à¤¸à¤¾à¤‡à¤Ÿà¤¹à¤°à¥‚à¤®à¤¾ à¤¤à¤¿à¤¨à¥€à¤¹à¤°à¥‚à¤•à¥‹ à¤­à¥à¤°à¤®à¤£à¤•à¥‹ à¤†à¤§à¤¾à¤°à¤®à¤¾ à¤µà¤¿à¤œà¥à¤žà¤¾à¤ªà¤¨à¤¹à¤°à¥‚ à¤ªà¥à¤°à¤¦à¤¾à¤¨ à¤—à¤°à¥à¤¨ à¤ªà¥à¤°à¤¯à¥‹à¤— à¤—à¤°à¤¿à¤¨à¥à¤›à¥¤ à¤¯à¤¦à¥à¤¯à¤ªà¤¿, à¤­à¥à¤°à¤®à¤£à¤•à¤°à¥à¤¤à¤¾à¤¹à¤°à¥‚à¤²à¥‡ à¤¤à¤²à¤•à¥‹ URL à¤®à¤¾ à¤°à¤¹à¥‡à¤•à¥‹ à¤—à¥à¤—à¤² à¤µà¤¿à¤œà¥à¤žà¤¾à¤ªà¤¨ à¤° à¤¸à¤¾à¤®à¤—à¥à¤°à¥€ à¤¨à¥‡à¤Ÿà¤µà¤°à¥à¤• à¤—à¥‹à¤ªà¤¨à¥€à¤¯à¤¤à¤¾ à¤¨à¥€à¤¤à¤¿à¤®à¤¾ à¤œà¤¾à¤à¤¦à¥ˆ DART à¤•à¥à¤•à¥€à¤œà¤•à¥‹ à¤ªà¥à¤°à¤¯à¥‹à¤— à¤…à¤¸à¥à¤µà¥€à¤•à¤¾à¤° à¤—à¤°à¥à¤¨ à¤°à¥‹à¤œà¥à¤¨ à¤¸à¤•à¥à¤›à¤¨à¥ â€“Â [url=https://policies.google.com/technologies/ads]https://policies.google.com/technologies/ads[/url]\r\n\r\n[b]à¤µà¤¿à¤œà¥à¤žà¤¾à¤ªà¤¨ à¤¸à¤¾à¤à¥‡à¤¦à¤¾à¤°à¤¹à¤°à¥‚à¤•à¥‹ à¤—à¥‹à¤ªà¤¨à¥€à¤¯à¤¤à¤¾ à¤¨à¥€à¤¤à¤¿à¤¹à¤°à¥‚[/b]\r\nà¤®à¥‡à¤°à¤¾à¤µà¤¿à¤œà¥à¤žà¤¾à¤ªà¤¨ à¤¸à¤¾à¤à¥‡à¤¦à¤¾à¤°à¤¹à¤°à¥‚à¤®à¤§à¥à¤¯à¥‡ à¤ªà¥à¤°à¤¤à¥à¤¯à¥‡à¤•à¤•à¥‹ à¤—à¥‹à¤ªà¤¨à¥€à¤¯à¤¤à¤¾ à¤¨à¥€à¤¤à¤¿ à¤ªà¤¤à¥à¤¤à¤¾ à¤²à¤—à¤¾à¤‰à¤¨ à¤¤à¤ªà¤¾à¤ˆà¤‚à¤²à¥‡ à¤¯à¥‹ à¤¸à¥‚à¤šà¥€ à¤¸à¤²à¥à¤²à¤¾à¤¹ à¤²à¤¿à¤¨ à¤¸à¤•à¥à¤¨à¥à¤¹à¥à¤¨à¥à¤›à¥¤\r\nà¤¤à¥‡à¤¸à¥à¤°à¥‹-à¤ªà¤•à¥à¤· à¤µà¤¿à¤œà¥à¤žà¤¾à¤ªà¤¨ à¤¸à¤°à¥à¤­à¤° à¤µà¤¾à¤µà¤¿à¤œà¥à¤žà¤¾à¤ªà¤¨ à¤¨à¥‡à¤Ÿà¤µà¤°à¥à¤•à¤¹à¤°à¥‚à¤²à¥‡ à¤•à¥à¤•à¥€à¤œ, à¤œà¤¾à¤­à¤¾à¤¸à¥à¤•à¥à¤°à¤¿à¤ªà¥à¤Ÿ, à¤µà¤¾ à¤µà¥‡à¤¬ à¤¬à¥€à¤•à¤¨ à¤œà¤¸à¥à¤¤à¤¾ à¤ªà¥à¤°à¤µà¤¿à¤§à¤¿à¤¹à¤°à¥‚ à¤ªà¥à¤°à¤¯à¥‹à¤— à¤—à¤°à¥à¤¦à¤›à¤¨à¥ à¤œà¥à¤¨ à¤®à¥‡à¤°à¥‹ à¤µà¥‡à¤¬à¤¸à¤¾à¤‡à¤Ÿà¤®à¤¾ à¤¦à¥‡à¤–à¤¾ à¤ªà¤°à¥à¤¨à¥‡ à¤¤à¤¿à¤¨à¥€à¤¹à¤°à¥‚à¤•à¤¾ à¤¸à¤®à¥à¤¬à¤¨à¥à¤§à¤¿à¤¤ à¤µà¤¿à¤œà¥à¤žà¤¾à¤ªà¤¨à¤¹à¤°à¥‚ à¤° à¤²à¤¿à¤™à¥à¤•à¤¹à¤°à¥‚à¤®à¤¾ à¤ªà¥à¤°à¤¯à¥‹à¤— à¤—à¤°à¤¿à¤¨à¥à¤›à¤¨à¥, à¤œà¥à¤¨ à¤ªà¥à¤°à¤¯à¥‹à¤—à¤•à¤°à¥à¤¤à¤¾à¤¹à¤°à¥‚à¤•à¥‹ à¤¬à¥à¤°à¤¾à¤‰à¤œà¤°à¤®à¤¾ à¤¸à¥€à¤§à¥ˆ à¤ªà¤ à¤¾à¤‡à¤¨à¥à¤›à¤¨à¥à¥¤ à¤¯à¥‹ à¤˜à¤Ÿà¤¨à¤¾ à¤¹à¥à¤à¤¦à¤¾ à¤¤à¤¿à¤¨à¥€à¤¹à¤°à¥‚à¤²à¥‡ à¤¸à¥à¤µà¤šà¤¾à¤²à¤¿à¤¤ à¤°à¥‚à¤ªà¤®à¤¾ à¤¤à¤ªà¤¾à¤ˆà¤‚à¤•à¥‹ à¤†à¤ˆà¤ªà¥€ à¤ à¥‡à¤—à¤¾à¤¨à¤¾ à¤ªà¥à¤°à¤¾à¤ªà¥à¤¤ à¤—à¤°à¥à¤¦à¤›à¤¨à¥à¥¤ à¤¯à¥€ à¤ªà¥à¤°à¤µà¤¿à¤§à¤¿à¤¹à¤°à¥‚ à¤¤à¤¿à¤¨à¥€à¤¹à¤°à¥‚à¤•à¤¾ à¤µà¤¿à¤œà¥à¤žà¤¾à¤ªà¤¨ à¤…à¤­à¤¿à¤¯à¤¾à¤¨à¤¹à¤°à¥‚à¤•à¥‹ à¤ªà¥à¤°à¤­à¤¾à¤µà¤•à¤¾à¤°à¤¿à¤¤à¤¾ à¤®à¤¾à¤ªà¤¨ à¤—à¤°à¥à¤¨ à¤°/à¤µà¤¾ à¤¤à¤ªà¤¾à¤ˆà¤‚à¤²à¥‡ à¤­à¥à¤°à¤®à¤£ à¤—à¤°à¥à¤¨à¥à¤­à¤à¤•à¤¾ à¤µà¥‡à¤¬à¤¸à¤¾à¤‡à¤Ÿà¤¹à¤°à¥‚à¤®à¤¾ à¤¤à¤ªà¤¾à¤ˆà¤‚à¤²à¥‡ à¤¦à¥‡à¤–à¥à¤¨à¥à¤¹à¥à¤¨à¥‡ à¤µà¤¿à¤œà¥à¤žà¤¾à¤ªà¤¨ à¤¸à¤¾à¤®à¤—à¥à¤°à¥€à¤²à¤¾à¤ˆ à¤µà¥à¤¯à¤•à¥à¤¤à¤¿à¤—à¤¤ à¤¬à¤¨à¤¾à¤‰à¤¨ à¤ªà¥à¤°à¤¯à¥‹à¤— à¤—à¤°à¤¿à¤¨à¥à¤›à¥¤\r\nà¤¯à¤¾à¤¦ à¤°à¤¾à¤–à¥à¤¨à¥à¤¹à¥‹à¤¸à¥à¤•à¤¿ à¤®à¤²à¥‡ à¤¤à¥‡à¤¸à¥à¤°à¥‹-à¤ªà¤•à¥à¤· à¤µà¤¿à¤œà¥à¤žà¤¾à¤ªà¤¨à¤¦à¤¾à¤¤à¤¾à¤¹à¤°à¥‚à¤¦à¥à¤µà¤¾à¤°à¤¾ à¤ªà¥à¤°à¤¯à¥‹à¤— à¤—à¤°à¤¿à¤¨à¥‡ à¤¯à¥€ à¤•à¥à¤•à¥€à¤œà¤¹à¤°à¥‚à¤®à¤¾ à¤ªà¤¹à¥à¤à¤š à¤µà¤¾ à¤¨à¤¿à¤¯à¤¨à¥à¤¤à¥à¤°à¤£ à¤—à¤°à¥à¤¨à¥‡ à¤•à¥à¤¨à¥ˆ à¤…à¤§à¤¿à¤•à¤¾à¤° à¤›à¥ˆà¤¨à¥¤\r\n\r\n[b]à¤¤à¥‡à¤¸à¥à¤°à¥‹ à¤ªà¤•à¥à¤· à¤—à¥‹à¤ªà¤¨à¥€à¤¯à¤¤à¤¾ à¤¨à¥€à¤¤à¤¿à¤¹à¤°à¥‚[/b]\r\nà¤®à¥‡à¤°à¥‹à¤—à¥‹à¤ªà¤¨à¥€à¤¯à¤¤à¤¾ à¤¨à¥€à¤¤à¤¿ à¤…à¤¨à¥à¤¯ à¤µà¤¿à¤œà¥à¤žà¤¾à¤ªà¤¨à¤¦à¤¾à¤¤à¤¾à¤¹à¤°à¥‚ à¤µà¤¾ à¤µà¥‡à¤¬à¤¸à¤¾à¤‡à¤Ÿà¤¹à¤°à¥‚à¤®à¤¾ à¤²à¤¾à¤—à¥‚ à¤¹à¥à¤à¤¦à¥ˆà¤¨à¥¤ à¤¯à¤¸à¥ˆà¤²à¥‡, à¤®à¤²à¥‡ à¤¤à¤ªà¤¾à¤ˆà¤‚à¤²à¤¾à¤ˆ à¤¯à¥€ à¤¤à¥‡à¤¸à¥à¤°à¥‹-à¤ªà¤•à¥à¤· à¤µà¤¿à¤œà¥à¤žà¤¾à¤ªà¤¨ à¤¸à¤°à¥à¤­à¤°à¤¹à¤°à¥‚à¤•à¥‹ à¤¸à¤®à¥à¤¬à¤¨à¥à¤§à¤¿à¤¤ à¤—à¥‹à¤ªà¤¨à¥€à¤¯à¤¤à¤¾ à¤¨à¥€à¤¤à¤¿à¤¹à¤°à¥‚à¤•à¥‹ à¤¸à¤²à¥à¤²à¤¾à¤¹ à¤²à¤¿à¤¨ à¤†à¤—à¥à¤°à¤¹ à¤—à¤°à¥à¤¦à¤›à¥à¥¤ à¤¯à¤¸à¤²à¥‡ à¤¤à¤¿à¤¨à¥€à¤¹à¤°à¥‚à¤•à¥‹ à¤…à¤­à¥à¤¯à¤¾à¤¸ à¤° à¤¨à¤¿à¤¶à¥à¤šà¤¿à¤¤ à¤µà¤¿à¤•à¤²à¥à¤ªà¤¹à¤°à¥‚à¤¬à¤¾à¤Ÿ à¤“à¤ªà¥à¤Ÿ-à¤†à¤‰à¤Ÿ (à¤…à¤¸à¥à¤µà¥€à¤•à¤¾à¤°) à¤—à¤°à¥à¤¨à¥‡ à¤¬à¤¾à¤°à¥‡à¤®à¤¾ à¤¨à¤¿à¤°à¥à¤¦à¥‡à¤¶à¤¨à¤¹à¤°à¥‚ à¤¸à¤®à¤¾à¤µà¥‡à¤¶ à¤—à¤°à¥à¤¨ à¤¸à¤•à¥à¤›à¥¤ à¤¤à¤ªà¤¾à¤ˆà¤‚à¤²à¥‡ à¤¯à¥€ à¤—à¥‹à¤ªà¤¨à¥€à¤¯à¤¤à¤¾ à¤¨à¥€à¤¤à¤¿à¤¹à¤°à¥‚à¤•à¥‹ à¤ªà¥‚à¤°à¥à¤£ à¤¸à¥‚à¤šà¥€ à¤° à¤¤à¤¿à¤¨à¥€à¤¹à¤°à¥‚à¤•à¤¾ à¤²à¤¿à¤™à¥à¤•à¤¹à¤°à¥‚ à¤¯à¤¹à¤¾à¤ à¤ªà¤¾à¤‰à¤¨ à¤¸à¤•à¥à¤¨à¥à¤¹à¥à¤¨à¥à¤›: à¤—à¥‹à¤ªà¤¨à¥€à¤¯à¤¤à¤¾ à¤¨à¥€à¤¤à¤¿ à¤²à¤¿à¤™à¥à¤•à¤¹à¤°à¥‚à¥¤\r\nà¤¤à¤ªà¤¾à¤ˆà¤‚à¤²à¥‡à¤†à¤«à¥à¤¨à¥‹ à¤µà¥à¤¯à¤•à¥à¤¤à¤¿à¤—à¤¤ à¤¬à¥à¤°à¤¾à¤‰à¤œà¤° à¤µà¤¿à¤•à¤²à¥à¤ªà¤¹à¤°à¥‚ à¤®à¤¾à¤°à¥à¤«à¤¤ à¤•à¥à¤•à¥€à¤œà¤¹à¤°à¥‚ à¤…à¤•à¥à¤·à¤® à¤—à¤°à¥à¤¨ à¤°à¥‹à¤œà¥à¤¨ à¤¸à¤•à¥à¤¨à¥à¤¹à¥à¤¨à¥à¤›à¥¤ à¤µà¤¿à¤¶à¤¿à¤·à¥à¤Ÿ à¤µà¥‡à¤¬ à¤¬à¥à¤°à¤¾à¤‰à¤œà¤°à¤¹à¤°à¥‚à¤¸à¤à¤— à¤•à¥à¤•à¥€ à¤µà¥à¤¯à¤µà¤¸à¥à¤¥à¤¾à¤ªà¤¨à¤•à¥‹ à¤¬à¤¾à¤°à¥‡à¤®à¤¾ à¤¥à¤ª à¤µà¤¿à¤¸à¥à¤¤à¥ƒà¤¤ à¤œà¤¾à¤¨à¤•à¤¾à¤°à¥€à¤•à¥‹ à¤²à¤¾à¤—à¤¿, à¤¯à¥‹ à¤¬à¥à¤°à¤¾à¤‰à¤œà¤°à¤¹à¤°à¥‚à¤•à¥‹ à¤¸à¤®à¥à¤¬à¤¨à¥à¤§à¤¿à¤¤ à¤µà¥‡à¤¬à¤¸à¤¾à¤‡à¤Ÿà¤¹à¤°à¥‚à¤®à¤¾ à¤ªà¤¾à¤‰à¤¨ à¤¸à¤•à¤¿à¤¨à¥à¤›à¥¤ à¤•à¥à¤•à¥€à¤œ à¤­à¤¨à¥‡à¤•à¥‹ à¤•à¥‡ à¤¹à¥‹?\r\n\r\n[b]à¤¸à¥€à¤¸à¥€à¤ªà¥€à¤ à¤—à¥‹à¤ªà¤¨à¥€à¤¯à¤¤à¤¾ à¤…à¤§à¤¿à¤•à¤¾à¤°à¤¹à¤°à¥‚ (à¤®à¥‡à¤°à¥‹ à¤µà¥à¤¯à¤•à¥à¤¤à¤¿à¤—à¤¤ à¤œà¤¾à¤¨à¤•à¤¾à¤°à¥€ à¤¬à¥‡à¤šà¥à¤¨à¥à¤¹à¥‹à¤¸à¥ à¤­à¤¨à¥‡à¤°)[/b]\r\nà¤¸à¥€à¤¸à¥€à¤ªà¥€à¤ à¤…à¤¨à¥à¤¤à¤°à¥à¤—à¤¤,à¤…à¤¨à¥à¤¯ à¤…à¤§à¤¿à¤•à¤¾à¤°à¤¹à¤°à¥‚à¤•à¥‹ à¤¬à¥€à¤š, à¤•à¥à¤¯à¤¾à¤²à¤¿à¤«à¥‹à¤°à¥à¤¨à¤¿à¤¯à¤¾à¤•à¤¾ à¤‰à¤ªà¤­à¥‹à¤•à¥à¤¤à¤¾à¤¹à¤°à¥‚à¤¸à¤à¤— à¤¨à¤¿à¤®à¥à¤¨ à¤…à¤§à¤¿à¤•à¤¾à¤°à¤¹à¤°à¥‚ à¤›à¤¨à¥:\r\nà¤à¤‰à¤Ÿà¤¾à¤µà¥à¤¯à¤µà¤¸à¤¾à¤¯à¤²à¤¾à¤ˆ à¤…à¤¨à¥à¤°à¥‹à¤§ à¤—à¤°à¥à¤¨à¥‡ à¤…à¤§à¤¿à¤•à¤¾à¤° à¤œà¤¸à¤²à¥‡ à¤‰à¤ªà¤­à¥‹à¤•à¥à¤¤à¤¾à¤•à¥‹ à¤µà¥à¤¯à¤•à¥à¤¤à¤¿à¤—à¤¤ à¤¡à¤¾à¤Ÿà¤¾ à¤¸à¤™à¥à¤•à¤²à¤¨ à¤—à¤°à¥à¤¦à¤›, à¤•à¤¿ à¤‰à¤¸à¤²à¥‡ à¤‰à¤ªà¤­à¥‹à¤•à¥à¤¤à¤¾à¤¹à¤°à¥‚à¤•à¥‹ à¤¬à¤¾à¤°à¥‡à¤®à¤¾ à¤¸à¤™à¥à¤•à¤²à¤¨ à¤—à¤°à¥‡à¤•à¥‹ à¤µà¥à¤¯à¤•à¥à¤¤à¤¿à¤—à¤¤ à¤¡à¤¾à¤Ÿà¤¾à¤•à¥‹ à¤¶à¥à¤°à¥‡à¤£à¥€à¤¹à¤°à¥‚ à¤° à¤µà¤¿à¤¶à¤¿à¤·à¥à¤Ÿ à¤–à¤£à¥à¤¡à¤¹à¤°à¥‚ à¤–à¥à¤²à¤¾à¤‰à¤“à¤¸à¥à¥¤\r\nà¤à¤‰à¤Ÿà¤¾à¤µà¥à¤¯à¤µà¤¸à¤¾à¤¯à¤²à¤¾à¤ˆ à¤…à¤¨à¥à¤°à¥‹à¤§ à¤—à¤°à¥à¤¨à¥‡ à¤…à¤§à¤¿à¤•à¤¾à¤° à¤•à¤¿ à¤‰à¤¸à¤²à¥‡ à¤‰à¤ªà¤­à¥‹à¤•à¥à¤¤à¤¾à¤•à¥‹ à¤¬à¤¾à¤°à¥‡à¤®à¤¾ à¤¸à¤™à¥à¤•à¤²à¤¨ à¤—à¤°à¥‡à¤•à¥‹ à¤•à¥à¤¨à¥ˆ à¤ªà¤¨à¤¿ à¤µà¥à¤¯à¤•à¥à¤¤à¤¿à¤—à¤¤ à¤¡à¤¾à¤Ÿà¤¾ à¤®à¥‡à¤Ÿà¤¾à¤“à¤¸à¥à¥¤\r\nà¤à¤‰à¤Ÿà¤¾à¤µà¥à¤¯à¤µà¤¸à¤¾à¤¯à¤²à¤¾à¤ˆ à¤…à¤¨à¥à¤°à¥‹à¤§ à¤—à¤°à¥à¤¨à¥‡ à¤…à¤§à¤¿à¤•à¤¾à¤° à¤œà¤¸à¤²à¥‡ à¤‰à¤ªà¤­à¥‹à¤•à¥à¤¤à¤¾à¤•à¥‹ à¤µà¥à¤¯à¤•à¥à¤¤à¤¿à¤—à¤¤ à¤¡à¤¾à¤Ÿà¤¾ à¤¬à¥‡à¤šà¥à¤¦à¤›, à¤•à¤¿ à¤‰à¤¸à¤²à¥‡ à¤‰à¤ªà¤­à¥‹à¤•à¥à¤¤à¤¾à¤•à¥‹ à¤µà¥à¤¯à¤•à¥à¤¤à¤¿à¤—à¤¤ à¤¡à¤¾à¤Ÿà¤¾ à¤¨à¤¬à¥‡à¤šà¥‹à¤¸à¥à¥¤\r\nà¤¯à¤¦à¤¿à¤¤à¤ªà¤¾à¤ˆà¤‚à¤²à¥‡ à¤…à¤¨à¥à¤°à¥‹à¤§ à¤—à¤°à¥à¤¨à¥à¤­à¤¯à¥‹ à¤­à¤¨à¥‡, à¤¤à¤ªà¤¾à¤ˆà¤‚à¤²à¤¾à¤ˆ à¤œà¤µà¤¾à¤« à¤¦à¤¿à¤¨ à¤®à¤¸à¤à¤— à¤à¤• à¤®à¤¹à¤¿à¤¨à¤¾à¤•à¥‹ à¤¸à¤®à¤¯ à¤›à¥¤ à¤¯à¤¦à¤¿ à¤¤à¤ªà¤¾à¤ˆà¤‚à¤²à¥‡ à¤¯à¥€ à¤®à¤§à¥à¤¯à¥‡ à¤•à¥à¤¨à¥ˆ à¤ªà¤¨à¤¿ à¤…à¤§à¤¿à¤•à¤¾à¤°à¤¹à¤°à¥‚ à¤ªà¥à¤°à¤¯à¥‹à¤— à¤—à¤°à¥à¤¨ à¤šà¤¾à¤¹à¤¨à¥à¤¹à¥à¤¨à¥à¤› à¤­à¤¨à¥‡, à¤•à¥ƒà¤ªà¤¯à¤¾ à¤®à¤²à¤¾à¤ˆ à¤¸à¤®à¥à¤ªà¤°à¥à¤• à¤—à¤°à¥à¤¨à¥à¤¹à¥‹à¤¸à¥à¥¤\r\n\r\n[b]à¤œà¥€à¤¡à¥€à¤ªà¥€à¤†à¤° à¤¡à¤¾à¤Ÿà¤¾ à¤¸à¤‚à¤°à¤•à¥à¤·à¤£ à¤…à¤§à¤¿à¤•à¤¾à¤°à¤¹à¤°à¥‚[/b]\r\nà¤® à¤¯à¥‹à¤¸à¥à¤¨à¤¿à¤¶à¥à¤šà¤¿à¤¤ à¤—à¤°à¥à¤¨ à¤šà¤¾à¤¹à¤¨à¥à¤›à¥ à¤•à¤¿ à¤¤à¤ªà¤¾à¤ˆà¤‚ à¤†à¤«à¥à¤¨à¤¾ à¤¸à¤¬à¥ˆ à¤¡à¤¾à¤Ÿà¤¾ à¤¸à¤‚à¤°à¤•à¥à¤·à¤£ à¤…à¤§à¤¿à¤•à¤¾à¤°à¤¹à¤°à¥‚à¤¬à¤¾à¤°à¥‡ à¤ªà¥‚à¤°à¥à¤£ à¤°à¥‚à¤ªà¤®à¤¾ à¤¸à¤šà¥‡à¤¤ à¤¹à¥à¤¨à¥à¤¹à¥à¤¨à¥à¤›à¥¤ à¤ªà¥à¤°à¤¤à¥à¤¯à¥‡à¤• à¤ªà¥à¤°à¤¯à¥‹à¤—à¤•à¤°à¥à¤¤à¤¾ à¤¨à¤¿à¤®à¥à¤¨ à¤…à¤§à¤¿à¤•à¤¾à¤°à¤¹à¤°à¥‚à¤•à¥‹ à¤¹à¤•à¤¦à¤¾à¤° à¤›à¤¨à¥:\r\nà¤ªà¤¹à¥à¤à¤š à¤—à¤°à¥à¤¨à¥‡à¤…à¤§à¤¿à¤•à¤¾à¤° â€“ à¤¤à¤ªà¤¾à¤ˆà¤‚à¤²à¥‡ à¤†à¤«à¥à¤¨à¥‹ à¤µà¥à¤¯à¤•à¥à¤¤à¤¿à¤—à¤¤ à¤¡à¤¾à¤Ÿà¤¾à¤•à¥‹ à¤ªà¥à¤°à¤¤à¤¿à¤²à¤¿à¤ªà¤¿à¤¹à¤°à¥‚ à¤…à¤¨à¥à¤°à¥‹à¤§ à¤—à¤°à¥à¤¨à¥‡ à¤…à¤§à¤¿à¤•à¤¾à¤° à¤›à¥¤ à¤®à¤²à¥‡ à¤¯à¤¸ à¤¸à¥‡à¤µà¤¾à¤•à¥‹ à¤²à¤¾à¤—à¤¿ à¤¤à¤ªà¤¾à¤ˆà¤à¤²à¤¾à¤ˆ à¤¸à¤¾à¤¨à¥‹ à¤¶à¥à¤²à¥à¤• à¤²à¤—à¤¾à¤‰à¤¨ à¤¸à¤•à¥à¤›à¥à¥¤\r\nà¤¸à¤šà¥à¤¯à¤¾à¤‰à¤¨à¥‡à¤…à¤§à¤¿à¤•à¤¾à¤° â€“ à¤¤à¤ªà¤¾à¤ˆà¤‚à¤¸à¤à¤— à¤…à¤¨à¥à¤°à¥‹à¤§ à¤—à¤°à¥à¤¨à¥‡ à¤…à¤§à¤¿à¤•à¤¾à¤° à¤› à¤•à¤¿ à¤®à¤²à¥‡ à¤•à¥à¤¨à¥ˆ à¤ªà¤¨à¤¿ à¤¯à¤¸à¥à¤¤à¥‹ à¤œà¤¾à¤¨à¤•à¤¾à¤°à¥€ à¤¸à¤šà¥à¤¯à¤¾à¤”à¤‚ à¤œà¥à¤¨ à¤¤à¤ªà¤¾à¤ˆà¤‚à¤²à¥‡ à¤—à¤²à¤¤ à¤ à¤¾à¤¨à¥à¤¨à¥à¤¹à¥à¤¨à¥à¤›à¥¤ à¤¤à¤ªà¤¾à¤ˆà¤‚à¤¸à¤à¤— à¤…à¤¨à¥à¤°à¥‹à¤§ à¤—à¤°à¥à¤¨à¥‡ à¤…à¤§à¤¿à¤•à¤¾à¤° à¤ªà¤¨à¤¿ à¤› à¤•à¤¿ à¤®à¤²à¥‡ à¤¤à¤ªà¤¾à¤ˆà¤‚à¤²à¥‡ à¤…à¤§à¥‚à¤°à¤¾ à¤ à¤¾à¤¨à¥à¤¨à¥à¤¹à¥à¤¨à¥‡ à¤œà¤¾à¤¨à¤•à¤¾à¤°à¥€ à¤ªà¥‚à¤°à¤¾ à¤—à¤°à¥Œà¤‚à¥¤\r\nà¤®à¥‡à¤Ÿà¤¾à¤‰à¤¨à¥‡à¤…à¤§à¤¿à¤•à¤¾à¤° â€“ à¤¤à¤ªà¤¾à¤ˆà¤‚à¤¸à¤à¤— à¤…à¤¨à¥à¤°à¥‹à¤§ à¤—à¤°à¥à¤¨à¥‡ à¤…à¤§à¤¿à¤•à¤¾à¤° à¤› à¤•à¤¿ à¤®à¤²à¥‡ à¤¤à¤ªà¤¾à¤ˆà¤‚à¤•à¥‹ à¤µà¥à¤¯à¤•à¥à¤¤à¤¿à¤—à¤¤ à¤¡à¤¾à¤Ÿà¤¾ à¤®à¥‡à¤Ÿà¤¾à¤”à¤‚, à¤¨à¤¿à¤¶à¥à¤šà¤¿à¤¤ à¤¶à¤°à¥à¤¤à¤¹à¤°à¥‚ à¤…à¤¨à¥à¤¤à¤°à¥à¤—à¤¤à¥¤\r\nà¤ªà¥à¤°à¤¶à¥‹à¤§à¤¨ à¤¸à¥€à¤®à¤¿à¤¤ à¤—à¤°à¥à¤¨à¥‡à¤…à¤§à¤¿à¤•à¤¾à¤° â€“ à¤¤à¤ªà¤¾à¤ˆà¤‚à¤¸à¤à¤— à¤…à¤¨à¥à¤°à¥‹à¤§ à¤—à¤°à¥à¤¨à¥‡ à¤…à¤§à¤¿à¤•à¤¾à¤° à¤› à¤•à¤¿ à¤®à¤²à¥‡ à¤¤à¤ªà¤¾à¤ˆà¤‚à¤•à¥‹ à¤µà¥à¤¯à¤•à¥à¤¤à¤¿à¤—à¤¤ à¤¡à¤¾à¤Ÿà¤¾à¤•à¥‹ à¤ªà¥à¤°à¤¶à¥‹à¤§à¤¨ à¤¸à¥€à¤®à¤¿à¤¤ à¤—à¤°à¥Œà¤‚, à¤¨à¤¿à¤¶à¥à¤šà¤¿à¤¤ à¤¶à¤°à¥à¤¤à¤¹à¤°à¥‚ à¤…à¤¨à¥à¤¤à¤°à¥à¤—à¤¤à¥¤\r\nà¤ªà¥à¤°à¤¶à¥‹à¤§à¤¨à¤•à¥‹à¤µà¤¿à¤°à¥‹à¤§ à¤—à¤°à¥à¤¨à¥‡ à¤…à¤§à¤¿à¤•à¤¾à¤° â€“ à¤¤à¤ªà¤¾à¤ˆà¤‚à¤¸à¤à¤— à¤®à¥‡à¤°à¥‹ à¤¦à¥à¤µà¤¾à¤°à¤¾ à¤¤à¤ªà¤¾à¤ˆà¤‚à¤•à¥‹ à¤µà¥à¤¯à¤•à¥à¤¤à¤¿à¤—à¤¤ à¤¡à¤¾à¤Ÿà¤¾à¤•à¥‹ à¤ªà¥à¤°à¤¶à¥‹à¤§à¤¨à¤•à¥‹ à¤µà¤¿à¤°à¥‹à¤§ à¤—à¤°à¥à¤¨à¥‡ à¤…à¤§à¤¿à¤•à¤¾à¤° à¤›, à¤¨à¤¿à¤¶à¥à¤šà¤¿à¤¤ à¤¶à¤°à¥à¤¤à¤¹à¤°à¥‚ à¤…à¤¨à¥à¤¤à¤°à¥à¤—à¤¤à¥¤\r\nà¤¡à¤¾à¤Ÿà¤¾à¤ªà¥‹à¤°à¥à¤Ÿà¥‡à¤¬à¤¿à¤²à¤¿à¤Ÿà¥€à¤•à¥‹ à¤…à¤§à¤¿à¤•à¤¾à¤° â€“ à¤¤à¤ªà¤¾à¤ˆà¤‚à¤¸à¤à¤— à¤…à¤¨à¥à¤°à¥‹à¤§ à¤—à¤°à¥à¤¨à¥‡ à¤…à¤§à¤¿à¤•à¤¾à¤° à¤› à¤•à¤¿ à¤®à¤²à¥‡ à¤¸à¤™à¥à¤•à¤²à¤¨ à¤—à¤°à¥‡à¤•à¥‹ à¤¡à¤¾à¤Ÿà¤¾ à¤…à¤°à¥à¤•à¥‹ à¤¸à¤‚à¤¸à¥à¤¥à¤¾à¤²à¤¾à¤ˆ, à¤µà¤¾ à¤¸à¥€à¤§à¥ˆ à¤¤à¤ªà¤¾à¤ˆà¤‚à¤²à¤¾à¤ˆ à¤¸à¥à¤¥à¤¾à¤¨à¤¾à¤¨à¥à¤¤à¤°à¤£ à¤—à¤°à¥Œà¤‚, à¤¨à¤¿à¤¶à¥à¤šà¤¿à¤¤ à¤¶à¤°à¥à¤¤à¤¹à¤°à¥‚ à¤…à¤¨à¥à¤¤à¤°à¥à¤—à¤¤à¥¤\r\nà¤¯à¤¦à¤¿à¤¤à¤ªà¤¾à¤ˆà¤‚à¤²à¥‡ à¤…à¤¨à¥à¤°à¥‹à¤§ à¤—à¤°à¥à¤¨à¥à¤­à¤¯à¥‹ à¤­à¤¨à¥‡, à¤¤à¤ªà¤¾à¤ˆà¤‚à¤²à¤¾à¤ˆ à¤œà¤µà¤¾à¤« à¤¦à¤¿à¤¨ à¤®à¤¸à¤à¤— à¤à¤• à¤®à¤¹à¤¿à¤¨à¤¾à¤•à¥‹ à¤¸à¤®à¤¯ à¤›à¥¤ à¤¯à¤¦à¤¿ à¤¤à¤ªà¤¾à¤ˆà¤‚à¤²à¥‡ à¤¯à¥€ à¤®à¤§à¥à¤¯à¥‡ à¤•à¥à¤¨à¥ˆ à¤ªà¤¨à¤¿ à¤…à¤§à¤¿à¤•à¤¾à¤°à¤¹à¤°à¥‚ à¤ªà¥à¤°à¤¯à¥‹à¤— à¤—à¤°à¥à¤¨ à¤šà¤¾à¤¹à¤¨à¥à¤¹à¥à¤¨à¥à¤› à¤­à¤¨à¥‡, à¤•à¥ƒà¤ªà¤¯à¤¾ à¤®à¤²à¤¾à¤ˆ à¤¸à¤®à¥à¤ªà¤°à¥à¤• à¤—à¤°à¥à¤¨à¥à¤¹à¥‹à¤¸à¥à¥¤\r\n\r\n[b]à¤¬à¤¾à¤²à¤¬à¤¾à¤²à¤¿à¤•à¤¾à¤•à¥‹ à¤œà¤¾à¤¨à¤•à¤¾à¤°à¥€[/b]\r\nà¤‡à¤¨à¥à¤Ÿà¤°à¤¨à¥‡à¤Ÿ à¤ªà¥à¤°à¤¯à¥‹à¤— à¤—à¤°à¥à¤¦à¤¾à¤¬à¤¾à¤²à¤¬à¤¾à¤²à¤¿à¤•à¤¾à¤¹à¤°à¥‚à¤•à¥‹ à¤²à¤¾à¤—à¤¿ à¤¸à¥à¤°à¤•à¥à¤·à¤¾ à¤¥à¤ªà¥à¤¨à¥ à¤®à¥‡à¤°à¥‹ à¤…à¤°à¥à¤•à¥‹ à¤ªà¥à¤°à¤¾à¤¥à¤®à¤¿à¤•à¤¤à¤¾ à¤¹à¥‹à¥¤ à¤® à¤…à¤­à¤¿à¤­à¤¾à¤µà¤• à¤° à¤¸à¤‚à¤°à¤•à¥à¤·à¤•à¤¹à¤°à¥‚à¤²à¤¾à¤ˆ à¤¤à¤¿à¤¨à¥€à¤¹à¤°à¥‚à¤•à¥‹ à¤…à¤¨à¤²à¤¾à¤‡à¤¨ à¤—à¤¤à¤¿à¤µà¤¿à¤§à¤¿à¤¹à¤°à¥‚ à¤…à¤µà¤²à¥‹à¤•à¤¨ à¤—à¤°à¥à¤¨, à¤¤à¤¿à¤¨à¥€à¤¹à¤°à¥‚à¤®à¤¾ à¤¸à¤¹à¤­à¤¾à¤—à¥€ à¤¹à¥à¤¨, à¤°/à¤µà¤¾ à¤¤à¤¿à¤¨à¥€à¤¹à¤°à¥‚à¤²à¤¾à¤ˆ à¤¨à¤¿à¤—à¤°à¤¾à¤¨à¥€ à¤° à¤®à¤¾à¤°à¥à¤—à¤¦à¤°à¥à¤¶à¤¨ à¤—à¤°à¥à¤¨ à¤ªà¥à¤°à¥‹à¤¤à¥à¤¸à¤¾à¤¹à¤¨ à¤—à¤°à¥à¤¦à¤›à¥à¥¤\r\n\r\nà¤®à¤²à¥‡ à¤œà¤¾à¤¨à¥€à¤œà¤¾à¤¨à¥€ à¥§à¥© à¤µà¤°à¥à¤· à¤­à¤¨à¥à¤¦à¤¾ à¤®à¥à¤¨à¤¿à¤•à¤¾ à¤¬à¤¾à¤²à¤¬à¤¾à¤²à¤¿à¤•à¤¾à¤¹à¤°à¥‚à¤¬à¤¾à¤Ÿ à¤•à¥à¤¨à¥ˆ à¤ªà¤¨à¤¿ à¤µà¥à¤¯à¤•à¥à¤¤à¤¿à¤—à¤¤ à¤°à¥‚à¤ªà¤®à¤¾ à¤ªà¤¹à¤¿à¤šà¤¾à¤¨ à¤¯à¥‹à¤—à¥à¤¯ à¤œà¤¾à¤¨à¤•à¤¾à¤°à¥€ à¤¸à¤™à¥à¤•à¤²à¤¨ à¤—à¤°à¥à¤¦à¤¿à¤¨à¥¤ à¤¯à¤¦à¤¿ à¤¤à¤ªà¤¾à¤ˆà¤‚à¤²à¤¾à¤ˆ à¤²à¤¾à¤—à¥à¤› à¤•à¤¿ à¤¤à¤ªà¤¾à¤ˆà¤‚à¤•à¥‹ à¤¬à¤šà¥à¤šà¤¾à¤²à¥‡ à¤®à¥‡à¤°à¥‹ à¤µà¥‡à¤¬à¤¸à¤¾à¤‡à¤Ÿà¤®à¤¾ à¤¯à¤¸ à¤ªà¥à¤°à¤•à¤¾à¤°à¤•à¥‹ à¤œà¤¾à¤¨à¤•à¤¾à¤°à¥€ à¤ªà¥à¤°à¤¦à¤¾à¤¨ à¤—à¤°à¥‡à¤•à¥‹ à¤› à¤­à¤¨à¥‡, à¤®à¤²à¥‡ à¤¤à¤ªà¤¾à¤ˆà¤‚à¤²à¤¾à¤ˆ à¤¤à¥à¤°à¥à¤¨à¥à¤¤à¥ˆ à¤®à¤²à¤¾à¤ˆ à¤¸à¤®à¥à¤ªà¤°à¥à¤• à¤—à¤°à¥à¤¨ à¤•à¤¡à¤¾ à¤†à¤—à¥à¤°à¤¹ à¤—à¤°à¥à¤¦à¤›à¥ à¤° à¤®à¤²à¥‡ à¤†à¤«à¥à¤¨à¥‹ à¤¸à¤°à¥à¤µà¥‹à¤¤à¥à¤¤à¤® à¤ªà¥à¤°à¤¯à¤¾à¤¸à¤¹à¤°à¥‚ à¤—à¤°à¥€ à¤¤à¥à¤°à¥à¤¨à¥à¤¤à¥ˆ à¤¯à¤¸à¥à¤¤à¥‹ à¤œà¤¾à¤¨à¤•à¤¾à¤°à¥€ à¤®à¥‡à¤°à¤¾ à¤°à¥‡à¤•à¤°à¥à¤¡à¤¹à¤°à¥‚à¤¬à¤¾à¤Ÿ à¤¹à¤Ÿà¤¾à¤‰à¤¨à¥‡à¤›à¥à¥¤', 0);

-- --------------------------------------------------------

--
-- Table structure for table `Ghimire_payments`
--

CREATE TABLE `Ghimire_payments` (
  `id` int(11) NOT NULL,
  `plan` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `payment_id` varchar(150) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `payer_id` varchar(150) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `token` varchar(150) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `price` float(10,2) DEFAULT NULL,
  `currency` varchar(5) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `status` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `date` int(11) DEFAULT 0,
  `author` int(11) DEFAULT 0,
  `expired_date` int(10) UNSIGNED DEFAULT 0,
  `frequency` int(10) UNSIGNED DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Ghimire_plans`
--

CREATE TABLE `Ghimire_plans` (
  `id` int(11) NOT NULL,
  `plan` varchar(50) DEFAULT NULL,
  `price_m` float(10,2) UNSIGNED DEFAULT NULL,
  `price_y` float(10,2) DEFAULT NULL,
  `currency` varchar(5) DEFAULT NULL,
  `desc1` varchar(200) DEFAULT NULL,
  `desc2` varchar(200) DEFAULT NULL,
  `desc3` varchar(200) DEFAULT NULL,
  `desc4` varchar(200) DEFAULT NULL,
  `desc5` varchar(200) DEFAULT NULL,
  `desc6` varchar(200) DEFAULT NULL,
  `desc7` varchar(200) DEFAULT NULL,
  `desc8` varchar(200) DEFAULT NULL,
  `created_at` int(11) DEFAULT 0,
  `families_m` int(11) UNSIGNED DEFAULT 0,
  `families_y` int(11) UNSIGNED DEFAULT 0,
  `members_m` int(11) UNSIGNED DEFAULT 0,
  `members_y` int(11) UNSIGNED DEFAULT 0,
  `privates_m` int(11) UNSIGNED DEFAULT 0,
  `privates_y` int(11) UNSIGNED DEFAULT 0,
  `albums` tinyint(1) DEFAULT NULL,
  `pdf` tinyint(1) DEFAULT NULL,
  `heritate` tinyint(1) DEFAULT NULL,
  `show_ads` tinyint(1) DEFAULT 0,
  `support` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Dumping data for table `Ghimire_plans`
--

INSERT INTO `Ghimire_plans` (`id`, `plan`, `price_m`, `price_y`, `currency`, `desc1`, `desc2`, `desc3`, `desc4`, `desc5`, `desc6`, `desc7`, `desc8`, `created_at`, `families_m`, `families_y`, `members_m`, `members_y`, `privates_m`, `privates_y`, `albums`, `pdf`, `heritate`, `show_ads`, `support`) VALUES
(1, 'Free Plan', 0.00, 0.00, '$', '[n] Famillies', '[n] Members per family', '[n] Private Family', 'Enable to heritate families', 'Enable to create albums', 'PDF Export', 'No advertisements', 'Priority support', 0, 1, 1, 10, 10, 0, 1, 0, 0, 0, 0, 0),
(2, 'Basic Plan', 9.99, 29.99, '$', '[n] Famillies', '[n] Members per family', '[n] Private Family', 'Enable to heritate families', 'Enable to create albums', 'PDF Export', 'No advertisements', 'Priority support', 0, 12, 50, 20, 120, 1, 10, 0, 1, 0, 1, 1),
(3, 'Regular Plan', 19.99, 40.00, '$', 'Unlimited Famillies', 'Unlimited Members per family', 'Unlimited Private Family', 'Enable to heritate families', 'Enable to create albums', 'PDF Export', 'No advertisements', 'Priority support', 0, 999999, 999999, 999999, 999999, 999999, 999999, 1, 1, 1, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `Ghimire_reset_passwords`
--

CREATE TABLE `Ghimire_reset_passwords` (
  `id` smallint(5) UNSIGNED NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `date` int(10) UNSIGNED DEFAULT NULL,
  `ip` varchar(255) DEFAULT NULL,
  `status` tinyint(1) UNSIGNED DEFAULT NULL,
  `token` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Ghimire_users`
--

CREATE TABLE `Ghimire_users` (
  `id` int(11) NOT NULL,
  `username` varchar(200) DEFAULT NULL,
  `password` varchar(200) DEFAULT NULL,
  `date` int(10) UNSIGNED DEFAULT 0,
  `status` tinyint(1) UNSIGNED DEFAULT NULL,
  `token` varchar(200) DEFAULT NULL,
  `updated_at` int(10) UNSIGNED DEFAULT NULL,
  `family` smallint(6) UNSIGNED DEFAULT 0,
  `firstname` varchar(100) DEFAULT NULL,
  `lastname` varchar(100) DEFAULT NULL,
  `gender` tinyint(1) UNSIGNED DEFAULT 0,
  `birth` varchar(100) DEFAULT NULL,
  `death` tinyint(1) UNSIGNED DEFAULT 0,
  `type` tinyint(1) UNSIGNED DEFAULT 0,
  `photo` varchar(255) DEFAULT NULL,
  `email` varchar(200) DEFAULT NULL,
  `site` varchar(200) DEFAULT NULL,
  `tel` varchar(15) DEFAULT NULL,
  `mobile` varchar(15) DEFAULT NULL,
  `birthplace` varchar(255) DEFAULT NULL,
  `deathplace` varchar(255) DEFAULT NULL,
  `profession` varchar(255) DEFAULT NULL,
  `company` varchar(255) DEFAULT NULL,
  `interests` varchar(255) DEFAULT NULL,
  `bio` mediumtext DEFAULT NULL,
  `level` tinyint(1) UNSIGNED DEFAULT 1,
  `parent` int(11) UNSIGNED DEFAULT 0,
  `birthday` tinyint(2) UNSIGNED DEFAULT 0,
  `birthmonth` tinyint(2) UNSIGNED DEFAULT 0,
  `birthyear` smallint(4) UNSIGNED DEFAULT 0,
  `deathday` tinyint(2) UNSIGNED DEFAULT 0,
  `deathmonth` tinyint(2) UNSIGNED DEFAULT 0,
  `deathyear` smallint(4) UNSIGNED DEFAULT 0,
  `birthdate` int(11) DEFAULT 0,
  `mariagedate` int(11) DEFAULT 0,
  `deathdate` int(11) DEFAULT 0,
  `facebook` varchar(255) DEFAULT NULL,
  `instagram` varchar(255) DEFAULT NULL,
  `twitter` varchar(255) DEFAULT NULL,
  `plan` tinyint(1) DEFAULT 0,
  `lastpayment` int(11) DEFAULT 0,
  `slug` varchar(255) DEFAULT NULL,
  `expired_date` int(10) UNSIGNED DEFAULT 0,
  `frequency` int(10) UNSIGNED DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Dumping data for table `Ghimire_users`
--

INSERT INTO `Ghimire_users` (`id`, `username`, `password`, `date`, `status`, `token`, `updated_at`, `family`, `firstname`, `lastname`, `gender`, `birth`, `death`, `type`, `photo`, `email`, `site`, `tel`, `mobile`, `birthplace`, `deathplace`, `profession`, `company`, `interests`, `bio`, `level`, `parent`, `birthday`, `birthmonth`, `birthyear`, `deathday`, `deathmonth`, `deathyear`, `birthdate`, `mariagedate`, `deathdate`, `facebook`, `instagram`, `twitter`, `plan`, `lastpayment`, `slug`, `expired_date`, `frequency`) VALUES
(1, 'Admin', 'd033e22ae348aeb5660fc2140aec35850c4da997', 1761573109, 0, '', 1761584274, 0, NULL, NULL, 0, NULL, 0, 0, '', 'bishnu@gmail.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 6, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, 0, 0, NULL, 0, 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `Ghimire_configs`
--
ALTER TABLE `Ghimire_configs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `Ghimire_families`
--
ALTER TABLE `Ghimire_families`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `Ghimire_heritage`
--
ALTER TABLE `Ghimire_heritage`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `Ghimire_images`
--
ALTER TABLE `Ghimire_images`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `Ghimire_languages`
--
ALTER TABLE `Ghimire_languages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `Ghimire_members`
--
ALTER TABLE `Ghimire_members`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `Ghimire_notifications`
--
ALTER TABLE `Ghimire_notifications`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `Ghimire_pages`
--
ALTER TABLE `Ghimire_pages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `Ghimire_payments`
--
ALTER TABLE `Ghimire_payments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `Ghimire_plans`
--
ALTER TABLE `Ghimire_plans`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `Ghimire_reset_passwords`
--
ALTER TABLE `Ghimire_reset_passwords`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `Ghimire_users`
--
ALTER TABLE `Ghimire_users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `Ghimire_configs`
--
ALTER TABLE `Ghimire_configs`
  MODIFY `id` tinyint(3) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=72;

--
-- AUTO_INCREMENT for table `Ghimire_families`
--
ALTER TABLE `Ghimire_families`
  MODIFY `id` smallint(5) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `Ghimire_heritage`
--
ALTER TABLE `Ghimire_heritage`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `Ghimire_images`
--
ALTER TABLE `Ghimire_images`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `Ghimire_languages`
--
ALTER TABLE `Ghimire_languages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `Ghimire_members`
--
ALTER TABLE `Ghimire_members`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `Ghimire_notifications`
--
ALTER TABLE `Ghimire_notifications`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `Ghimire_pages`
--
ALTER TABLE `Ghimire_pages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `Ghimire_payments`
--
ALTER TABLE `Ghimire_payments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `Ghimire_plans`
--
ALTER TABLE `Ghimire_plans`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `Ghimire_reset_passwords`
--
ALTER TABLE `Ghimire_reset_passwords`
  MODIFY `id` smallint(5) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `Ghimire_users`
--
ALTER TABLE `Ghimire_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
