<?php
error_reporting(E_ALL);
ini_set('display_errors', 'On');
include __DIR__ . '/db0.php';

// Get current page content
$page_id = 2; // About Ghimire Dynasty page

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Handle form submission
    $content = $_POST['content'] ?? '';
    
    // Update only the content in database
    $stmt =$conn->prepare("UPDATE " . prefix . "pages SET content = ? WHERE id = ?");
    $stmt->bind_param("si", $content, $page_id);
    
    if ($stmt->execute()) {
        $success_message = "Page updated successfully!";
    } else {
        $error_message = "Error updating page: " . $stmt->error;
    }
    $stmt->close();
}

// Fetch current page data
$result =$conn->query("SELECT * FROM " . prefix . "pages WHERE id = $page_id");
if ($result && $result->num_rows > 0) {
    $current_page = $result->fetch_assoc();
}
$result->close();
?>

<!DOCTYPE html>
<html lang="ne">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit About Page</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; background: #f5f5f5; }
        .container { max-width: 1000px; margin: 0 auto; background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        h1 { color: #DC143C; text-align: center; margin-bottom: 20px; }
        .form-group { margin-bottom: 20px; }
        .form-label { display: block; margin-bottom: 8px; font-weight: bold; color: #003893; }
        .form-textarea { width: 100%; height: 400px; padding: 10px; border: 1px solid #ddd; border-radius: 4px; font-family: monospace; }
        .btn { padding: 10px 20px; background: #003893; color: white; border: none; border-radius: 4px; cursor: pointer; }
        .btn:hover { background: #002966; }
        .alert { padding: 10px; margin-bottom: 20px; border-radius: 4px; }
        .alert-success { background: #d4edda; color: #155724; border: 1px solid #c3e6cb; }
        .alert-error { background: #f8d7da; color: #721c24; border: 1px solid #f5c6cb; }
        .bbcode-help { background: #f8f9fa; padding: 15px; border-radius: 4px; margin-bottom: 20px; border-left: 4px solid #003893; }
    </style>
</head>
<body>
    <div class="container">
        <h1>Edit About Ghimire Dynasty Page</h1>
        
        <?php if (isset($success_message)): ?>
            <div class="alert alert-success"><?php echo $success_message; ?></div>
        <?php endif; ?>
        
        <?php if (isset($error_message)): ?>
            <div class="alert alert-error"><?php echo $error_message; ?></div>
        <?php endif; ?>
        
        <div class="bbcode-help">
            <strong>BBcode Help:</strong><br>
            <code>[b]text[/b]</code> - Bold<br>
            <code>[i]text[/i]</code> - Italic<br>
            <code>[u]text[/u]</code> - Underline<br>
            <code>[color=#color]text[/color]</code> - Color<br>
            <code>[size=20]text[/size]</code> - Size<br>
            <code>[center]text[/center]</code> - Center<br>
            <code>[url=http://example.com]text[/url]</code> - Link<br>
            <code>[hr]</code> - Horizontal line<br>
            <code>[ul][li]item[/li][/ul]</code> - List
        </div>
        
        <?php if ($current_page): ?>
        <form method="POST" action="">
            <div class="form-group">
                <label class="form-label">Content (BBcode):</label>
                <textarea class="form-textarea" name="content" required><?php echo htmlspecialchars($current_page['content']); ?></textarea>
            </div>
            
            <button type="submit" class="btn">Update Page</button>
        </form>
        <?php else: ?>
            <div class="alert alert-error">Page not found!</div>
        <?php endif; ?>
    </div>
</body>
</html>