<?php
// configs/db0.php

define('prefix', 'Ghimire_');
error_reporting(E_ALL);
ini_set('display_errors', 'On');
$host = 'sql102.infinityfree.com'; // तपाईंको host name
$username = 'if0_40435316'; // तपाईंको database username
$password = 'NJHOmLBWzet'; // तपाईंको database password
$database = 'if0_40435316_ghimire'; // तपाईंको database name


// Create connection
$conn = new mysqli($host, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
// Set charset
?>