<?php
error_reporting(E_ALL);
ini_set('display_errors', 'On');
include __DIR__ . '/db0.php';

// Actions
$action = $_GET['action'] ?? 'list';
$page_id = $_GET['id'] ?? 0;
$message = '';
$message_type = '';

// Handle actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = $_POST['title'] ?? '';
    $content = $_POST['content'] ?? '';
    $slug = $_POST['slug'] ?? '';
    
    if (isset($_POST['create'])) {
        // Create new page
        $stmt = $conn->prepare("INSERT INTO " . prefix . "pages (title, content, slug, created_at, updated_at) VALUES (?, ?, ?, NOW(), NOW())");
        $stmt->bind_param("sss", $title, $content, $slug);
        
        if ($stmt->execute()) {
            $message = "Page created successfully!";
            $message_type = 'success';
            $action = 'list';
        } else {
            $message = "Error creating page: " . $stmt->error;
            $message_type = 'error';
        }
        $stmt->close();
    } 
    elseif (isset($_POST['update'])) {
        // Update page
        $stmt = $conn->prepare("UPDATE " . prefix . "pages SET title = ?, content = ?, slug = ?, updated_at = NOW() WHERE id = ?");
        $stmt->bind_param("sssi", $title, $content, $slug, $page_id);
        
        if ($stmt->execute()) {
            $message = "Page updated successfully!";
            $message_type = 'success';
            $action = 'list';
        } else {
            $message = "Error updating page: " . $stmt->error;
            $message_type = 'error';
        }
        $stmt->close();
    }
}

// Handle delete action
if (isset($_GET['delete'])) {
    $page_id = $_GET['delete'];
    $stmt = $conn->prepare("DELETE FROM " . prefix . "pages WHERE id = ?");
    $stmt->bind_param("i", $page_id);
    
    if ($stmt->execute()) {
        $message = "Page deleted successfully!";
        $message_type = 'success';
    } else {
        $message = "Error deleting page: " . $stmt->error;
        $message_type = 'error';
    }
    $stmt->close();
    $action = 'list';
}

// Fetch data based on action
$current_page = null;
$pages = [];

if ($action === 'edit' && $page_id) {
    $result = $conn->query("SELECT * FROM " . prefix . "pages WHERE id = $page_id");
    if ($result && $result->num_rows > 0) {
        $current_page = $result->fetch_assoc();
    }
    $result->close();
}

if ($action === 'list' || $action === '') {
    $result = $conn->query("SELECT * FROM " . prefix . "pages ORDER BY id DESC");
    if ($result) {
        $pages = $result->fetch_all(MYSQLI_ASSOC);
    }
    $result->close();
}
?>

<!DOCTYPE html>
<html lang="ne">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Database File Manager</title>
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body { font-family: 'Segoe UI', Arial, sans-serif; margin: 0; background: #f8f9fa; color: #333; }
        
        .container { max-width: 1200px; margin: 0 auto; padding: 20px; }
        
        .header { 
            background: linear-gradient(135deg, #003893 0%, #DC143C 100%); 
            color: white; 
            padding: 20px 0; 
            margin-bottom: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        }
        
        .header h1 { text-align: center; font-size: 2.2em; margin-bottom: 10px; }
        .header p { text-align: center; opacity: 0.9; }
        
        .actions { 
            background: white; 
            padding: 20px; 
            border-radius: 8px; 
            margin-bottom: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .btn { 
            padding: 10px 20px; 
            border: none; 
            border-radius: 6px; 
            cursor: pointer; 
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            font-weight: 500;
            transition: all 0.3s ease;
        }
        
        .btn-primary { 
            background: #003893; 
            color: white; 
        }
        .btn-primary:hover { background: #002966; transform: translateY(-2px); }
        
        .btn-success { 
            background: #28a745; 
            color: white; 
        }
        .btn-success:hover { background: #218838; transform: translateY(-2px); }
        
        .btn-warning { 
            background: #ffc107; 
            color: #212529; 
        }
        .btn-warning:hover { background: #e0a800; transform: translateY(-2px); }
        
        .btn-danger { 
            background: #dc3545; 
            color: white; 
        }
        .btn-danger:hover { background: #c82333; transform: translateY(-2px); }
        
        .btn-secondary { 
            background: #6c757d; 
            color: white; 
        }
        .btn-secondary:hover { background: #545b62; transform: translateY(-2px); }
        
        .alert { 
            padding: 15px; 
            margin-bottom: 20px; 
            border-radius: 6px; 
            border-left: 4px solid;
        }
        
        .alert-success { 
            background: #d4edda; 
            color: #155724; 
            border-color: #c3e6cb; 
        }
        
        .alert-error { 
            background: #f8d7da; 
            color: #721c24; 
            border-color: #f5c6cb; 
        }
        
        /* File Manager Grid */
        .file-grid { 
            display: grid; 
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); 
            gap: 20px; 
            margin-bottom: 30px;
        }
        
        .file-card { 
            background: white; 
            border-radius: 8px; 
            padding: 20px; 
            box-shadow: 0 2px 10px rgba(0,0,0,0.08);
            transition: all 0.3s ease;
            border: 1px solid #e9ecef;
        }
        
        .file-card:hover { 
            transform: translateY(-5px); 
            box-shadow: 0 5px 20px rgba(0,0,0,0.15);
        }
        
        .file-title { 
            font-size: 1.2em; 
            font-weight: 600; 
            margin-bottom: 10px; 
            color: #003893;
            word-break: break-word;
        }
        
        .file-meta { 
            color: #6c757d; 
            font-size: 0.85em; 
            margin-bottom: 15px;
            display: flex;
            justify-content: space-between;
        }
        
        .file-content-preview { 
            color: #495057; 
            margin-bottom: 15px; 
            max-height: 80px; 
            overflow: hidden;
            line-height: 1.4;
        }
        
        .file-actions { 
            display: flex; 
            gap: 10px; 
            border-top: 1px solid #e9ecef;
            padding-top: 15px;
        }
        
        /* Form Styles */
        .form-container { 
            background: white; 
            padding: 30px; 
            border-radius: 8px; 
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        }
        
        .form-group { 
            margin-bottom: 25px; 
        }
        
        .form-label { 
            display: block; 
            margin-bottom: 8px; 
            font-weight: 600; 
            color: #003893; 
        }
        
        .form-input, 
        .form-textarea { 
            width: 100%; 
            padding: 12px; 
            border: 1px solid #ddd; 
            border-radius: 6px; 
            font-family: inherit;
            transition: border 0.3s ease;
        }
        
        .form-input:focus, 
        .form-textarea:focus { 
            border-color: #003893; 
            outline: none;
            box-shadow: 0 0 0 3px rgba(0, 56, 147, 0.1);
        }
        
        .form-textarea { 
            height: 400px; 
            resize: vertical;
        }
        
        .bbcode-help { 
            background: #f8f9fa; 
            padding: 20px; 
            border-radius: 6px; 
            margin-bottom: 25px; 
            border-left: 4px solid #003893;
            font-size: 0.9em;
        }
        
        .bbcode-help code { 
            background: #e9ecef; 
            padding: 2px 6px; 
            border-radius: 3px; 
            font-family: monospace;
        }
        
        .form-actions { 
            display: flex; 
            gap: 15px; 
            margin-top: 25px;
            padding-top: 20px;
            border-top: 1px solid #e9ecef;
        }
        
        .empty-state { 
            text-align: center; 
            padding: 60px 20px; 
            color: #6c757d;
        }
        
        .empty-state h3 { 
            margin-bottom: 10px; 
            color: #003893;
        }
        
        /* Responsive */
        @media (max-width: 768px) {
            .file-grid { grid-template-columns: 1fr; }
            .actions { flex-direction: column; gap: 15px; align-items: stretch; }
            .form-actions { flex-direction: column; }
        }
    </style>
</head>
<body>
    <div class="header">
        <div class="container">
            <h1>📁 Database File Manager</h1>
            <p>Manage your website pages like files</p>
        </div>
    </div>

    <div class="container">
        <?php if ($message): ?>
            <div class="alert alert-<?php echo $message_type === 'success' ? 'success' : 'error'; ?>">
                <?php echo $message; ?>
            </div>
        <?php endif; ?>

        <?php if ($action === 'list' || $action === ''): ?>
            <!-- File Manager Interface -->
            <div class="actions">
                <h2>All Pages (<?php echo count($pages); ?>)</h2>
                <a href="?action=create" class="btn btn-primary">
                    <span>+</span> Create New Page
                </a>
            </div>

            <?php if (empty($pages)): ?>
                <div class="empty-state">
                    <h3>No pages found</h3>
                    <p>Create your first page to get started</p>
                    <a href="?action=create" class="btn btn-primary" style="margin-top: 15px;">
                        Create New Page
                    </a>
                </div>
            <?php else: ?>
                <div class="file-grid">
                    <?php foreach ($pages as $page): ?>
                        <div class="file-card">
                            <div class="file-title">📄 <?php echo htmlspecialchars($page['title']); ?></div>
                            <div class="file-meta">
                                <span>ID: <?php echo $page['id']; ?></span>
                                <span><?php echo date('Y-m-d', strtotime($page['updated_at'])); ?></span>
                            </div>
                            <div class="file-content-preview">
                                <?php echo substr(strip_tags($page['content']), 0, 120) . '...'; ?>
                            </div>
                            <div class="file-actions">
                                <a href="?action=edit&id=<?php echo $page['id']; ?>" class="btn btn-warning" style="flex: 1;">
                                    ✏️ Edit
                                </a>
                                <a href="?delete=<?php echo $page['id']; ?>" 
                                   class="btn btn-danger" 
                                   onclick="return confirm('Are you sure you want to delete this page?')"
                                   style="flex: 1;">
                                    🗑️ Delete
                                </a>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>

        <?php elseif ($action === 'create' || $action === 'edit'): ?>
            <!-- Create/Edit Form -->
            <div class="actions">
                <h2><?php echo $action === 'create' ? 'Create New Page' : 'Edit Page'; ?></h2>
                <a href="?action=list" class="btn btn-secondary">
                    ← Back to List
                </a>
            </div>

            <div class="form-container">
                <div class="bbcode-help">
                    <strong>📝 BBcode Help:</strong><br>
                    <code>[b]text[/b]</code> - Bold • 
                    <code>[i]text[/i]</code> - Italic • 
                    <code>[u]text[/u]</code> - Underline<br>
                    <code>[color=#color]text[/color]</code> - Color • 
                    <code>[size=20]text[/size]</code> - Size • 
                    <code>[center]text[/center]</code> - Center<br>
                    <code>[url=http://example.com]text[/url]</code> - Link • 
                    <code>[hr]</code> - Horizontal line • 
                    <code>[ul][li]item[/li][/ul]</code> - List
                </div>

                <form method="POST" action="?action=<?php echo $action; ?><?php echo $action === 'edit' ? '&id=' . $page_id : ''; ?>">
                    <div class="form-group">
                        <label class="form-label">Page Title:</label>
                        <input type="text" class="form-input" name="title" 
                               value="<?php echo $current_page['title'] ?? ''; ?>" required>
                    </div>

                    <div class="form-group">
                        <label class="form-label">Slug (URL):</label>
                        <input type="text" class="form-input" name="slug" 
                               value="<?php echo $current_page['slug'] ?? ''; ?>" required>
                    </div>

                    <div class="form-group">
                        <label class="form-label">Content (BBcode):</label>
                        <textarea class="form-textarea" name="content" required><?php echo htmlspecialchars($current_page['content'] ?? ''); ?></textarea>
                    </div>

                    <div class="form-actions">
                        <?php if ($action === 'create'): ?>
                            <button type="submit" name="create" class="btn btn-success">
                                💾 Create Page
                            </button>
                        <?php else: ?>
                            <button type="submit" name="update" class="btn btn-success">
                                💾 Update Page
                            </button>
                        <?php endif; ?>
                        
                        <a href="?action=list" class="btn btn-secondary">
                            ❌ Cancel
                        </a>
                    </div>
                </form>
            </div>
        <?php endif; ?>
    </div>

    <script>
        // Auto-hide messages after 5 seconds
        setTimeout(() => {
            const alerts = document.querySelectorAll('.alert');
            alerts.forEach(alert => {
                alert.style.opacity = '0';
                alert.style.transition = 'opacity 0.5s ease';
                setTimeout(() => alert.remove(), 500);
            });
        }, 5000);

        // Confirm before delete
        document.addEventListener('click', (e) => {
            if (e.target.classList.contains('btn-danger')) {
                if (!confirm('Are you sure you want to delete this page? This action cannot be undone.')) {
                    e.preventDefault();
                }
            }
        });
    </script>
</body>
</html>