<?php
error_reporting(E_ALL);
ini_set('display_errors', 'On');

// Include connection data
error_reporting(E_ALL);
ini_set('display_errors', 'On');
$host = 'sql102.infinityfree.com'; 
$username = 'if0_40435316'; 
$password = 'NJHOmLBWzet'; 
$database = 'if0_40435316_ghimire';


// Create connection
$conn = new mysqli($host, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if connection is established
if (!isset($conn) || $conn->connect_error) {
    die("Database connection failed: " . ($conn->connect_error ?? "Connection not established"));
}

// Get current table
$current_table = $_GET['table'] ?? '';
$current_id = $_GET['id'] ?? '';
$action = $_GET['action'] ?? 'view';
$view_mode = $_GET['view'] ?? 'list'; // 'list' or 'full'

// Get all tables
$tables_result = $conn->query("SHOW TABLES");
$tables = [];
while ($row = $tables_result->fetch_row()) {
    $tables[] = $row[0];
}

// Handle form actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $table = $_POST['table'] ?? '';
    $id = $_POST['id'] ?? '';
    
    if ($action === 'insert' && $table) {
        $columns = [];
        $values = [];
        $types = '';
        $params = [];
        
        foreach ($_POST as $key => $value) {
            if ($key !== 'action' && $key !== 'table' && $key !== 'id') {
                $columns[] = "`$key`";
                $values[] = "?";
                $types .= "s";
                $params[] = $value;
            }
        }
        
        $sql = "INSERT INTO `$table` (" . implode(', ', $columns) . ") VALUES (" . implode(', ', $values) . ")";
        $stmt = $conn->prepare($sql);
        if ($types) {
            $stmt->bind_param($types, ...$params);
        }
        $stmt->execute();
        
    } elseif ($action === 'update' && $table && $id) {
        $updates = [];
        $types = '';
        $params = [];
        
        foreach ($_POST as $key => $value) {
            if ($key !== 'action' && $key !== 'table' && $key !== 'id') {
                $updates[] = "`$key` = ?";
                $types .= "s";
                $params[] = $value;
            }
        }
        
        $types .= "i";
        $params[] = $id;
        $sql = "UPDATE `$table` SET " . implode(', ', $updates) . " WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param($types, ...$params);
        $stmt->execute();
        
    } elseif ($action === 'delete' && $table && $id) {
        $stmt = $conn->prepare("DELETE FROM `$table` WHERE id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
    }
    
    // Redirect to avoid form resubmission
    header("Location: " . $_SERVER['PHP_SELF'] . "?table=$table&view=$view_mode");
    exit;
}

// Get table data if table is selected
$table_data = [];
$table_columns = [];
$edit_row = null;

if ($current_table) {
    // Get table columns
    $columns_result = $conn->query("DESCRIBE `$current_table`");
    while ($column = $columns_result->fetch_assoc()) {
        $table_columns[] = $column;
    }
    
    // Get table data
    $data_result = $conn->query("SELECT * FROM `$current_table` LIMIT 100");
    while ($row = $data_result->fetch_assoc()) {
        $table_data[] = $row;
    }
    
    // Get row for editing
    if ($current_id && $action === 'edit') {
        $stmt = $conn->prepare("SELECT * FROM `$current_table` WHERE id = ?");
        $stmt->bind_param("i", $current_id);
        $stmt->execute();
        $edit_result = $stmt->get_result();
        $edit_row = $edit_result->fetch_assoc();
    }
}

// Function to display value properly
function displayValue($value, $max_length = 50) {
    if ($value === null) return 'NULL';
    if ($value === '') return '∅';
    
    // For list view, truncate long content
    if (strlen($value) > $max_length) {
        return substr($value, 0, $max_length) . '...';
    }
    
    return $value;
}

// Function to get full value without truncation
function displayFullValue($value) {
    if ($value === null) return 'NULL';
    if ($value === '') return '∅';
    return $value;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Database data Manager</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { 
            font-family: Arial, sans-serif; 
            background: #f5f5f5; 
            padding: 0;
            overflow-x: hidden;
        }
        
        /* Mobile Drawer Styles */
        .drawer-overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.5);
            z-index: 998;
            display: none;
        }
        
        .drawer-overlay.active {
            display: block;
        }
        
        .sidebar {
            position: fixed;
            top: 0;
            left: -280px;
            width: 280px;
            height: 100%;
            background: #2c3e50;
            color: white;
            transition: all 0.3s ease;
            z-index: 999;
            overflow-y: auto;
            box-shadow: 2px 0 10px rgba(0,0,0,0.3);
        }
        
        .sidebar.active {
            left: 0;
        }
        
        .drawer-header {
            background: #34495e;
            padding: 20px 15px;
            border-bottom: 1px solid #4a6278;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .drawer-close {
            background: none;
            border: none;
            color: white;
            font-size: 20px;
            cursor: pointer;
            padding: 5px;
        }
        
        /* Main Container */
        .container { 
            max-width: 100%; 
            margin: 0 auto; 
            background: white; 
            min-height: 100vh;
            transition: all 0.3s ease;
        }
        
        .container.drawer-open {
            transform: translateX(280px);
        }
        
        .header { 
            background: #2c3e50; 
            color: white; 
            padding: 15px; 
            position: sticky;
            top: 0;
            z-index: 99;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .main-content { 
            padding: 15px; 
            background: #ecf0f1; 
            min-height: calc(100vh - 80px);
        }
        
        /* Menu Button */
        .menu-btn {
            background: none;
            border: none;
            color: white;
            font-size: 20px;
            cursor: pointer;
            padding: 5px 10px;
            border-radius: 4px;
            transition: background 0.3s;
        }
        
        .menu-btn:hover {
            background: rgba(255,255,255,0.1);
        }
        
        /* Tables List */
        .table-list { list-style: none; margin-top: 10px; }
        .table-item { 
            padding: 15px; 
            border-bottom: 1px solid #4a6278; 
            cursor: pointer; 
            transition: background 0.3s; 
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .table-item:hover { background: #4a6278; }
        .table-item.active { 
            background: #3498db; 
            border-left: 4px solid #2980b9;
        }
        
        .table-icon {
            font-size: 18px;
        }
        
        .table-info {
            flex: 1;
        }
        
        .table-name {
            font-weight: bold;
            font-size: 14px;
        }
        
        .table-count {
            font-size: 11px;
            color: #bdc3c7;
            margin-top: 2px;
        }
        
        /* Buttons */
        .btn { 
            padding: 8px 12px; 
            margin: 3px; 
            border: none; 
            border-radius: 4px; 
            cursor: pointer; 
            text-decoration: none; 
            display: inline-block; 
            font-size: 12px; 
        }
        .btn-primary { background: #3498db; color: white; }
        .btn-success { background: #27ae60; color: white; }
        .btn-warning { background: #f39c12; color: white; }
        .btn-danger { background: #e74c3c; color: white; }
        .btn-info { background: #17a2b8; color: white; }
        .btn-sm { padding: 6px 10px; font-size: 11px; }
        
        /* View Mode Toggle */
        .view-toggle {
            display: flex;
            background: #f8f9fa;
            border-radius: 6px;
            padding: 4px;
            margin: 10px 0;
        }
        
        .view-btn {
            flex: 1;
            padding: 8px 12px;
            border: none;
            background: none;
            cursor: pointer;
            border-radius: 4px;
            font-size: 12px;
            transition: all 0.3s;
        }
        
        .view-btn.active {
            background: #3498db;
            color: white;
        }
        
        /* Mobile responsive table */
        .data-table { 
            width: 100%; 
            border-collapse: collapse; 
            margin: 10px 0; 
            background: white; 
            font-size: 12px; 
        }
        .data-table th { 
            background: #34495e; 
            color: white; 
            padding: 10px 8px; 
            text-align: left; 
            position: sticky;
            top: 0;
        }
        .data-table td { 
            padding: 8px; 
            border-bottom: 1px solid #ecf0f1; 
            vertical-align: top;
        }
        .data-table tr:nth-child(even) { background: #f9f9f9; }
        .data-table tr:hover { background: #f1f1f1; }
        
        /* List View Styles */
        .list-view .content-cell {
            max-width: 150px;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
        }
        
        .list-view .full-content {
            background: #fff3cd;
            padding: 4px 6px;
            border-radius: 3px;
            border-left: 2px solid #ffc107;
            cursor: pointer;
        }
        
        /* Full View Styles */
        .full-view .content-cell {
            white-space: normal;
            word-wrap: break-word;
        }
        
        .full-view .full-content {
            background: #e8f4fd;
            padding: 8px;
            border-radius: 4px;
            border-left: 3px solid #3498db;
            margin: 2px 0;
        }
        
        /* Mobile table container */
        .table-container { 
            overflow-x: auto; 
            -webkit-overflow-scrolling: touch;
            margin-bottom: 15px;
        }
        
        /* Forms */
        .form-group { margin-bottom: 10px; }
        .form-control { 
            width: 100%; 
            padding: 10px; 
            border: 1px solid #ddd; 
            border-radius: 4px; 
            font-size: 14px; 
        }
        .form-label { 
            display: block; 
            margin-bottom: 5px; 
            font-weight: bold; 
            color: #2c3e50; 
            font-size: 14px; 
        }
        
        /* Alerts */
        .alert { 
            padding: 12px; 
            margin: 10px 0; 
            border-radius: 6px; 
            font-size: 14px; 
        }
        .alert-info { 
            background: #d1ecf1; 
            color: #0c5460; 
            border: 1px solid #bee5eb; 
        }
        
        /* Empty state */
        .empty-state { 
            text-align: center; 
            padding: 30px 15px; 
            color: #7f8c8d; 
        }
        
        /* Action buttons container */
        .action-buttons { 
            display: flex; 
            flex-wrap: wrap; 
            gap: 4px; 
        }
        
        /* Current table info */
        .current-table-info {
            background: white;
            padding: 15px;
            border-radius: 6px;
            margin-bottom: 15px;
            border-left: 4px solid #3498db;
        }
        
        /* Desktop Styles */
        @media (min-width: 1024px) {
            .sidebar {
                position: static;
                width: 300px;
                height: auto;
                background: #2c3e50;
                transform: none !important;
                box-shadow: none;
            }
            
            .container {
                display: flex;
                min-height: 100vh;
            }
            
            .main-content {
                flex: 1;
                padding: 20px;
            }
            
            .drawer-header, .drawer-close, .drawer-overlay {
                display: none;
            }
            
            .menu-btn {
                display: none;
            }
            
            .list-view .content-cell {
                max-width: 200px;
            }
        }
        
        /* Tablet Styles */
        @media (min-width: 768px) and (max-width: 1023px) {
            .sidebar {
                width: 320px;
                left: -320px;
            }
            
            .container.drawer-open {
                transform: translateX(320px);
            }
        }
        
        /* Small mobile adjustments */
        @media (max-width: 480px) {
            .sidebar {
                width: 100%;
                left: -100%;
            }
            
            .container.drawer-open {
                transform: translateX(100%);
            }
            
            .list-view .content-cell {
                max-width: 120px;
            }
            
            .btn { 
                padding: 6px 10px; 
                font-size: 11px; 
            }
        }
    </style>
</head>
<body>
    <!-- Drawer Overlay -->
    <div class="drawer-overlay" id="drawerOverlay" onclick="closeDrawer()"></div>
    
    <!-- Sidebar Drawer -->
    <div class="sidebar" id="sidebar">
        <div class="drawer-header">
            <h3 style="margin: 0; font-size: 18px;">📊 Database Tables</h3>
            <button class="drawer-close" onclick="closeDrawer()">✕</button>
        </div>
        
        <div style="padding: 15px;">
            <ul class="table-list">
                <?php foreach ($tables as $table): ?>
                    <?php
                    // Get row count for each table
                    $count_result = $conn->query("SELECT COUNT(*) as count FROM `$table`");
                    $row_count = $count_result ? $count_result->fetch_assoc()['count'] : 0;
                    ?>
                    <li class="table-item <?= $current_table === $table ? 'active' : '' ?>" 
                        onclick="selectTable('<?= urlencode($table) ?>')">
                        <span class="table-icon">📋</span>
                        <div class="table-info">
                            <div class="table-name"><?= htmlspecialchars($table) ?></div>
                            <div class="table-count"><?= $row_count ?> records</div>
                        </div>
                        <?php if ($current_table === $table): ?>
                            <span style="color: #2ecc71;">✓</span>
                        <?php endif; ?>
                    </li>
                <?php endforeach; ?>
            </ul>
            
            <?php if ($current_table): ?>
            <div style="margin-top: 25px; padding-top: 20px; border-top: 1px solid #4a6278;">
                <h4 style="font-size: 16px; margin-bottom: 15px; color: #ecf0f1;">Quick Actions</h4>
                <a href="?table=<?= urlencode($current_table) ?>&action=add" class="btn btn-success" style="display: block; text-align: center;" onclick="closeDrawer()">
                    ➕ Add New Record
                </a>
                <a href="?" class="btn btn-primary" style="display: block; text-align: center; margin-top: 10px;" onclick="closeDrawer()">
                    🏠 Back to Home
                </a>
            </div>
            <?php endif; ?>
        </div>
    </div>
    
    <!-- Main Container -->
    <div class="container" id="mainContainer">
        <div class="header">
            <button class="menu-btn" onclick="openDrawer()">☰</button>
            <div>
                <h1 style="font-size: 18px; margin: 0;">Database Manager</h1>
                <p style="font-size: 12px; margin: 0; opacity: 0.8;">Manage your database tables</p>
            </div>
            <div style="width: 40px;"></div>
        </div>
        
        <div class="main-content">
            <?php if (!$current_table): ?>
                <div class="empty-state">
                    <div style="font-size: 48px; margin-bottom: 20px;">📊</div>
                    <h2 style="margin-bottom: 10px; color: #2c3e50;">Welcome to Database Manager</h2>
                    <p style="margin-bottom: 25px; color: #7f8c8d;">Select a table from the menu to view and manage its data</p>
                    <button class="btn btn-primary" onclick="openDrawer()">📋 Open Tables Menu</button>
                </div>
            <?php elseif ($action === 'add' || ($action === 'edit' && $edit_row)): ?>
                <!-- Add/Edit Form -->
                <div class="current-table-info">
                    <h3 style="margin: 0; color: #2c3e50;">
                        <?= $action === 'add' ? '➕ Add New Record' : '✏️ Edit Record' ?> 
                        in <span style="color: #3498db;"><?= htmlspecialchars($current_table) ?></span>
                    </h3>
                </div>
                
                <div style="background: white; padding: 20px; border-radius: 8px;">
                    <form method="POST">
                        <input type="hidden" name="action" value="<?= $action === 'add' ? 'insert' : 'update' ?>">
                        <input type="hidden" name="table" value="<?= htmlspecialchars($current_table) ?>">
                        <?php if ($action === 'edit'): ?>
                            <input type="hidden" name="id" value="<?= $edit_row['id'] ?>">
                        <?php endif; ?>
                        
                        <?php foreach ($table_columns as $column): ?>
                            <?php if ($column['Field'] !== 'id' && $column['Extra'] !== 'auto_increment'): ?>
                                <div class="form-group">
                                    <label class="form-label">
                                        <?= htmlspecialchars($column['Field']) ?>
                                        <small style="color: #7f8c8d; font-weight: normal;">(<?= htmlspecialchars($column['Type']) ?>)</small>
                                    </label>
                                    <?php if (strpos($column['Type'], 'text') !== false || strpos($column['Type'], 'longtext') !== false): ?>
                                        <textarea name="<?= htmlspecialchars($column['Field']) ?>" class="form-control" rows="5"
                                            placeholder="Enter <?= htmlspecialchars($column['Field']) ?>"><?= isset($edit_row[$column['Field']]) ? $edit_row[$column['Field']] : '' ?></textarea>
                                    <?php else: ?>
                                        <input type="text" name="<?= htmlspecialchars($column['Field']) ?>" class="form-control"
                                            value="<?= isset($edit_row[$column['Field']]) ? $edit_row[$column['Field']] : '' ?>"
                                            placeholder="Enter <?= htmlspecialchars($column['Field']) ?>">
                                    <?php endif; ?>
                                </div>
                            <?php endif; ?>
                        <?php endforeach; ?>
                        
                        <div style="display: flex; gap: 10px; flex-wrap: wrap; margin-top: 25px;">
                            <button type="submit" class="btn btn-success">💾 Save Record</button>
                            <a href="?table=<?= urlencode($current_table) ?>&view=<?= $view_mode ?>" class="btn">❌ Cancel</a>
                        </div>
                    </form>
                </div>
                
            <?php else: ?>
                <!-- Table Data View -->
                <div class="current-table-info">
                    <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 10px;">
                        <div>
                            <h3 style="margin: 0; color: #2c3e50;">
                                Table: <span style="color: #3498db;"><?= htmlspecialchars($current_table) ?></span>
                            </h3>
                            <p style="margin: 5px 0 0 0; color: #7f8c8d; font-size: 13px;">
                                Showing <?= count($table_data) ?> records
                            </p>
                        </div>
                        <div style="display: flex; gap: 8px; align-items: center;">
                            <!-- View Mode Toggle -->
                            <div class="view-toggle">
                                <button class="view-btn <?= $view_mode === 'list' ? 'active' : '' ?>" 
                                        onclick="changeViewMode('list')">
                                    📋 List View
                                </button>
                                <button class="view-btn <?= $view_mode === 'full' ? 'active' : '' ?>" 
                                        onclick="changeViewMode('full')">
                                    📄 Full View
                                </button>
                            </div>
                            <a href="?table=<?= urlencode($current_table) ?>&action=add&view=<?= $view_mode ?>" class="btn btn-success">➕ Add New</a>
                        </div>
                    </div>
                </div>
                
                <?php if (!empty($table_data)): ?>
                    <div class="table-container <?= $view_mode ?>-view">
                        <table class="data-table">
                            <thead>
                                <tr>
                                    <?php foreach (array_keys($table_data[0]) as $column): ?>
                                        <th><?= htmlspecialchars($column) ?></th>
                                    <?php endforeach; ?>
                                    <th style="text-align: center;">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($table_data as $row): ?>
                                    <tr>
                                        <?php foreach ($row as $value): ?>
                                            <td class="content-cell">
                                                <div class="full-content" 
                                                     onclick="showFullContent(this, '<?= htmlspecialchars(addslashes(displayFullValue($value))) ?>')"
                                                     title="Click to view full content">
                                                    <?= $view_mode === 'list' ? 
                                                        htmlspecialchars(displayValue($value)) : 
                                                        htmlspecialchars(displayFullValue($value)) ?>
                                                </div>
                                            </td>
                                        <?php endforeach; ?>
                                        <td>
                                            <div class="action-buttons">
                                                <a href="?table=<?= urlencode($current_table) ?>&id=<?= $row['id'] ?>&action=edit&view=<?= $view_mode ?>" 
                                                   class="btn btn-warning btn-sm">✏️ Edit</a>
                                                <form method="POST" style="display: inline;">
                                                    <input type="hidden" name="action" value="delete">
                                                    <input type="hidden" name="table" value="<?= htmlspecialchars($current_table) ?>">
                                                    <input type="hidden" name="id" value="<?= $row['id'] ?>">
                                                    <button type="submit" class="btn btn-danger btn-sm" 
                                                            onclick="return confirm('Are you sure you want to delete this record?')">🗑️ Delete</button>
                                                </form>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <div class="empty-state">
                        <div style="font-size: 48px; margin-bottom: 20px;">📭</div>
                        <h3 style="margin-bottom: 10px; color: #2c3e50;">No Data Found</h3>
                        <p style="margin-bottom: 25px; color: #7f8c8d;">This table is empty. Add the first record!</p>
                        <a href="?table=<?= urlencode($current_table) ?>&action=add&view=<?= $view_mode ?>" class="btn btn-success">➕ Add First Record</a>
                    </div>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>

    <!-- Full Content Modal -->
    <div id="fullContentModal" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.8); z-index: 1000; justify-content: center; align-items: center;">
        <div style="background: white; padding: 20px; border-radius: 8px; max-width: 90%; max-height: 80%; overflow: auto; position: relative;">
            <button onclick="closeFullContent()" style="position: absolute; top: 10px; right: 10px; background: #e74c3c; color: white; border: none; border-radius: 50%; width: 30px; height: 30px; cursor: pointer;">✕</button>
            <h3 style="margin-bottom: 15px; color: #2c3e50;">Full Content</h3>
            <pre id="modalContent" style="white-space: pre-wrap; word-wrap: break-word; font-family: Arial, sans-serif; font-size: 14px; line-height: 1.4;"></pre>
        </div>
    </div>

    <script>
        // Drawer functions
        function openDrawer() {
            document.getElementById('sidebar').classList.add('active');
            document.getElementById('drawerOverlay').classList.add('active');
            document.getElementById('mainContainer').classList.add('drawer-open');
            document.body.style.overflow = 'hidden';
        }
        
        function closeDrawer() {
            document.getElementById('sidebar').classList.remove('active');
            document.getElementById('drawerOverlay').classList.remove('active');
            document.getElementById('mainContainer').classList.remove('drawer-open');
            document.body.style.overflow = 'auto';
        }
        
        function selectTable(tableName) {
            window.location.href = '?table=' + tableName;
            closeDrawer();
        }
        
        // View mode functions
        function changeViewMode(mode) {
            const url = new URL(window.location);
            url.searchParams.set('view', mode);
            window.location.href = url.toString();
        }
        
        // Full content modal
        function showFullContent(element, fullContent) {
            document.getElementById('modalContent').textContent = fullContent;
            document.getElementById('fullContentModal').style.display = 'flex';
        }
        
        function closeFullContent() {
            document.getElementById('fullContentModal').style.display = 'none';
        }
        
        // Close modal when clicking outside
        document.getElementById('fullContentModal').addEventListener('click', function(e) {
            if (e.target === this) {
                closeFullContent();
            }
        });
        
        // Close drawer when pressing Escape key
        document.addEventListener('keydown', function(event) {
            if (event.key === 'Escape') {
                closeDrawer();
                closeFullContent();
            }
        });
        
        // Swipe to close drawer on mobile
        let touchStartX = 0;
        let touchEndX = 0;
        
        document.addEventListener('touchstart', function(event) {
            touchStartX = event.changedTouches[0].screenX;
        });
        
        document.addEventListener('touchend', function(event) {
            touchEndX = event.changedTouches[0].screenX;
            handleSwipe();
        });
        
        function handleSwipe() {
            const swipeThreshold = 50;
            const swipeDistance = touchEndX - touchStartX;
            
            // Swipe left to close
            if (swipeDistance < -swipeThreshold && document.getElementById('sidebar').classList.contains('active')) {
                closeDrawer();
            }
        }
        
        // Auto-resize textareas
        document.querySelectorAll('textarea').forEach(textarea => {
            textarea.addEventListener('input', function() {
                this.style.height = 'auto';
                this.style.height = (this.scrollHeight) + 'px';
            });
            
            // Initial resize
            setTimeout(() => {
                textarea.style.height = 'auto';
                textarea.style.height = (textarea.scrollHeight) + 'px';
            }, 100);
        });
    </script>
</body>
</html>