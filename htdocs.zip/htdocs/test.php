<?php
echo "Hello World! Testing...";
phpinfo();
?>